import os
import glob
import numpy as np
np.set_printoptions(threshold=np.inf)

from bs4 import BeautifulSoup

import datasets

logger = datasets.logging.get_logger(__name__)

_CITATION = """\
    @inproceedings{dang2010soverview,
        title={Overview of DUC 2010},
        author={Dang, Hoa Trang},
        booktitle={Proceedings of the Document Understanding Conference},
        volume={2010},
        year={2010},
        organization={Citeseer}
    }
"""

_DESCRIPTION = """\
    The DUC 2010 summarization task was to synthesize from a set of 25
    documents a well-organized, fluent answer to a complex question. The
    task and evaluation measures were basically the same as in DUC 2005,
    except that an additional “overall” responsiveness measure was added
    which took into account both content and readability of the summary.
    The average performance of systems in 2010 was noticeably better than
    in 2005; systems achieved better focus on average, and many attempted
    to provide greater coherence to their summaries. The overall
    responsiveness metric showed that readability plays an important
    role in the perceived quality of the summaries.
"""


class DUC2010Config(datasets.BuilderConfig):
    """BuilderConfig for DUC2010."""

    def __init__(self, **kwargs):
        """BuilderConfig for DUC2010.
        Args:
          **kwargs: keyword arguments forwarded to super.
        """
        super(DUC2010Config, self).__init__(**kwargs)


class DUC2010(datasets.GeneratorBasedBuilder):
    """DUC2010 (Document Understanding Conferences) Dataset. Version 1.0."""

    BUILDER_CONFIGS = [
        DUC2010Config(
            name="plain_text",
            version=datasets.Version("1.0.0", ""),
            description="Plain text",
        ),
    ]

    _FOLDER = "tac2010"

    def _info(self):
        return datasets.DatasetInfo(
            description=_DESCRIPTION,
            features=datasets.Features(
                {
                    "id": datasets.Value("string"),
                    "title": datasets.Value("string"),
                    "narrative": datasets.Value("string"),
                    "documents": datasets.features.Sequence(
                        {
                            "docname": datasets.Value("string"),
                            "date": datasets.Value("string"),
                            "headline": datasets.Value("string"),
                            "text": datasets.Value("string"),
                        }
                    ),
                    "abstracts": datasets.features.Sequence(
                        {
                            "annotator": datasets.Value("string"),
                            "text": datasets.Value("string"),
                        }
                    )
                }
            ),
            supervised_keys=None,
            homepage="https://www-nlpir.nist.gov/projects/duc/data/2010_data.html",
            citation=_CITATION,
        )

    def _split_generators(self, dl_manager):
        folderpath = dl_manager._base_path

        return [
            datasets.SplitGenerator(
                name='TAU2010', gen_kwargs={"folderpath": folderpath}
            ),
        ]

    def _generate_examples(self, folderpath):
        """Generate DUC2010 Summarization examples."""
        def load_topics():
            # with open(topics_filepath) as f:
            #     topics = f.read()

            # bs_content = BeautifulSoup(topics, 'lxml')
            # nodes = bs_content.find_all('topic')

            #     topics = '<ROOT>{}</ROOT>'.format(f.read())
            # tree = etree.fromstring(topics)
            # nodes = list(tree.xpath('//topic'))

            # topics = {}
            topics = []
            
            abstracts_folderpath = os.path.join(folderpath, 'GuidedSumm2010_test_docs_files')
            for file_name in os.listdir(abstracts_folderpath):
                # filepath = os.path.join(abstracts_folderpath, file_name)
                
                topics.append({
                    'id': str(file_name),
                    'title': '',
                    'narrative': '',
                
                })
            
            
            ## 読み込むsgmlファイルが存在しないので，コメントアウト．
            # for node in nodes:
            #     num = node.find('num').text.strip()
            #     # num = node.xpath('num')[0].text_content().strip()[:-1].lower()
            #     title = node.find('title').text.strip()
            #     # title = node.xpath('title')[0].text_content().strip()
            #     narr = node.find('narr').text.strip()
            #     # narr = node.xpath('narr')[0].text_content().strip()

            #     # Dict version
            #     # topics[num] = {
            #     #     'title': title,
            #     #     'narrative': narr
            #     # }
            #     # List version
            #     topics.append({
            #         'id': num,
            #         'title': title,
            #         'narrative': narr
            #     })

            return topics

        topics = load_topics()
    

        

        
        
        for topic in topics:
            # topic['id']がファイル名になっているので，それをつなげて，
            ## DUC2010\Summ2010_test_docs_files\D0601A\
            ## をdocs_folderpathに格納している．
            tempo=topic['id']+ '-A'
            tempo=str(tempo)
            docs_folderpath = os.path.join(folderpath, 'GuidedSumm2010_test_docs_files',topic['id'],tempo)
            topic['documents'] = []
            topic['abstracts'] = []
            topic['konn']=[]
            # docs_folderpath以下に格納されているファイル名をリストアップして，ひとつづつ呼び出し，
            ## ひとつづつ，filepathに格納している．
            for filepath in os.listdir(docs_folderpath):
                docname = filepath
                
                # ここで，最下層までのフルパスが完成．
                ## 例：DUC2010\Summ2010_test_docs_files\D0601A\APW19990707.0181
                ## これはフルニュース．詳細の情報（原文）が格納されている．
                filepath = os.path.join(docs_folderpath, filepath)
          
                # 日付の切り取り
                date = docname[3:11]
                year, month, day = date[:4], date[4:6], date[6:]
                date = f'{year}-{month}-{day}'

                with open(filepath) as f:
                    doc = f.read()
                    
                # BeautifulSoup を使って、読み込んだファイル内容（HTMLやXML形式のテキスト）を解析し、
                ## 構造化されたデータとして扱えるようにする。
                doc_content = BeautifulSoup(doc, 'lxml')
                # tree = etree.parse(filepath)

                # 読み込んだファイルからタイトル（headline）を取得
                headline_nodes = doc_content.find_all('headline')   
                # hedlineタグない場合に，headerタグを取得する．
                ## strip(): 前後の空白や改行を取り除き、クリーンなテキストにします。
                if len(headline_nodes) != 1:
                    headline_nodes = doc_content.find_all('header')
                
                if not headline_nodes:
                    headline = "No headline found" 
                
                ## headline_nodes[0]は，複数個あった場合の最初のものを取得している．
                headline = headline_nodes[0].text.strip()
                # print(headline)


                text_nodes = doc_content.find_all('text')
                # text_nodes = list(tree.xpath('//text'))
                assert len(text_nodes) == 1
                text = text_nodes[0].text.strip()
                # text = re.sub('\s+', ' ', text)
                # print(text)


                # もともとtopicsは，id,topics,narrativeだけだった．
                topic['documents'].append({
                    'docname': docname,
                    'date': date,
                    'headline': headline,
                    'text': text
                })

## 別のファイルに格納された誰かが書いたものを読みこんで，topicにaddしている．
            abstracts_folderpath = os.path.join(folderpath, 'GuidedSumm2010_eval', 'ROUGE', 'models')
   
            tem = topic['id'][:-1]
           

    
            for filepath in glob.glob(os.path.join(abstracts_folderpath, f'{tem}*')):
                
                abstractname = os.path.basename(filepath)
                
                annotator = abstractname.split('.')[-1]
              
                with open(filepath, encoding='iso-8859-1') as f:
                    text = f.read()
             
                topic['abstracts'].append({
                    'annotator': annotator,
                    'text': text
                })
    
        
            yield topic['id'], topic


#############　金地の付け足した所．実行しようとしている．削除する　################




# # まずは DUC2010 クラスをインスタンス化
# duc2010_instance = DUC2010()

# # フォルダパスの指定（仮のパスを使用）
# folderpath = "C:/Users/Kanaji Rinntarou/Desktop/res_fra/dataset/TAC2010"

# # _generate_examples メソッドを実行し、生成されたデータを取得
# for example_id, example in duc2010_instance._generate_examples(folderpath):
    
#     print(f"ID: {example_id}")
#     print(f"id :  {example['id']}")
    
#     ## title and narrative are none. 
#     print(f"title : {example['title']}")
#     print(f"narrative : {example['narrative']}")

#     print(f"document : {example['documents']}")
#     print(f"Abstract : {example['abstracts']}")

#     break
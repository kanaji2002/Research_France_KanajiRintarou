date|trial|mod
date|jan.3|of
been|2000|mod-before
been|set|pred
case|anadol diallo|nn
set|case|for
officers|four|nn
officers|new york city|nn
officers|police|nn
charged|officers|obj
degree|second|amount-value
murder|degree|nn
charged|murder|with
vendor|22-year-old|mod
vendor|immigrant|nn
vendor|street|nn
murder|vendor|of
vendor|guinea|from
fired|feb 4 , 1999|on
fired|they|subj
fired|41|obj
41|shots|whn
shots|41|of
41|19|num
hit|shots|subj
victim|unarmed|mod
hit|victim|obj
officers|four|nn
officers|kenneth boss|conj
kenneth boss|jean carroll|conj
jean carroll|edward mcmellon|conj
edward mcmellon|and|punc
edward mcmellon|richard murphy|conj
pleaded|officers|subj
guilty|not|mod
pleaded|guilty|desc
pleaded|maintaining|mod
maintaining|officer|subj
maintaining|that|c
thought|they|subj
thought|armed|fc
armed|diallo|obj
attorney|bronx|nn
attorney|district|mod
attorney|robert johnson|person
charged|attorney|subj
intended|officers|subj
intended|take|fc
take|officer|subj
life|diallo|gen
take|life|obj

scientists|monitoring|rel
monitoring|scientist|subj
monitoring|activity|obj
activity|mt|of
st. helens|oct 4|on
explained|st. helens|subj
explained|plume|fc
plume|steam|subj
feet|soaring|mod
feet|1000-2000|nn
plume|feet|obj
crater|volcano|gen
feet|crater|above
crater|result|as
material|hot|mod
result|material|of
material|mountain|in
mountain|contacting|rel
contacting|mountain|subj
water|glacial|mod
contacting|water|obj
water|causing|rel
causing|water|subj
predicted|they|subj
serious|more|mod
eruption|serious|mod
predicted|eruption|obj
morning|next|post
day|fifth|post
day|straight|mod
spat up|day|for
spat up|volcano|subj
cloud|towering|mod
spat up|cloud|obj
cloud|steam|of
steam|and|punc
steam|ash|conj
jacob lowenstern|u.s. geological survey|nn
usgs|(|punc
u.s. geological survey|usgs|abbrev
usgs|)|punc
jacob lowenstern|volcanologist|nn
said|jacob lowenstern|subj
said|activity|obj
last weeks|or|punc
last weeks|months|conj
activity|seismic|mod
diminished|activity|subj
announced|oct 6|on
announced|usgs|subj
announced|mt|obj
was|no|pred
about|longer|mod
no|about|pnmod
about|erupt|fc
erupt|st. helens|subj

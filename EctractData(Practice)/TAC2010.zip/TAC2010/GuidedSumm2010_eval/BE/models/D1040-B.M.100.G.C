trial|robert blake|nn
jury|trial|in
began|jury|subj
began|deliberation|obj
deliberation|march 4 , 2005|on
reviewed|march 9|on
reviewed|jurors|subj
reviewed|testimony|obj
people|three|nn
testimony|people|by
people|who|whn
saw|people|subj
saw|blake|obj
saw|night|mod
night|murder|of
time|only|mod
was|time|pred
time|that|c
asked|jurors|subj
asked|court|obj
court|information|for
information|trial|from
ended|march 15|on
trial|12-month|nn
ended|trial|subj
ended|when|wha
found|after|mod-before
days|nine|amount-value
found|days|after
days|deliberation|of
found|jury|subj
found|blake|obj
guilty|not|mod
blake|guilty|pnmod
guilty|murder|of
of|and|punc
of|in|conj
case|one|nn
of|case|in
case|solicitation|of
11-1|jury|nn
11-1|deadlocked|mod
charge|other|mod
charge|solicitation|nn
11-1|charge|on
charge|which|whn
dismissed|later|mod-before
dismissed|charge|obj
dismissed|judge|subj
thomas nicholson|jury|nn
thomas nicholson|foreman|nn
said|thomas nicholson|subj
said|that|c
was|flimsy|pred

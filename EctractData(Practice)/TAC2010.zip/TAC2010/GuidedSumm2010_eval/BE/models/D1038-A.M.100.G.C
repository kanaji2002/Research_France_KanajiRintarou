state|southwest|mod
state|washington|nn
mount st. helens|state|in
erupted|mount st. helens|subj
erupted|violently|mod
violently|may 18 , 1980|on
may 18 , 1980|killing|rel
killing|may 18, 1980|subj
killing|57people|obj
killing|destroying|mod
homes|200|num
destroying|homes|obj
homes|and|punc
much|coating|nn
homes|much|conj
much|northwest|of
tons|520 million|amount-value
northwest|tons|with
tons|ash|of
activity|seismic|mod
activity|beginning|rel
beginning|activity|subj
beginning|sept 23 , 2004|on
released|activity|subj
energy|more|mod
released|energy|obj
released|than|mod
burped|time|at
time|1980|since
since|and|punc
since|on|conj
since|october 1|on
than|burped|comp1
burped|volcano|subj
column|tall|mod
column|steam|of
steam|and|punc
steam|ash|conj
activity|seismic|mod
ceased|activity|subj
ceased|briefly|mod
ceased|but|punc
ceased|resumed|conj
resumed|activity|obj
warned|oct 2|on
warned|scientists|subj
warned|of|guest
warned|more|of
eruption|serious|mod
warned|eruption|obj
eruption|threatening|rel
threatening|eruption|subj
threatening|life|obj
life|and|punc
life|property|conj
evacuated|officials|subj
miles|observatory|nn
miles|5|amount-value
evacuated|miles|obj
miles|crater|from
evacuated|and|punc
evacuated|moved|conj
moved|officials|subj
tourists|lookout|to
moved|point|fc
point|tourists|subj
point|miles|obj
point|below|mod

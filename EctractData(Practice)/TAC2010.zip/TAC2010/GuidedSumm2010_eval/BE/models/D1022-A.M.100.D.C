opposes|strongly|mod-before
opposes|australia|subj
plan|japan|gen
opposes|plan|obj
plan|increase|rel
increase|plan|subj
kill|its|gen
kill|authorized|mod
increase|kill|obj
kill|whales|of
waters|antarctic|mod
whales|waters|in
meeting|annual|mod
waters|meeting|at
meeting|international whaling commission|of
international whaling commission|opening|rel
opening|international whaling commission|subj
opening|may 30 , 2005|mod
opening|south korea|in
philip ruddock|australian|mod
philip ruddock|attorney general|title
says|philip ruddock|subj
says|lead|fc
lead|australia|subj
effort|diplomatic|mod
lead|effort|obj
effort|have|rel
have|effort|subj
sanctuary|south pacific|nn
sanctuary|whale|nn
have|sanctuary|obj
lead|but|punc
would|not|neg
lead|try|conj
try|australia|subj
try|board|fc
board|australia|subj
ships|japanese|mod
board|ships|obj
john howard|prime minister|title
said|john howard|subj
said|working|fc
working|australia|subj
working|united states|with
united states|new zealand|conj
new zealand|and|punc
new zealand|england|conj
england|convince|rel
convince|england|subj
convince|japan|obj
japan|reconsider|rel
reconsider|japan|subj
proposal|its|gen
reconsider|proposal|obj
believed|japan|obj
believed|have|mod
have|japan|subj
have|votes|obj
votes|get|rel
get|vote|subj
proposal|its|gen
approved|proposal|obj

network|regional|mod
network|telecom|nn
network|which|whn
covers|now|subj
wolong grant panda nature reserve|china|gen
covers|wolong grant panda nature reserve|obj
help|"|punc
will|not|neg
help|only|amod
help|network|subj
help|increase|obj
number|giant pandas|of
giant pandas|but|punc
giant pandas|will|conj
help|also|mod-before
increase|help|rel
help|number|subj
manage|increase|obj1
manage|us|subj
environment|living|mod
manage|environment|obj2
environment|giant pandas|of
giant pandas|"|punc
director|reserve|gen
giant pandas|declared|rel
declared|giant pandas|obj
declared|director|subj
declared|april 3 , 2005|on
announced|may 7|on
announced|that|c
plans|china|nn
plans|build|rel
build|plan|subj
museum|new|mod
museum|giant panda|nn
build|museum|obj
museum|help|rel
help|museum|subj
save|plans|subj
animal|endangered|mod
save|animal|obj
animal|and|punc
habitat|its|gen
animal|habitat|conj
announced|may 10|on
government|southwest sichuan province|nn
announced|government|subj
announced|that|c
closed|it|subj
mines|78|num
closed|mines|obj
polluting|companies|obj
habitat|giant panda|gen
companies|habitat|in

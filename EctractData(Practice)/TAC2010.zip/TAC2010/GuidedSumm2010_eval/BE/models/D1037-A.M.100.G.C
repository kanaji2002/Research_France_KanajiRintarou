oysters|maryland|nn
jewels|shining|mod
oysters|jewels|appo
jewels|chesapeake bay|of
becoming|oysters|subj
species|endangered|mod
haul|annual|mod
haul|2003|in
was|about|pred
bushels|23,000|num
was|bushels|about
bushels|compared|vrel
compared|bushels|obj
compared|80,000|to
80,000|1993 and 2 million|in
maryland|and|punc
maryland|virginia|conj
taken|maryland|subj
taken|steps|obj
steps|protect|rel
protect|step|subj
oysters|native|mod
protect|oysters|obj
protect|but|mod
but|considering|comp1
considering|both|subj
considering|introducing|guest
introducing|both|subj
introducing|chinese|obj
considering|oyster|obj
oyster|replacement|as
grown|optimism|as
optimism|chinese|about
grown|oyster|subj
grown|administration|in
robert ehrlich|gov.|title
administration|robert ehrlich|of
robert ehrlich|(|punc
robert ehrlich|r-md|appo
spread|pessimism|subj
spread|scientists|among
spawned|successfully|amod
spawned|maryland|subj
spawned|and|punc
spawned|raised|conj
raised|maryland|subj
oysters|native|mod
raised|oysters|obj
reserves|managed|mod
oysters|reserves|in
supervision|scientific|mod
reserves|supervision|under
is|slow|pred
slow|and|punc
slow|limited|conj
limited|scope|in

helios|cypriot|mod
helios|airline|nn
flight 522|helios|of
bound|flight 522|subj
bound|athens|for
athens|larnaka cyprus|from
larnaka cyprus|crashed|vrel
crashed|larnaka cyprus|obj
crashed|12:05 p.m.|at
near|august 14 , 2005|subj
town|coastal|mod
near|town|obj
town|grammatikos|of
grammatikos|killing|rel
killing|grammatikos|subj
killing|all|obj
all|121|num
all|including|aboard
children|48|num
children|greek cypriot|nn
including|children|obj
children|and|punc
children|youths|conj
pilots|greek|nn
pilots|air force|nn
reports|pilots|from
pilots|who|whn
intercepted|pilots|subj
airline|doomed|mod
intercepted|airline|obj
suggest|reports|subj
suggest|that|c
loss|catastrophic|mod
pressure|cabin|nn
loss|pressure|of
caused|loss|subj
caused|crash|obj
minister|cyprus|nn
minister|transport|nn
minister|haris thrasou|person
said|minister|subj
said|had|fc
had|plane|subj
had|problems|obj
problems|decompression|with
decompression|past|in
box|plane|gen
box|black|nn
recovered|box|obj
investigation|cause|of
cause|crash|of
is|underway|pred

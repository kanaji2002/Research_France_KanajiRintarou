graduate|18-year-old|mod
graduate|high school|nn
natalee holloway|graduate|appo
graduate|alabama|from
missing|natalee holloway|subj
missing|since|mod
since|was|comp1
was|last|pred
last|seen|vrel
seen|last|obj
seen|leaving|mod
leaving|may 30, 2005|subj
club|oranjestad|nn
club|night|nn
leaving|club|obj
club|aruba|on
suspects|four|nn
are|held|pred
joran van der sloot|17|conj
deepak|brothers|nn
17|deepak|conj
deepak|21|conj
21|and|punc
21|satish kalpoe|conj
satish kalpoe|18|num
suriname|and|punc
suriname|steve gregory croes|conj
searches|extensive|mod
uncovered|searches|subj
uncovered|evidence|obj
van der sloot|and|punc
brothers|kalpoe|nn
van der sloot|brothers|conj
claimed|van der sloot|subj
claimed|left|fc
left|they|subj
left|holloway|obj
hotel|her|gen
holloway|hotel|at
quoted|source|subj
quoted|deepak kalpoe|obj
deepak kalpoe|saying|rel
saying|deepak kalpoe|subj
he|and|punc
brother|his|gen
he|brother|conj
saying|dropped|fc
dropped|he|subj
dropped|off|guest
dropped|holloway|obj
holloway|and|punc
holloway|van der sloot|conj
van der sloot|hotel|at
charged|one|obj

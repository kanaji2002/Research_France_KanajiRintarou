consultant|january 2005|nn
consultant|environmental|mod
petitioned|consultant|in
petitioned|wolf-dieter busch|subj
petitioned|national marine fisheries service|obj
national marine fisheries service|list|rel
list|national marine fisheries service|subj
list|oyster|obj
species|endangered|mod
is|now|pred
experts|12|num
is|experts|with
experts|decision|for
decision|scheduled|pnmod
scheduled|jan 2006|by
oyster|chesapeake bay|nn
population|local|mod
is|population|pred
oyster|eastern|mod
population|oyster|of
does|not|neg
allow|endangered species act|subj
allow|restrictions|obj
invertebrates|specific|mod
invertebrates|area|nn
restrictions|invertebrates|on
allow|so|mod
oysters|all|pre
oysters|new england|from
new england|yucatan|to
so|included|comp1
included|oysters|obj
maryland|and|punc
maryland|virginia|conj
undertaken|maryland|subj
study|environmental|mod
undertaken|study|obj
methods|oyster|nn
methods|restoration|nn
study|methods|of
methods|due|pnmod
due|january|in
maryland|and|punc
maryland|virginia|conj
considering|still|amod
considering|maryland|subj
considering|introducing|guest
introducing|maryland|subj
introducing|chinese|obj
considering|oyster|obj
oyster|chesapeake|to

nervosa|anorexia|nn
disorder|psychological|mod
is|disorder|pred
starves|sufferer|subj
starves|his|obj
his|or|punc
body|her|gen
his|body|conj
body|skin and bones|to
starves|but|punc
wants|still|mod-before
starves|wants|conj
wants|sufferer|subj
wants|lose|fc
lose|sufferer|subj
lose|weight|obj
nervosa|bulimia|nn
disorder|eating|nn
is|disorder|pred
loses|patient|subj
loses|weight|obj
vomiting|forced|mod
weight|vomiting|through
vomiting|eating|after
eating|patient|subj
eating|binge|nn
is|disorder|pred
disorder|that|whn
involves|disorder|subj
much|consuming|mod
involves|much|obj
much|more|pnmod
more|normal|than
period of time|short|mod
normal|period of time|in
all|who|whn
have|all|subj
have|disorder|obj
are|overweight|pred
lobby|insurance|nn
blocked|lobby|subj
blocked|attempts|obj
attempts|have|rel
have|attempt|subj
disorders|eating|nn
have|disorders|obj
disorders|added|vrel
added|disorders|obj
added|list|to
mental illnesses|serious|mod
list|mental illnesses|of
companies|insurance|nn

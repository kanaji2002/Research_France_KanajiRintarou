president|dec 3 , 1998|nn
president|indonesian|mod
president|b.j|person
instructed|habibie|subj
andi m. ghalib|attorney general|title
take|andi m. ghalib|subj
measures|legal|mod
take|measures|obj
measures|soeharto|against
promised|ghalib|subj
promised|complete|fc
complete|ghalib|subj
complete|investigation|obj
wealth|soeharto|gen
wealth|alleged|mod
wealth|ill-gotten|mod
investigation|wealth|into
election|june 1999|nn
wealth|election|before
suffered|july 1999|in
suffered|soeharto|subj
suffered|stroke|obj
said|oct 18|on
attorney general|acting|mod
said|attorney general|subj
investigation|corruption|of
said|discontinued|fc
discontinued|investigation|obj
discontinued|lack|due to
lack|evidence|of
objections|wide|mod
objections|spread|nn
marzuki darusman|incumbent|mod
marzuki darusman|attorney general|title
reopened|marzuki darusman|subj
reopened|case|obj
case|december|in
failed|soeharto|subj
failed|respond|fc
respond|soeharto|subj
respond|summons|to
summons|february|in
february|and|punc
february|march 2000|conj
march 2000|claiming|rel
claiming|march 2000|subj
claiming|illness|obj
summons|third|post
was|promised|pred

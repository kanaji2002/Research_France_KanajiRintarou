ceasefire|reached|vrel
reached|ceasefire|obj
reached|march 18|mod
held on|still|amod
held on|ceasefire|subj
held on|march 22|mod
held on|when|wha
committee|parliamentary|mod
committee|baluchistan|on
left|committee|subj
left|islamabad|obj
nawar akbar bugti|leader|appo
leader|rebels|of
proved|mission|subj
proved|successful|desc
agreed|april 13|on
agreed|bugti|subj
agreed|end|fc
end|bugti|subj
blockade|his|gen
end|blockade|obj
access road|key|mod
blockade|access road|of
access road|dara bugti|to
while|agreed|comp1
agreed|government|subj
agreed|lift|fc
lift|government|subj
checkpoints|its|gen
lift|checkpoints|obj
checkpoints|town|around
elsewhere|baluchistan|in
bombings|railways|of
occurred|bombings|subj
hit|march 25|on
hit|rockets|subj
headquarters|regional|mod
hit|headquarters|obj
headquarters|barakhan|at
claimed|attacks|obj
claimed|by|by-subj
group|shady|mod
claimed|group|by
group|called|vrel
called|group|obj1
called|baluchistan national liberation army|desc

missiles|u.s. tomahawk|nn
struck|missiles|subj
struck|factory|obj
factory|khartoum sudan|in
people|ten|nn
injured|people|obj
was|in|pred
was|retaliation|in
bombing|aug 7|nn
retaliation|bombing|for
embassies|u.s.|nn
bombing|embassies|of
embassies|nairobi|in
nairobi|and|punc
es-salaam|dar|nn
nairobi|es-salaam|conj
authorities|american|mod
claimed|authorities|subj
claimed|that|c
produced|factory|subj
produced|precursors|obj
weapon|deadly|mod
weapon|vx|nn
weapon|chemical|mod
precursors|weapon|for
produced|and|punc
produced|associated|conj
associated|factory|obj
laden|osama|nn
laden|bin|nn
associated|laden|with
insisted|sudanese|subj
insisted|was|fc
was|actually|guest
factory|pharmaceutical|mod
was|factory|pred
connection|bin|nn
connection|laden|nn
factory|connection|with
ambassador|sudan|gen
ambassador|u.n.|nn
said|elfatih mohamed ahmed erwa|subj
said|file|fc
file|he|subj
complaint|formal|mod
file|complaint|obj
president|security council|nn
complaint|president|with
president|danilo turk|appo
danilo turk|aug 21|on

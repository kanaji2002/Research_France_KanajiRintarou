order|dec 16 , 1999|on
panel|five|nn
panel|member|nn
panel|new york supreme court appellate division|of
order|panel|subj
order|that|c
case|diallo|nn
trial|case|of
moved|trial|obj
moved|bronx|from
bronx|albany county|to
moved|ruling|mod
ruling|panel|subj
ruling|that|c
trial|fair|mod
be|impossible|pred
impossible|bronx|in
because of|"|punc
clamor|public|mod
bronx|clamor|because of
attorney|bronx|nn
attorney|district|mod
attorney|robert johnson|person
said|attorney|subj
disagree|"|punc
could|not|neg
said|disagree|fc
disagree|he|subj
strongly|more|mod
disagree|strongly|mod
decision|court|gen
strongly|decision|with
defendants|four|nn
lawyers|defendants|for
argued|lawyers|subj
argued|that|c
publicity|and|punc
demonstrations|public|mod
publicity|demonstrations|conj
tainted|irrevocably|amod
tainted|publicity|subj
pool|jury|nn
tainted|pool|obj
pool|new york city|in
selection|jury|nn
is|now|pred
now|scheduled|pnmod
scheduled|jan 31|for

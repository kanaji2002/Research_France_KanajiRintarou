trial|ft|at
counts|nine|nn
hood|counts|on
counts|including|rel
including|count|subj
including|conspiracy|obj
conspiracy|dereliction|appo
dereliction|duty|of
maltreatment|and|punc
acts|indecent|mod
maltreatment|acts|conj
acts|pleaded|vrel
pleaded|acts|obj
may 2 , 2005|guilty|mod
pleaded|may 2 , 2005|mod
concern|charges|subj
concern|violation|obj
code|uniform|nn
violation|code|of
justice|military|mod
code|justice|of
justice|that|whn
occurred|justice|subj
prison|abu ghraib|nn
occurred|prison|at
prison|baghdad|near
baghdad|fall|in
fall|2003|of
serve|agreement|under
agreement|reached|vrel
reached|agreement|obj
prosecutors|military|mod
reached|prosecutors|with
serve|english|subj
11|less than|num-mod
years|11|amount-value
serve|years|obj
years|prison|in
plea|her|gen
accepted|plea|obj
accepted|by|by-subj
judge|military|mod
accepted|judge|by
james pohl|col.|title
judge|james pohl|appo
jury|military|mod

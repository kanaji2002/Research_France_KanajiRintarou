assailants|masked|mod
assailants|armed|pnmod
launchers|rocket|nn
armed|launchers|with
launchers|and|punc
rifles|m16|nn
launchers|rifles|conj
abducted|assailants|subj
people|20|num
abducted|people|obj
people|beach|from
beach|sipadan island|on
sipadan island|coast|off
coast|sabah|of
side|malaysian|mod
sabah|side|appo
side|borneo island|of
ten|captives|of
tourists|foreign|mod
are|tourists|pred
tourists|and|punc
malaysians|ten|nn
tourists|malaysians|conj
area|resort|nn
malaysians|area|from
area|popular|pnmod
popular|scuba divers|with
forced|gunmen|subj
hostages|their|gen
swim|hostages|subj
boats|two|nn
boats|fishing|nn
swim|boats|to
boats|which|whn
sped|boats|subj
sped|away|mod
waters|philippine|nn
away|waters|toward
group|philippine muslim|nn
group|separatist|mod
group|abu sayyaf|appo
claimed|group|subj
claimed|responsibility|obj
responsibility|abductions|for
claimed|but|mod
but|neither|punc
claim|nor|punc
claim|location|conj
captives|20|num
location|captives|of
but|confirmed|comp1
confirmed|claim|obj

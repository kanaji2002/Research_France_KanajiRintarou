dozens|searches|of
searches|officials|by
officials|and|punc
officials|volunteers|conj
turned|dozens|subj
turned|up|guest
turned|trace|obj
trace|natalee holloway|of
says|now|mod-before
says|joran van der sloot|subj
says|that|c
was|alone|pred
alone|holloway|with
holloway|beach|on
hotel|marriott|nn
beach|hotel|near
was|and|punc
was|left|conj
left|he|subj
left|her|obj
left|there|mod
says|now|mod-before
says|satish kalpoe|subj
he|and|punc
brother|his|gen
he|brother|conj
says|dropped|fc
dropped|he|subj
dropped|off|guest
dropped|holloway|obj
holloway|and|punc
holloway|van der sloot|conj
van der sloot|together|pnmod
together|marriott|at
father|joran|gen
paul van der sloot|father|appo
arrested|paul van der sloot|obj
arrested|and|punc
arrested|held|conj
held|paul van der sloot|subj
days|three|amount-value
held|days|obj
days|suspect|as
held|but|punc
released|then|mod-before
held|released|conj
released|paul van der sloot|obj
brothers|kalpoe|nn
ordered|brothers|obj
released|july 4.|on
remained|july 16|as of
remained|joran van der sloot|subj
remained|custody|in

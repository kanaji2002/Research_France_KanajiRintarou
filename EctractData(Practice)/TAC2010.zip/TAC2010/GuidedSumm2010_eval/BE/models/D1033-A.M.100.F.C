korean|july 25 , 2005|nn
korean|south|mod
called for|korean|on
called for|president roh moo-hyun|subj
investigation|"|punc
investigation|thorough|mod
investigation|"|punc
called for|investigation|obj
investigation|national intelligence service|by
nis|(|punc
national intelligence service|nis|abbrev
nis|)|punc
national intelligence service|allegations|into
allegations|that|c
officials|intelligence|nn
had|officials|subj
had|in|guest
had|1997|in
taped|illegally|mod
conversations|taped|mod
had|conversations|obj
conversations|hong seok-hyun|between
ambassador|south|mod
ambassador|korean|nn
hong seok-hyun|ambassador|conj
ambassador|u.s.|to
u.s.|and|punc
hak-soo|lee|nn
u.s.|hak-soo|conj
ranking|high|mod
official|ranking|mod
hong seok-hyun|official|appo
official|samsung|of
conglomerate|country|gen
business|largest|mod
conglomerate|business|mod
samsung|conglomerate|appo
conversations|recorded|mod
revelation|conversations|of
conversations|involving|rel
involving|conversation|subj
slush fund|illegal|mod
slush fund|political|mod
involving|slush fund|obj
caused|revelation|subj
caused|hong|obj
hong|resign|rel
resign|hong|subj
resign|ambassador|as
released|august 5|on
released|nis|subj
results|interim|mod
released|results|obj
investigation|its|gen
investigation|ongoing|mod
results|investigation|from
investigation|admitting|rel
admitting|investigation|subj
admitting|taped|fc
taped|it|subj
figures|influential|mod
taped|figures|obj
figures|as|mod
late|2002|as
as|but|punc
as|not|punc
as|under|conj
administration|president|gen
president|roh|person
as|administration|under

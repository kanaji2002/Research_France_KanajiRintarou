plant|petrochemical|nn
explosion|plant|at
plant|songhua river|on
china|northeast|mod
songhua river|china|in
china|nov 13 , 2005|on
threatened|explosion|subj
pollution|toxic|mod
pollution|benzene|nn
threatened|pollution|obj
water|drinking|nn
pollution|water|of
water|harbin|of
3.8 million|urban|mod
3.8 million|population|nn
harbin|3.8 million|appo
is|tributary|pred
river|heilong|nn
river|(|punc
river|russian amur|nn
river|)|punc
tributary|river|of
border|russian|mod
river|border|on
authorities|russian|mod
keep|authorities|obj
authorities|informed|pnmod
informed|movement|of
block|benzene-polluted|mod
movement|block|of
cut off|harbin|subj
supply|its|gen
supply|urban|mod
supply|water|nn
cut off|supply|obj
cut off|nov 23|mod
advised|populace|obj
advised|avoid|mod
avoid|populace|subj
contact|all|pre
avoid|contact|obj
contact|pollution|with
discharge|water|nn
reservoirs|two|nn
discharge|reservoirs|from
increased|discharge|obj
increased|dilute|mod
dilute|discharge|subj
slick|massive|mod
dilute|slick|obj
slick|pollutants|of
investigating|authorities|subj
responsibility|criminal|mod
investigating|responsibility|obj
responsibility|catastrophe|for

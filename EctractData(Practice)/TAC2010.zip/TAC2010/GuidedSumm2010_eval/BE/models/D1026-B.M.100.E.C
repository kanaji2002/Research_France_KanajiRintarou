rate|mortality|nn
patients|motorcycle|nn
patients|crash|nn
rate|patients|of
remained|rate|subj
remained|about 5 percent|at
years|recent|mod
about 5 percent|years|in
about 5 percent|most|with
most|dying|pnmod
hours|first 24|amount-value
dying|hours|in
injuries|head|mod
hours|injuries|from
been|increase|pred
usage|helmet|nn
increase|usage|in
usage|30%|from
30%|48%|to
states|u.s.|in
washington|only|mod
washington|d.c.|conj
d.c.|and|punc
d.c.|20|conj
states|washington|subj
helmets|mandate|nn
helmets|motorcycle|nn
states|helmets|obj
complain|opponents|subj
complain|that|c
laws|such|pre
violate|laws|subj
freedom|personal|mod
violate|freedom|obj

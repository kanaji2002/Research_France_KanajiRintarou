announced|june 1 , 1998|on
attorney general|indonesian|mod
announced|attorney general|subj
announced|investigation|obj
investigation|wealth|into
president|former|mod
wealth|president|of
president|soeharto|person
president|and|punc
family|his|gen
president|family|conj
reported|indonesian data center|subj
assets|soeharto|nn
assets|family|nn
reported|assets|obj
assets|about u.s. $17.5 billion|of
announced|sept 21|on
announced|that|c
set up|government|subj
teams|two|nn
set up|teams|obj
teams|investigate|rel
investigate|team|subj
corruption|soeharto|gen
investigate|corruption|obj
corruption|as|punc
corruption|well|punc
corruption|as|punc
wealth|his|gen
corruption|wealth|conj
17 one|teams|of
announced|17 one|subj
announced|that|c
wealth|soeharto|gen
wealth|ill-gotten|mod
evidence|wealth|of
including|evidence|subj
including|land|obj
land|factories|conj
factories|and|punc
factories|u.s. $2.3 million|conj
accounts|personal|mod
accounts|savings|nn
u.s. $2.3 million|accounts|in
took place|nov 19|on
demonstration|anti-soeharto|mod
demonstration|mass|nn
took place|demonstration|subj
capital|indonesia|gen
took place|capital|in
capital|jakarta|of

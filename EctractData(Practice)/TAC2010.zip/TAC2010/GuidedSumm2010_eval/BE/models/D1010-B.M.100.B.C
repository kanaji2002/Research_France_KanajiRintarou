college|university|nn
research|college|at
suggests|london|subj
suggests|that|c
susceptibility|individual|gen
susceptibility|vcjd|to
varies|susceptibility|subj
makeup|genetic|mod
varies|makeup|with
government|u.s.|nn
announced|government|subj
announced|in|guest
announced|march 2005|in
announced|that|c
add|it|subj
$2million|$4.7 million|to
budgeted for|already|mod-before
add|budgeted for|fc
budgeted for|$2million|subj
research|bse|nn
budgeted for|research|obj
new|meanwhile|mod
cases|new|mod
cases|bse|of
appear|cases|subj
restrictions|import|nn
persist|restrictions|subj
case|new|mod
case|spain|in
raised|case|subj
raised|total|obj
total|20|to
20|2000|since
goat|slaughtered|vrel
slaughtered|goat|obj
slaughtered|2002|in
slaughtered|france|in
tested|goat|subj
tested|positive|obj
positive|bse|for
victim|first|post
victim|known|mod
victim|non-bovine|mod
bse|victim|appo
ban|japan|gen
imports|u.s.|nn
imports|beef|nn
ban|imports|on
continues|ban|subj
continues|does|as
does|ban|rel
ban|does|obj
ban|u.s.|subj
beef|canada|gen
ban|beef|on

is|underway|pred
underway|africa|in
africa|asia|conj
asia|and|punc
asia|south america|conj
south america|protect|rel
protect|south america|subj
protect|tropical rain forest|obj
tropical rain forest|threatened|vrel
threatened|tropical rain forest|obj
threatened|by|by-subj
cutting|excessive|mod
threatened|cutting|by
set up|china|in
set up|government|subj
zone|tropical|mod
zone|primary|mod
protective|forest|mod
zone|protective|mod
set up|zone|obj
province|hainan|nn
zone|province|in
province|1951|in
decided|1993|in
government|hainan|nn
government|provincial|mod
decided|government|subj
decided|stop|fc
stop|government|subj
tree|commercial|mod
stop|tree|obj
tree|felling|rel
felling|tree|subj
felling|area|in
province|yunnan|nn
stopped|province|subj
stopped|building|mod
building|province|subj
factories|sugar|nn
building|factories|obj
region|xishuangbanna|nn
factories|region|in
region|preserve|rel
preserve|region|subj
preserve|tropical rain forest|obj
preserve|removed|conj
removed|region|subj
farmers|itinerant|mod
removed|farmers|obj
forest|rain|nn
farmers|forest|from
removed|and|punc
removed|settled|conj
settled|region|subj
settled|them|obj
settled|elsewhere|mod
settled|and|punc
settled|formed|conj
formed|region|subj
formed|team|obj
patrolmen|armed|mod
team|patrolmen|of
patrolmen|discourage|rel
discourage|patrolmen|subj
discourage|poaching|obj

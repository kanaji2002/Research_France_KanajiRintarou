raided|aug 28|on
raided|prosecutors|subj
offices|phone|nn
raided|offices|obj
offices|seoul|across
seoul|looking|rel
looking|seoul|subj
looking|evidence|for
arrested|nov 15|on
arrested|authorities|subj
chiefs lin dong-won|former|mod
chiefs lin dong-won|nis|nn
arrested|chiefs lin dong-won|obj
chiefs lin dong-won|and|punc
chiefs lin dong-won|shin gunn|conj
directing|authority|subj
directing|spying|obj
individuals|high-profile|mod
spying|individuals|on
deputy|shin|gen
committed|deputy|subj
committed|suicide|obj
suicide|nov 20|on
indicted|dec 2|on
lin|and|punc
lin|shin|conj
indicted|lin|obj
supervising|lin|subj
taps|illegal|mod
taps|phone|nn
supervising|taps|obj
cleared|dec.14|on
cleared|prosecutors|subj
executives|two|nn
executives|samsung|nn
cleared|executives|obj
executives|and|punc
ambassador|former|mod
executives|ambassador|conj
ambassador|hong|person
ambassador|charges|of
charges|arising|rel
arising|charge|subj
conversations|their|gen
conversations|taped|mod
arising|conversations|from
indicted|they|subj
lee|tv|nn
lee|journalist|nn
indicted|lee|obj
revealed|who|subj
revealed|tapes|obj
revealed|violation|on
laws|privacy|nn
violation|laws|of

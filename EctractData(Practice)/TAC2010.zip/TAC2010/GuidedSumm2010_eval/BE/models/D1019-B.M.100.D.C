mercado|2000 philippine defense secretary|nn
confirmed|mercado|subj
location|hostages|gen
confirmed|location|obj
location|sula province|in
participated|abu sayyaf|subj
participated|abduction|in
president|joseph estrada|person
appointed|president|subj
appointed|nur misuari|obj
nur misuari|governor|appo
governor|autonomous region|of
autonomous region|muslim mindanao|in
negotiator|government|gen
appointed|negotiator|as
negotiator|kidnappers|with
kidnappers|who|whn
demanding|kidnappers|subj
demanding|u.s. $2.4 million|obj
u.s. $2.4 million|ransom|in
rejected|abu sayyaf|subj
rejected|nur misuari|obj
rejected|and|punc
rejected|threatened|conj
threatened|abu sayyaf|subj
threatened|behead|mod
behead|abu sayyaf|subj
behead|some|obj
some|hostages|of
visited|may 1|on
doctor|and|punc
doctor|journalists|conj
visited|doctor|subj
visited|hostages|obj
hut|bamboo|mod
hostages|hut|at
hut|hills|in
hills|jolo island|of
suffering|they|subj
suffering|hunger|from
hunger|and|punc
hunger|diarrhea|conj

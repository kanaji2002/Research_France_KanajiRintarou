disease|mad|mod
disease|cow|nn
disease|or|punc
disease|bovine spongiform encephalopathy|conj
bse|(|punc
bovine spongiform encephalopathy|bse|abbrev
bse|)|punc
eats|disease|subj
eats|holes|obj
holes|brains|in
brains|cattle|of
form|human|mod
form|disease|of
disease|variant creutzfeldt-jakob disease|appo
vcjd|(|punc
variant creutzfeldt-jakob disease|vcjd|abbrev
vcjd|)|punc
variant creutzfeldt-jakob disease|which|whn
caught|variant creutzfeldt-jakob disease|obj
products|beef|nn
eating|products|obj
products|cattle|from
cattle|bse|with
change|causes|nn
change|personality|nn
bse|change|conj
change|loss|conj
functions|body|nn
loss|functions|of
deterioration|brain|nn
functions|deterioration|conj
deterioration|and|punc
deterioration|death|conj
first|identified|vrel
identified|first|obj
identified|britain|in
britain|1996|in
been|there|mod-before
cases|147|num
been|cases|pred
been|there|mod
testing|widespread|mod
testing|and|punc
testing|destruction|conj
destruction|cattle|of
cattle|and|punc
cattle|bans|conj
imports|beef|nn
bans|imports|on
imposed|testing|obj
imposed|countries|in
countries|world|around
britain|u.s.|appo
u.s.|canada|appo
canada|eu|appo
japan|and|punc
japan|taiwan|conj

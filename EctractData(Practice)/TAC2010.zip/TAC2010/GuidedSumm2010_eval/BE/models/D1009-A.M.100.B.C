jonbenet ramsey|six-year-old|mod
found|jonbenet ramsey|obj1
found|beaten|desc
found|and|punc
found|strangled|conj
strangled|jonbenet ramsey|obj
strangled|dec 26 , 1996|on
home|her|gen
strangled|home|in
home|boulder|in
charged|one|obj
charged|case|in
charged|although|mod
although|both|punc
attorney|boulder|gen
attorney|district|nn
alex hunter|attorney|conj
attorney|and|punc
attorney|mark beckner|conj
chief|boulder|gen
chief|police|nn
alex hunter|chief|appo
although|said|comp1
said|alex hunter|subj
parents|jonbenet|gen
said|parents|obj
parents|john|conj
john|and|punc
john|patsy ramsey|conj
said|fall|mod
under|"|punc
said|umbrella|under
umbrella|suspicion|of
attorney|ramseys|gen
attorney|hal haddon|appo
said|attorney|subj
said|that|c
trust|they|subj
police|boulder|nn
trust|police|obj
district|sept 15 , 1998|nn
took|district|on
attorney|hunter|person
took|attorney|subj
took|case|obj
jury|grand|nn
case|jury|before

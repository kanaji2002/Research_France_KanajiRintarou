it|(|punc
identity theft "|it|abbrev
it|)|punc
stealing|identity theft "|subj
social security number|someone|gen
stealing|social security number|obj
numbers|credit card|nn
identifiers|other|mod
numbers|identifiers|of
using|them|obj
using|gain|mod
credit|fraudulent|mod
gain|credit|obj
is|one|pred
growing|fastest|mod
crimes|growing|mod
one|crimes|of
crimes|world|in
estimated|that|c
up|350,000|to
victimized|people|obj
victimized|by|by-subj
victimized|it|by
victimized|year|mod
estimates|secret service|subj
estimates|that|c
cost|it|subj
$750 million|citizens|nn
cost|$750 million|obj
$750 million|1997|in
cost|up|mod
up|$450 million|from
$450 million|1996|in
signed|october 1998|in
signed|president|subj
signed|into|guest
signed|law|into
theft|identity|nn
signed|theft|obj
theft|and|punc
theft|assumption deterrence act|conj
assumption deterrence act|1998|of
1998|making|rel
making|1998|subj
making|it|obj1
making|felony|desc
felony|punishable|pnmod
15|up to|num-mod
years|15|amount-value
punishable|years|by
years|prison|in

charged|1999|in
individuals|1,350|num
charged|individuals|obj
theft|identity|nn
charged|theft|under
theft|and|punc
theft|assumption deterrence act|conj
sentenced|644|obj
entered|407|subj
pleas|guilty|mod
entered|pleas|obj
hotline|established|vrel
established|hotline|obj
established|by|by-subj
established|federal trade commission|by
federal trade commission|1999|in
received|hotline|subj
400|about|num-mod
calls|400|nn
received|calls|obj
calls|week|per
company|insurance|nn
offering|now|guest
offering|company|subj
offering|policy|obj1
policy|covering|rel
covering|policy|subj
covering|some|obj
some|expenses|of
expenses|incurred|vrel
incurred|expenses|obj
incurred|by|by-subj
incurred|it|by
offering|victims|obj2
increased|it|as
increased|cases|subj
have|so|mod-before
have|sales|obj
sales|shredders|of
100,000|about|mod
shredders|100,000|from
100,000|1990 to 9 million|in
1990 to 9 million|1998|in
use|widespread|mod
use|social security numbers|of
identification|national|mod
social security numbers|identification|as
calls for|use|subj
legislation|corrective|mod
calls for|legislation|obj

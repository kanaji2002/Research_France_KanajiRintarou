group|high|mod
group|level|nn
group|chinese|nn
group|work|nn
left|group|subj
left|beijing|obj
beijing|nov 26|on
nov 26|investigate|rel
investigate|nov 26|subj
pollution|songhua river|nn
investigate|pollution|obj
official|senior|mod
official|state environmental protection administration|of
said|official|subj
jilin petrochemical company|where|whn
explosion|occurred|vrel
occurred|explosion|obj
occurred|nov 13|on
said|held|fc
held|jilin petrochemical company|subj
held|responsible|desc
informed|china|subj
informed|united nations|obj
united nations|area|of
area|pollution|of
informed|and|punc
informed|apologized|conj
apologized|china|obj
apologized|russia|to
effects|its|gen
russia|effects|for
apologized|there|mod
russian|high|mod
official|russian|mod
visited|official|subj
visited|khabarovsk|obj
khabarovsk|prepare for|rel
prepare for|khabarovsk|subj
prepare for|arrival|obj
arrival|nitrobenzene|of
there|slick|mod
prepare for|there|mod
prepare for|dec.8|about
side|positive|mod
focused|side|on
catastrophe|songhua river|nn
focused|catastrophe|subj
attention|chinese|nn
attention|public|mod
focused|attention|obj
protection|environmental|mod
attention|protection|on

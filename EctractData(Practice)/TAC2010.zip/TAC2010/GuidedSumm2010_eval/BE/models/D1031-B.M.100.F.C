conference|un-sponsored|mod
conference|paris|in
opened|conference|subj
opened|jan 24 , 2005|obj
jan 24 , 2005|draw|rel
draw|jan 24, 2005|subj
lessons|environmental|mod
draw|lessons|obj
lessons|learned|vrel
learned|lessons|obj
tsunami|dec 26|nn
learned|tsunami|from
said|speakers|subj
said|that|c
coastlines|vulnerable|pnmod
vulnerable|tsunamis|to
nurture|coastlines|subj
coral reefs|healthy|mod
nurture|coral reefs|obj
coral reefs|beds|conj
grass|sea|mod
beds|grass|of
grass|and|punc
swamps|mangrove|nn
grass|swamps|conj
buffers|natural|mod
coral reefs|buffers|appo
waves|killer|nn
buffers|waves|against
toll|death|nn
toll|more|of
more|227,000|than
was|due|pred
due|part|in
destruction|earlier|mod
part|destruction|to
destruction|buffers|of
are|now|guest
are|planning|pred
planning|plant|rel
plant|planning|subj
plant|mangroves|obj
mangroves|protection|as
protection|tidal waves|against
attributed|myanmar|subj
escape|its|gen
attributed|escape|obj
damage|serious|mod
damage|tsunami|nn
escape|damage|from
mangroves|unspoiled|mod
part|mangroves|due to
mangroves|and|punc
islands|coral|mod
mangroves|islands|conj

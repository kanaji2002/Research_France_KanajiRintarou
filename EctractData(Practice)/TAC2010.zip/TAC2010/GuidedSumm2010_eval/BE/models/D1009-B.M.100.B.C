received|march 23 , 1999|on
jury|grand|nn
jury|investigating|rel
investigating|jury|subj
slaying|jonbenet ramsey|nn
investigating|slaying|obj
received|jury|subj
received|funding|obj
months|three|amount-value
more|months|nn
funding|more|for
more|operation|of
granted|april 8|on
jury|grand|nn
granted|jury|obj1
granted|extension|obj2
extension|oct 20|until
identified|only|amod
although|identified|comp1
identified|prosecutors|subj
identified|parents|obj
identified|as|mod
suggest|suspicion|under
material|unidentified|mod
material|dna|nn
suspicion|material|conj
underwear|jonbenet|gen
material|underwear|in
underwear|and|punc
print|shoe|nn
underwear|print|conj
print|found|vrel
near|print|subj
as|suggest|comp1
suggest|body|subj
suggest|possibility|obj
possibility|intruder|of
jury|grand|nn
year|jury|after
began|year|subj
began|looking at|mod
looking at|year|subj
looking at|case|obj
is|there|mod-before
is|indication|pred
indication|is|comp1
is|any|pred
any|closer|pnmod
closer|resolution|to

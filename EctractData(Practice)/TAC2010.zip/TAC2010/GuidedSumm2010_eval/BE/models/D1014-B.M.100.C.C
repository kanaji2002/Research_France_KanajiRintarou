defined|obesity|obj
defined|clinically|mod
being|20%|pred
20%|heavier|pnmod
weight|one|nn
weight|ideal|mod
heavier|weight|than
about 33%|1997|num
is|about 33%|in
about 33%|u.s.|of
is|overweight|pred
overweight|compared|vrel
compared|overweight|obj
compared|25%|to
25%|1960 's|in
contributes to|obesity|subj
contributes to|over|guest
contributes to|300,000|over
each|excess|mod
each|deaths|nn
contributes to|each|obj
contributes to|year|mod
contributes to|and|punc
contributes to|is|conj
is|after|guest
is|smoking|after
cause|second|post
cause|leading|mod
is|cause|pred
deaths|preventable|mod
cause|deaths|of
deaths|u.s.|in
u.s.|fight|rel
fight|u.s.|subj
fight|obesity|obj
recognized|it|obj
problem|serious|mod
problem|public|mod
problem|health|nn
recognized|problem|as
educated|consumers|obj
educated|eat|mod
eat|consumer|subj
eat|balanced diet|obj
schedule|schools|subj
physical|more|mod
activity|physical|mod
schedule|activity|obj
schedule|and|punc
schedule|encourage|conj
encourage|schools|subj
encourage|children|obj
children|eat|rel
eat|child|subj
calorie|low|mod
eat|calorie|obj
foods|low-fat|mod
calorie|foods|appo

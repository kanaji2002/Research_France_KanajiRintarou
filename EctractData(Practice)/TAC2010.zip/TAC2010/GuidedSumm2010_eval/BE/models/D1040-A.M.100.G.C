actor|robert blake|person
is|on|pred
is|trial|on
trial|van nuys superior court|in
van nuys superior court|charged|pnmod
charged|murder|with
bonnie lee bakley|his|gen
bonnie lee bakley|wife|nn
murder|bonnie lee bakley|of
counts|2001 and two|subj
counts|solicitation|of
solicitation|murder|of
attorney|deputy|nn
deputy|los angeles county district|person
prosecutor|attorney|appo
attorney|shelly l. samuels|person
stuntmen|two|nn
heavily|stuntmen|on
stuntmen|who|whn
claim|stuntmen|subj
solicited|blake|subj
solicited|them|obj
solicited|kill|mod
kill|blake|subj
wife|his|gen
kill|wife|obj
pleaded|blake|subj
guilty|not|mod
pleaded|guilty|desc
lawyer|his|gen
lawyer|m. gerald schwartzbach|appo
emphasized|lawyer|subj
emphasized|lack|obj
lack|evidence|of
evidence|blake|against
competence|l.a|of
investigation|department|nn
believability|stuntmen|of
arguments|closing|mod
arguments|trial|in
ended|arguments|subj
ended|march 4 , 2005|mod

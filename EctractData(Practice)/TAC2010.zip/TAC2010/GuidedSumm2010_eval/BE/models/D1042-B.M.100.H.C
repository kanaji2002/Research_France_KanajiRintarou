phase|sentencing|mod
trial|england|gen
phase|trial|of
began|phase|subj
began|may 3 , 2005|on
tossed|may 4|on
tossed|abruptly|amod
tossed|judge|subj
tossed|out|guest
plea|england|gen
plea|guilty|mod
tossed|plea|obj
tossed|declared|conj
declared|judge|subj
declared|mistrial|obj
declared|dismissed|conj
dismissed|judge|subj
dismissed|jury|obj
dismissed|and|punc
dismissed|referred|conj
referred|judge|subj
referred|matters|obj
thomas f. metz|lt.|nn
thomas f. metz|gen.|title
matters|thomas f. metz|to
thomas f. metz|ft|appo
commander|hood|gen
said|judge|subj
said|defense|obj
testimony|that|c
did|not|neg
know|england|subj
know|doing|fc
doing|what|obj
doing|she|subj
was|wrong|pred
plead|you|subj
plead|guilty|desc
plead|and|punc
say|then|mod-before
plead|say|conj
say|you|subj
say|you|obj
chris graveline|capt.|title
prosecutors|chris graveline|conj
chris graveline|and|punc
chuck neill|capt.|title
chris graveline|chuck neill|conj
chuck neill|and|punc
lawyers|defense|nn
chuck neill|lawyers|conj
jonathan crisp|capt.|title
lawyers|jonathan crisp|conj
jonathan crisp|and|punc
jonathan crisp|rich hernandez|conj
rich hernandez|made|vrel
made|rich hernandez|obj1
comment|public|mod
made|comment|desc
drop|metz|subj
drop|charges|obj
drop|refer|conj
refer|metz|subj
refer|them|obj
refer|hearing|to
refer|or|punc
refer|recommend|conj
recommend|metz|subj
punishment|non-judicial|mod
recommend|punishment|obj

On Dec. 16, 1999 the five member panel of the New York Supreme Court Appellate Division order that the trial of the Diallo case be moved from the Bronx to Albany County, ruling that a fair trial would be impossible in the Bronx because of "the public clamor".
Bronx District Attorney Robert Johnson said he "could not disagree more strongly with the Court's decision".
Lawyers for the four defendants argued that publicity and public demonstrations had irrevocably tainted the jury pool in New York City.
Jury selection is now scheduled for Jan. 31.

On June 1, 1998 the Indonesian Attorney General announced an investigation into the wealth of former President Soeharto and his family.
The Indonesian Data Center reported Soeharto family assets of about U.S. $17.5 billion.
On Sept 21 it was announced that the government had set up two teams to investigate Soeharto's corruption as well as his wealth.
On Nov. 17 one of the teams announced that evidence of Soeharto's ill-gotten wealth had been found including land, factories, and U.S. $2.3 million in personal savings accounts.
On Nov. 19 an anti-Soeharto mass demonstration took place in Indonesia's capital of Jakarta.

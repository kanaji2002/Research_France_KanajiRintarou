Natalee Holloway, an 18-year-old high school graduate from Alabama, missing since early May 30, 2005 was last seen leaving an Oranjestad night club on Aruba.
Four suspects are being held: Joran Van Der Sloot, 17, brothers Deepak, 21, and Satish Kalpoe, 18, from Suriname, and Steve Gregory Croes, 26, a disc jockey.
Extensive searches uncovered no evidence.
Van Der Sloot and the Kalpoe brothers claimed they left Holloway at her hotel.
Another source quoted Deepak Kalpoe saying he and his brother dropped off Holloway and Van Der Sloot at another hotel.
No one has been charged.

Progress is underway in Africa, Asia and South America to protect tropical rain forest threatened by excessive cutting.
In China the government set up a tropical primary forest protective zone in Hainan province in 1951.
In 1993 the Hainan provincial government decided to stop commercial tree felling in the area.
Yunnan province stopped building sugar factories in the Xishuangbanna region to preserve tropical rain forest, removed itinerant farmers from the rain forest and settled them elsewhere, and have formed a team of armed patrolmen to discourage poaching and illegal lumbering.

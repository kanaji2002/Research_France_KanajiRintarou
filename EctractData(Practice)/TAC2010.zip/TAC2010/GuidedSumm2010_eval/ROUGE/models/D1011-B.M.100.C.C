Research on eating disorders continues to test drugs for effectiveness but the standard treatment remains prolonged psychotherapy.
A study of genetic links to anorexia, which has the highest death rate of any psychiatric illness, has been funded with a $10 million grant from the National Institute of Mental Health.
Web-sites now feature a cult-like pro-Ana group which promotes weight loss.
Some large web servers like Yahoo have removed sites that promote eating disorders.
Despite attempts to limit Ana's online presence, it has now grown to include followers (many of them young) in many parts of the world.

On Aug. 28 prosecutors raided phone offices across Seoul looking for evidence.
On Nov. 15 authorities arrested former NIS Chiefs Lin Dong-won and Shin Gunn, for directing spying on high-profile individuals.
Both denied directing or approving illegal eavesdropping.
Shin's deputy committed suicide on Nov. 20.
On Dec. 2 Lin and Shin were indicted for supervising illegal phone taps.
On Dec.14 prosecutors cleared two Samsung executives and former Ambassador Hong of any charges arising from their taped conversations; however they indicted TV journalist Lee Sang-ho who originally revealed the tapes, on violation of privacy laws.

A high level Chinese work group left Beijing on Nov. 26 to investigate Songhua River pollution.
A senior official of the State Environmental Protection Administration said the Jilin Petrochemical Company where the explosion occurred on Nov. 13 should be held responsible.
China informed the United Nations of the area of pollution and apologized to Russia for its effects there.
A high Russian official visited Khabarovsk to prepare for arrival of the nitrobenzene slick there about Dec.8.
On the positive side the Songhua River catastrophe has focused Chinese public attention on environmental protection.

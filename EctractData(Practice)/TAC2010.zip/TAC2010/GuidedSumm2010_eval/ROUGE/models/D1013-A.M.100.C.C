"Identity Theft" (IT) is stealing someone's Social Security number, credit card numbers of other identifiers and using them to gain fraudulent credit.
It is one of the fastest growing crimes in the world.
It is estimated that up to 350,000 people are victimized by IT each year.
The Secret Service estimates that IT cost citizens $750 million in 1997 up from $450 million in 1996.
In October 1998 the President signed into law the Identity Theft and Assumption Deterrence Act of 1998 making IT a felony punishable by up to 15 years in prison.

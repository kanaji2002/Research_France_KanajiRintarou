Australia strongly opposes Japan's plan to increase its authorized kill of whales in Antarctic waters at the annual meeting of the International Whaling Commission opening May 30, 2005 in South Korea.
Australian Attorney General Philip Ruddock says Australia would lead a diplomatic effort to have a South Pacific whale sanctuary, but would not try to board Japanese ships.
Prime Minister John Howard said Australia was working with the United States, New Zealand and England to convince Japan to reconsider its proposal.
Japan is believed to have the votes to get its proposal approved.

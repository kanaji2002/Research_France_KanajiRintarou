Healthy tropical rain forests not only prevent erosion and water pollution and act as a natural "sink" for the carbon-based gases that contribute to global warming.
They also harbor plant and animal species with enormous untapped benefits for human health.
But more than half of the world's original tropical forests have disappeared.
Causes of destruction of tropical rain forest include fire, indigenous people clearing land to farm, and companies clearing land for plantation, lumbering or mining.
Despite some protective measures, the rate of destruction is increasing.

In advance of the June 2005 meeting of the International Whaling Commission in Ulsan, South Korea, the United States informed Japan through diplomatic channels that any move to increase the number or type of whales killed would be unacceptable.
On June 19 Japan announced that it intended to almost double its catch of minke whales from 440 to 850 and to enlarge the cull to include the endangered fin and humpback whales.
On June 22 the commission voted 30 to 27 urging Japan to drop its plan.
Japan says it is considering leaving the commission.

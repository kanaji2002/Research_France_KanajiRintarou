The giant panda is one of the world's most endangered species with about 1500 living in the wild in China.
Destruction of natural forest has been countered by government creation of nature preserves and genetic research programs, but starvation remains a threat.
The panda's preferred diet, arrow bamboo, flowers at the end of its life, then seeds and dies with replacement growth taking ten years.
Programs to reseed arrow bamboo and move giant pandas have prevented extinction, but poachers, mining and logging continue to threaten.

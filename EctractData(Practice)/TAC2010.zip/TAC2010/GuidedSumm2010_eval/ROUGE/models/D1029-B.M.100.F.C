A ceasefire reached March 18, still held on March 22 when the parliamentary committee on Baluchistan left Islamabad to negotiate with Nawar Akbar Bugti, leader of the rebels.
The mission proved successful and on April 13 Bugti agreed to end his blockade of the key access road to Dara Bugti while the government agreed to lift its checkpoints around the town.
Elsewhere in Baluchistan, however, several bombings of railways occurred and on March 25 rockets hit the regional headquarters at Barakhan.
These attacks were claimed by a shady group called the Baluchistan National Liberation Army.

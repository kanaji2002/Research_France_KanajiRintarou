Autopsies of the Helios crash victims have established that people on the plane were alive when the plane crashed but may have been unconscious.
Official determination of how they died will be made after the plane's "black box" voice and data recorders are examined.
Both recorders have been sent to France for analysis.
The plane may have suffered a sudden loss of cabin pressure aggravated by a switch left in the wrong position.
On September 16, Chief Investigator Akrivos Tsozakis promised a preliminary report "within days".
A full report is expected in about 5 months.

Actor Robert Blake is on trial in Van Nuys Superior Court charged with murder of his wife Bonnie Lee Bakley on May 4, 2001 and two counts of solicitation of murder.
The prosecutor, Deputy Los Angeles County District Attorney Shelly L. Samuels, has relied heavily on two stuntmen who claim Blake solicited them to kill his wife.
Blake has pleaded not guilty.
His lawyer, M. Gerald Schwartzbach, has emphasized the lack of evidence against Blake, attacked the competence of the L.A.
Police Department investigation and demeaned the believability of the stuntmen.
Closing arguments in the trial ended March 4, 2005.

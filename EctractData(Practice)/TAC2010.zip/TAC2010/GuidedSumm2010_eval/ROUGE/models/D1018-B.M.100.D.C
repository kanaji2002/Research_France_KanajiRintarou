Dozens of searches by officials and volunteers have turned up no trace of Natalee Holloway.
Joran Van Der Sloot now says that he was alone with Holloway on the beach near the Marriott Hotel and left her there.
Satish Kalpoe now says he and his brother dropped off Holloway and Van Der Sloot together at the Marriott.
Paul Van Der Sloot, Joran's father, was arrested and held three days as a suspect, but then released.
The Kalpoe brothers were ordered released on July 4.
As of July 16 only Joran Van Der Sloot remained in custody.

On August 20, 1998 six U.S. Tomahawk missiles struck a factory in Khartoum Sudan.
Ten people were injured, 4 critically.
The attack was in retaliation for the Aug. 7 bombing of U.S. embassies in Nairobi and Dar es-Salaam.
American authorities claimed that the factory produced precursors for the deadly VX chemical weapon and was associated with Osama bin Laden.
Sudanese insisted it was actually a pharmaceutical factory with no bin Laden connection.
Sudan's U.N. ambassador, Elfatih Mohamed Ahmed Erwa said he would file a formal complaint with the Security Council President, Danilo Turk on Aug. 21.

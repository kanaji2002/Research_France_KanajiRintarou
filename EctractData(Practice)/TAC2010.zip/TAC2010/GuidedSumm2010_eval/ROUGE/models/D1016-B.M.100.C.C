On Dec. 3, 1998 Indonesian President B.J.
Habibie instructed Attorney General Andi M. Ghalib to take legal measures against Soeharto.
Ghalib promised to complete investigation into Soeharto's alleged ill-gotten wealth before the June 1999 election.
In July 1999 Soeharto suffered a stroke.
On Oct. 18 the acting Attorney General said the investigation of corruption would be discontinued due to lack of evidence.
After wide spread objections the incumbent Attorney General Marzuki Darusman reopened the case in December.
Soeharto failed to respond to summons in February and March 2000 claiming illness.
A third summons was promised.

Research at University College, London suggests that an individual's susceptibility to vCJD varies with genetic makeup.
The U.S. government announced in March 2005 that it would add $2million to the $4.7 million already budgeted for BSE research.
Meanwhile new cases of BSE appear and import restrictions persist.
A new case in Spain raised the total to 20 since 2000.
A goat slaughtered in 2002 in France tested positive for BSE, the first known non-bovine victim.
Japan's ban on U.S. beef imports continues as does the U.S. ban on Canada's beef.

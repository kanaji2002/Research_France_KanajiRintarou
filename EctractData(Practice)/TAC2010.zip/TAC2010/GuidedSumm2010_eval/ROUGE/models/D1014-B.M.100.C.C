Obesity is defined clinically as being 20% heavier than one's ideal weight.
In 1997 about 33% of the U.S. population is overweight compared to 25% in the 1960's.
Obesity contributes to over 300,000 excess deaths each year and is, after smoking, the second leading cause of preventable deaths in the U.S. To fight obesity it must be recognized as the serious public health problem that it is.
Consumers must be educated to eat a balanced diet, and schools should schedule more physical activity and encourage children to eat low calorie, low-fat foods.

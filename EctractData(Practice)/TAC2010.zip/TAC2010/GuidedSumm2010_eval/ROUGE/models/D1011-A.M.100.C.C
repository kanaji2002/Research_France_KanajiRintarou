Anorexia nervosa is a psychological disorder in which the sufferer starves his or her body to skin and bones but still wants to lose weight.
Bulimia nervosa is an eating disorder in which the patient loses weight through forced vomiting after eating.
Binge eating is a disorder that involves consuming much more than normal in a short period of time.
Almost all who have this disorder are overweight or obese.
The insurance lobby has blocked attempts to have eating disorders added to the list of serious mental illnesses that insurance companies are mandated to cover.

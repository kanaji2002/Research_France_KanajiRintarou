Pfc. Lynndie R. England, on trial at Ft.
Hood, Texas on nine counts including conspiracy, dereliction of duty, maltreatment and indecent acts, pleaded guilty May 2, 2005 to seven of the counts.
The charges concern violation of the Uniform Code of Military Justice that occurred at the Abu Ghraib prison near Baghdad, Iraq in the fall of 2003.
Under an agreement reached with military prosecutors, English would serve less than 11 years in prison.
If her plea is accepted by the military judge, Col. James Pohl, her sentencing will be referred to a military jury.

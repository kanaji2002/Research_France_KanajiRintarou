On April 26, 2000 Philippine Defense Secretary Orlando Mercado confirmed the hostages' location in Sula Province and that Abu Sayyaf participated in the abduction.
President Joseph Estrada appointed Nur Misuari, governor of the Autonomous Region in Muslim Mindanao, as the government's negotiator with the kidnappers who were demanding U.S.$2.4 million in ransom.
Abu Sayyaf rejected Nur Misuari and threatened to behead some of the hostages.
On May 1 a doctor and several journalists visited the hostages at a bamboo hut in the hills of Jolo Island.
They were suffering from hunger and diarrhea.

In January 2005 environmental consultant Wolf-Dieter Busch petitioned the National Marine Fisheries Service to list the oyster as an endangered species.
The petition is now with 12 experts for a decision scheduled by Jan. 2006.
The Chesapeake Bay oyster is the local population of the eastern oyster.
The Endangered Species Act does not allow restrictions on specific area invertebrates so all oysters from New England to the Yucatan would be included.
Maryland and Virginia have undertaken an environmental study of oyster restoration methods due in January.
Maryland and Virginia are still considering introducing the Chinese oyster to the Chesapeake.

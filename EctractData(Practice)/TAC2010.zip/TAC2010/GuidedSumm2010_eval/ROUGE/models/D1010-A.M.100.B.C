Mad cow disease, or bovine spongiform encephalopathy (BSE) eats holes in the brains of cattle.
A human form of the disease, variant Creutzfeldt-Jakob Disease (vCJD), which can be caught from eating beef products from cattle with BSE, causes personality change, loss of body functions, brain deterioration and death.
First identified in Britain in 1996, there have been 147 cases there and 10 elsewhere.
Widespread testing and destruction of cattle and bans on beef imports have been imposed in countries around the world including, Britain, U.S., Canada, EU, Ireland, Japan and Taiwan.

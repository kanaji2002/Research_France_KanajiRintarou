An explosion at a petrochemical plant on the Songhua River in northeast China on Nov. 13, 2005 threatened toxic benzene pollution of drinking water of Harbin, urban population 3.8 million.
The Songhua is a tributary of the Heilong (Russian Amur) River on the Russian border.
China pledged to keep Russian authorities informed of the movement of the benzene-polluted block.
Harbin cut off its urban water supply Nov. 23.
The populace was advised to avoid all contact with pollution.
Water discharge from two reservoirs was increased to dilute a massive slick of pollutants.
Authorities are investigating criminal responsibility for the catastrophe.

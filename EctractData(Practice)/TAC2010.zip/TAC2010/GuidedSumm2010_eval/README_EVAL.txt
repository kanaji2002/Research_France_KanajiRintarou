	    TAC 2010 Guided Summarization Task: Evaluation Results
	    ======================================================


This is the README file for the manual and automatic evaluation that
was performed at NIST for summaries in the TAC 2010 guided
summarization task.  

The guided summarization task was to write a 100-word summary of a set
of 10 newswire articles for a given topic, where the topic falls into
a predefined category. Participants (and human summarizers) were given
a list of aspects for each category, and a summary must include all
aspects found for its category.  Categories and their aspects are
defined in the file categories.txt.

Additionally, an "update" component of the guided summarization task
was to write a 100-word "update" summary of a subsequent 10 newswire
articles for the topic, under the assumption that the user had already
read the earlier articles.

Eight NIST assessors selected and wrote summaries for the 46 topics in
the TAC 2010 guided summarization task.  Each topic had 2 docsets
(A,B), and NIST assessors wrote 4 model summaries for each docset.
The NIST human summarizer IDs are A-H.

NIST received 41 runs from 23 participants for the guided
summarization task.  The participants each submitted up to two runs,
and their summarizer IDs are 3-43.

In addition, two baseline runs were included in the evaluation, and
their summarizer IDs are 1-2:

    Baseline 1 (summarizer ID = 1): returns all the leading sentences
    (up to 100 words) in the most recent document.  Baseline 1
    provides a lower bound on what can be achieved with a simple fully
    automatic extractive summarizer.

    Baseline 2 (summarizer ID = 2): output of MEAD automatic summarizer  
    (v 3.12, publically available at http://www.summarization.com/mead/), 
    with all default settings, set to producing 100-word summaries. 
    
NIST evaluated all summaries manually for overall responsiveness and
for content according to the Pyramid method.  All summaries were also
automatically evaluated using ROUGE/BE.

All summaries were truncated to 100 words before being evaluated.
Summaries are saved one per file, using the following naming
convention: <topic-docset>.M.100.<topic_selectorID>.<summarizerID>


Manual Evaluation
-----------------

The manual evaluation comprised the following:

    1. Pyramid-based evaluation of content 
    2. assessment of linguistic quality
    3. assessment of overall responsiveness.

Pyramid Content: NIST assessors created Pyramids from the 4 model
summaries for each docset, and annotated peer summaries using the
guidelines in:
   http://www1.cs.columbia.edu/~becky/DUC2006/2006-pyramid-guidelines.html
Four 3-model pyramids were then derived from each 4-model pyramid in
order to implement jackknifing and compare pyramid scores for systems
and humans.

Linguistic Quality: NIST assessors assigned an overall linguistic
quality score to each of the automatic and human summaries.  The score
is an integer between 1 (very poor) and 5 (very good) and is guided by
consideration of the following factors:

	1. Grammaticality
	2. Non-redundancy
	3. Referential clarity
	4. Focus
	5. Structure and Coherence

Overall Responsiveness: NIST assessors assigned an overall
responsiveness score to each of the automatic and human summaries.
The overall responsiveness score is an integer between 1 (very poor)
and 5 (very good) and is based on both the linguistic quality of the
summary and the amount of information in the summary that helps to
satisfy the information need defined for the topic's category.

Files under manual/:
   peers/			automatic summaries (Pyramid annotation format)
   models/			model summaries (text format)
   pyramids/			Pyramids for each topic (.pyr files)
   manual.peer.A		peer scores table for initial summaries (see MANUAL.PEER below)
   manual.peer.B		peer scores table for update summaries (see MANUAL.PEER below)
   manual.model.A		model scores table for initial summaries (see MANUAL.MODEL below)
   manual.model.B		model scores table for update summaries (see MANUAL.MODEL below)
   manual.peer.A.avg		average scores per automatic summarizer for initial summaries (see MANUAL.PEER.AVG below)
   manual.peer.B.avg		average scores per automatic summarizer for update summaries (see MANUAL.PEER.AVG below)
   manual.model.A.avg		average scores per model summarizer for initial summaries (see MANUAL.MODEL.AVG below)
   manual.model.A.avg		average scores per model summarizer for update summaries (see MANUAL.MODEL.AVG below)
  
   manual.peer.A.category.avg	average scores per category per automatic summarizer for initial summaries (see MANUAL.PEER.CATEGORY.AVG below)
   manual.peer.B.category.avg	average scores per category per automatic summarizer for update summaries (see MANUAL.PEER.CATEGORY.AVG below)
   manual.model.A.category.avg	average scores per category per model summarizer for initial summaries (see MANUAL.MODEL.CATEGORY.AVG below)
   manual.model.A.category.avg	average scores per category per model summarizer for update summaries (see MANUAL.MODEL.CATEGORY.AVG below)

   aspect.peer.A.avg		average scores per aspect per automatic summarizer for initial summaries (see ASPECT.PEER.AVG below)
   aspect.peer.B.avg		average scores per aspect per automatic summarizer for update summaries (see ASPECT.PEER.AVG below)
   aspect.model.A.avg		average scores per aspect per model summarizer for initial summaries (see ASPECT.MODEL.AVG below)
   aspect.model.B.avg		average scores per aspect per model summarizer for update summaries (see ASPECT.MODEL.AVG below)


MANUAL.PEER TABLE

Columns in the peer results table contain the following information:

1. setID---document set ID
2. peerID---peer summarizer ID

3. modified (pyramid) score---this score equals the sum of the weights
       of the Summary Content Units (SCUs) that a peer summary
       matches, normalized by the ideal weight of a summary which has
       the same number of contributors as the average of the 4 model
       summaries in the associated pyramid.
4. numSCUs---the number of unique contributors in the peer summary
       that match an SCU in the model pyramid. Note that a pyramid SCU
       can be matched by more than one contributor, in the case of
       exact or paraphrase repetition.
5. numrepetitions---the number of contributors in the peer that
       repeated a match to a pyramid SCU. For each set of contributors
       in the peer summary that match the same pyramid SCU, only one
       increments the count in column 4. The rest appear in this
       field; thus the total number of contributing content units in a
       peer summary would be given by summing columns 4 and 5.
       (HOWEVER: NIST assessors were told that it was sufficient for
       scoring purposes to mark just one contributor for each SCU that
       was matched, although they were encouraged to mark any
       additional contributors.)
6. creator---the ID for the assessor who created the pyramid.
7. annotator---the ID for the assessor who annotated all automatic
       summaries for the given docset against its pyramid.
8. average modified score with 3 models---this score is also a
       modified (pyramid) score as in column 3, but in this case it 
       is the average of four scores, each calculated with only three 
       model summaries (instead of all four), in all possible combinations.
9. linguistic quality---overall linguistic quality of the peer summary
10. overall---the overall responsiveness judgment for the peer summary


MANUAL.MODEL TABLE

Columns in the model results table contain the following information:

1. setID---document set ID
2. modelID---human summarizer ID
3. numSCUs---the number of unique contributors in the human summary
       that match an SCU in the model pyramid (which is constructed
       from the remaining 3 model summaries for that document
       set).
4. creator---the ID for the assessor who created the pyramid.
5. annotator---the ID for the assessor who annotated all automatic
       summaries for the given docset against its pyramid.
6. modified (pyramid) score---calculated against the pyramid
   constructed from the remaining 3 models. As in the case of peer
   evaluation, this score equals the sum of the weights of the Summary
   Content Units (SCUs) that a summary matches, normalized by the
   ideal weight of a summary which has the same number of contributors
   as the average of the 3 model summaries in the associated pyramid.
7. linguistic quality---overall linguistic quality of the human summary
8. overall---the overall responsiveness judgment for the human summary


MANUAL.PEER.AVG TABLE

Columns in the average peer results table present scores for each run
averaged over all topics. The table contains the following information
(descriptions of columns correspond to the MANUAL.PEER TABLE):

1. peerID
2. average modified (pyramid) score
3. average numSCUs
4. average numrepetitions
5. macroaverage modified score with 3 models
6. average linguistic quality
7. average overall responsiveness


MANUAL.MODEL.AVG TABLE

Columns in the average model results table present scores for each
human summarizer (A-H) averaged over all relevant topics (i.e. all
summaries they created). The table contains the following information
(descriptions of columns correspond to the MANUAL.MODEL TABLE):

1. modelID
2. average numSCUs
3. average modified (pyramid) score against the remaining 3 models
4. average linguistic quality
5. average overall responsiveness


MANUAL.PEER.CATEGORY.AVG

Columns in the average peer results table present scores for each run
averaged over all topics in a given category (1 - Accidents and Natural Disasters;
2 - Attacks; 3 - Health and Safety; 4 - Endangered Resources; 5 - Trials and 
Investigations). The table contains the following information (descriptions of 
columns correspond to the MANUAL.PEER TABLE):

1. categoryID
2. peerID
3. average modified (pyramid) score
4. average numSCUs
5. average numrepetitions
6. macroaverage modified score with 3 models
7. average linguistic quality
8. average overall responsiveness


MANUAL.MODEL.CATEGORY.AVG TABLE

Columns in the average model results table present scores for each
human summarizer (A-H) averaged over all relevant topics in a given
category (i.e. all summaries they created in that category). The table 
contains the following information (descriptions of columns correspond 
to the MANUAL.MODEL TABLE):

1. categoryID
2. modelID
3. average numSCUs
4. average modified (pyramid) score against the remaining 3 models
5. average linguistic quality
6. average overall responsiveness

ASPECT.PEER.AVG TABLE

Columns in this table present Pyramid scores for each of the category
aspects (for a list of aspects see Summarization track guidelines) for
each automatic summarizer. The table contains the following information:

1. aspectID
2. peerID
3. average modified (pyramid) score
4. macroaverage modified score with 3 models


ASPECT.MODEL.AVG TABLE

Columns in this table present Pyramid scores for each of the category
aspects (for a list of aspects see Summarization track guidelines) for
each human summarizer. The table contains the following information:

1. aspectID
2. modelID
3. macroaverage modified score with 3 models



ROUGE
-----

ROUGE-2 and ROUGE-SU4 scores were computed by running ROUGE-1.5.5 with
stemming but no removal of stopwords.  The input file rougejk.in implemented
jackknifing so that scores of systems and humans could be compared. 

ROUGE run-time parameters:
   ROUGE-1.5.5.pl -n 4 -w 1.2 -m  -2 4 -u -c 95 -r 1000 -f A -p 0.5 -t 0 -a -d rouge_[A,B].in 
   ROUGE-1.5.5.pl -n 4 -w 1.2 -m  -2 4 -u -c 95 -r 1000 -f A -p 0.5 -t 0 -a -d rougejk_[A,B].in 

Files under ROUGE/ (separate for initial (A) and update (B) summaries):
   models/			sentence-segmented model summaries
   peers/			sentence-segmented automatic summaries
   rouge_[A,B].in		input file to ROUGE-1.5.5		
   rouge_[A,B].m.out		output of ROUGE-1.5.5
   rouge2_[A,B].m.avg		average ROUGE-2 recall, by summarizer ID
   rougeSU4_[A,B].m.avg		average ROUGE-SU4 recall, by summarizer ID
   rougejk_[A,B].in		input file to ROUGE-1.5.5 (with jackknifing)
   rougejk_[A,B].m.out		output of ROUGE-1.5.5 (with jackknifing)
   rouge2_[A,B].jk.m.avg	average ROUGE-2 recall, by summarizer ID (with jackknifing)
   rougeSU4_[A,B].jk.m.avg	average ROUGE-SU4 recall, by summarizer ID (with jackknifing)




Basic Elements
--------------

Basic Elements (BE) scores were computed by first using the tools in
BE-1.1 to extract BE-F from each sentence-segmented <summary>:
   bebreakMinipar.pl -p $MINIPATH <summary>

The BE-F were then matched by running ROUGE-1.5.5 with stemming, using
the Head-Modifier (HM) matching criterion.  The input file simplejk.in
implemented jackknifing so that scores of systems and humans could be
compared.

BE run-time parameters:
   ROUGE-1.5.5.pl -m -a -d -3 HM simple.in  
   ROUGE-1.5.5.pl -m -a -d -3 HM simplejk.in  

Files under BE/ (separate for initial (A) and update (B) summaries):
   models/			BEs from model summaries
   peers/			BEs from automatic summaries
   simple_[A,B].in		input file to ROUGE-1.5.5
   simple_[A,B].m.hm.out	output of ROUGE-1.5.5
   simple_[A,B].m.hm.avg	average BE recall, by summarizer ID
   simplejk_[A,B].in		input file to ROUGE-1.5.5 (with jackknifing)
   simplejk_[A,B].m.hm.out	output of ROUGE-1.5.5 (with jackknifing)
   simple_[A,B].jk.m.hm.avg	average BE recall, by summarizer ID (with jackknifing)

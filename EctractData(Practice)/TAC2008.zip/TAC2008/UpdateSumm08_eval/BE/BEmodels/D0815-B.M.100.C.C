vote|just|mod-before
cloture|successful|mod
cloture|may 24 , 2005|nn
just|cloture|prior to
vote|for|guest
vote|first|for
nominee|judicial|mod
vote|nominee|obj1
consideration|senate|nn
nominee|consideration|under
vote|(|punc
vote|pricilla owen|obj2
circuit|u.s. appeals court|nn
circuit|5th|mod
pricilla owen|circuit|for
circuit|)|punc
circuit|14|num
senators|moderate|mod
confirmed|senators|subj
pact|their|gen
pact|mutual|mod
confirmed|pact|obj
vote for|cloture|obj
confirmations|judicial|mod
cloture|confirmations|in
in|"|punc
circumstances|extraordinary|mod
vote|circumstances|in
vote for|circumstances|in
change|circumstances|in
vote for|circumstances|in
change|not|mod-before
rules|filibuster|nn
change|rules|obj
vote for|cloture|obj
nominees|three|nn
contentious|less|mod
nominees|contentious|mod
nominees|federal|mod
nominees|judicial|mod
cloture|nominees|for
vote for|including|mod
including|brown|obj
brown|and|punc
brown|owen|conj
opened|june 6|on
opened|senate|subj
opened|debate|obj
confirmation|brown|gen
debate|confirmation|on
joined|june 7 , 10|on
joined|democrats|subj
vote|successful|mod
joined|vote|in
vote|cloture|for
cloture|brown|for
approved|june 8|on
approved|senate|subj
appointment|brown|gen
appointment|judicial|mod
approved|appointment|obj
appointment|56-43|by

ordered|emirate airlines|subj
passenger|first|post
ordered|passenger|obj1
months|a380|nn
months|five|amount-value
ordered|months|obj2
months|its|before
months|launch|rel
launch|months|obj
launch|december 2000|subj
ordered|january|in
ordered|federal express|subj
cargo|first|post
ordered|cargo|obj1
ordered|a380|obj2
airlines|thirteen|nn
airlines|non-american|nn
placed|airlines|subj
orders|154|num
placed|orders|obj
china|and|punc
china|hong kong|conj
have|china|subj
have|options|obj
deliveries|commercial|mod
begin|deliveries|subj
begin|first quarter|mod
first quarter|2006|num
begin|singapore|to
land|a380s|subj
airports|25|num
land|airports|at
including|new york|obj
new york|los angeles|conj
los angeles|san francisco|conj
san francisco|miami|conj
miami|chicago|conj
chicago|dulles|conj
dulles|memphis|conj
memphis|and|punc
memphis|anchorage|conj
airbus|february 2001|nn
expanded|airbus|in
plant|hamburg|nn
expanded|plant|subj
production|toulouse|nn
started|production|subj
started|january 2002|in
got|july 2003|in
got|broughton|subj
plant|airbus|nn
got|plant|obj
a380|first|post
arrived|a380|subj
arrived|january 2005|in
arrived|taking|mod
taking|a380|subj
flight|its|gen
flight|maiden|mod
taking|flight|obj
taking|april 27|mod

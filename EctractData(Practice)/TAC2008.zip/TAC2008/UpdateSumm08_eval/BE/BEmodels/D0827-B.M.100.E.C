reached|september 27 , 2005|by
deaths|us katrina|nn
reached|deaths|subj
reached|1,121|obj
rescuers|searched|vrel
searched|rescuers|obj
searched|victims|for
hurricane rita|successor|nn
victims|hurricane rita|as
struck|rescuers|subj
forecast|september 14|by
forecast|brit insurance|subj
losses|$us 50 billion|nn
losses|global|mod
losses|insurance|nn
forecast|losses|obj
oil|gulf of mexico|nn
oil|and|punc
extraction|natural gas|nn
oil|extraction|conj
dropped|oil|subj
dropped|sharply|mod
refineries|and|punc
plants|chemical|mod
refineries|plants|conj
faltered|refineries|subj
$us 900 million|us agriculture|nn
$us 900 million|lost|mod
was|september|in
unemployment|louisiana|nn
was|11.5%|pred
gave|august|from
turkey|5.7%|nn
gave|turkey|subj
gave|$us 1.5 million|obj
$us 1.5 million|us red cross|to
relief|katrina|nn
us red cross|relief|for
relief|and|punc
relief|$us 1 million|conj
supplies|humanitarian|mod
$us 1 million|supplies|in
red cross|bosnia|gen
gave|red cross|subj
gave|money|obj
passed|september 21|on
house|us|nn
passed|house|subj
passed|$us 6.1 billion|obj
breaks|katrina|nn
breaks|recovery|nn
breaks|tax|nn
$us 6.1 billion|breaks|in

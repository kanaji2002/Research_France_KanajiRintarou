round|second|post
talks|au-lead|mod
talks|peace|nn
round|talks|of
talks|abuja|in
abuja|that|whn
suspended|temporarily|amod
suspended|abuja|obj
suspended|october 27 , 2004 ,|on
ended|round|subj
ended|november 10|mod
ended|sudan|with
sudan|sla|conj
sla|and|punc
sla|jem|conj
jem|signing|rel
signing|jem|subj
signing|security|obj
security|and|punc
protocols|humanitarian|mod
security|protocols|conj
third|hopeful|pnmod
talks|au-lead|mod
talks|peace|nn
round|talks|of
hopeful|began|fc
began|round|subj
began|abuja|in
abuja|december 11 , 2004 ,|on
began|seeking|mod
seeking|round|subj
settlement|political|mod
seeking|settlement|obj
sla|and|punc
sla|jem|conj
pulled out|sla|subj
talks|peace|nn
pulled out|talks|of
talks|december 13|on
december 13|which|whn
suspended|december 13|obj
suspended|january|until
january|even|pnmod
even|rebels|as
rebels|vowed|vrel
vowed|rebels|obj
vowed|never|mod
vowed|return|mod
return|sla|subj
return|until|mod
until|stopped|comp1
stopped|sudan|subj
stopped|attacking|fc
attacking|sudan|subj
signed|ndjamena|in
national movement|darfur|gen
national movement|reconstruction|for
reconstruction|and|punc
reconstruction|development|conj
signed|national movement|subj
pact|separate|mod
pact|chad-mediated|mod
pact|peace|nn
signed|pact|obj
pact|sudan|with

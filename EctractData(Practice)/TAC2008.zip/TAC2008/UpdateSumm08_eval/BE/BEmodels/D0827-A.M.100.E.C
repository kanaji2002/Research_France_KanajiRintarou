hit|hurricane katrina|subj
hit|louisiana|obj
louisiana|mississippi|conj
mississippi|and|punc
mississippi|alabama|conj
alabama|august 29 , 2005|on
crews|rescue|nn
worked|crews|subj
worked|frantically|mod
worked|save|mod
save|crew|subj
save|hundreds|obj
hundreds|people|of
people|trapped|pnmod
trapped|floodwaters|by
reached|september 8|by
toll|us|nn
toll|death|nn
reached|toll|subj
reached|118|obj
death|one|nn
death|reported|mod
was|death|pred
death|guatemala|in
efforts|fema|gen
efforts|katrina|nn
efforts|disaster|nn
efforts|response|nn
cost|efforts|subj
cost|$us 2.87 million|obj
$us 2.87 million|september 6 , 2005|as of
september 12|swiss reinsurance company|appo
losses|estimated|mod
losses|$us 40 billion|nn
losses|global|mod
losses|insured|mod
swiss reinsurance company|losses|appo
losses|united states|in
united states|hurricane katrina|from
emir|qatar|of
donated|emir|subj
donated|$us 100 million|obj
victims|us|nn
$us 100 million|victims|for
victims|katrina|of
$us 200,000|uganda|nn
$us 200,000|pledged|mod
relief|katrina|nn
$us 200,000|relief|toward
relief|and|punc
relief|rebuilding|conj
rebuilding|us|in

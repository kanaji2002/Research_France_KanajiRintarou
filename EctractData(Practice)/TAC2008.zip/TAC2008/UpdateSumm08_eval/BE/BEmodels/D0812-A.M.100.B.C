regained|january 2004|in
regained|saakashvili|subj
regained|control|obj
control|adzharia|of
searched|georgia|subj
searched|ships|obj
ships|arriving|rel
arriving|ship|subj
arriving|abkhazia|in
offered|saakashvili|subj
offered|"|punc
offered|widest|punc
autonomy|possible|mod
offered|autonomy|obj
autonomy|"|punc
autonomy|abkhazia|to
abkhazia|and|punc
abkhazia|south ossetia|conj
troops|georgian|mod
entered|troops|subj
entered|south ossetia|obj
south ossetia|threats|despite
intervention|russian|mod
threats|intervention|of
guards|georgian|mod
guards|coast|nn
fired|guards|subj
ship|turkish|nn
fired|ship|on
ship|abkhazia|near
threatened|georgia|subj
threatened|withdrawal|obj
withdrawal|commonwealth of independent states|from
georgia|and|punc
georgia|south ossetia|conj
agreed|georgia|subj
withdrawal|mutual|mod
agreed|withdrawal|to
withdrawal|troops|of
said|georgia|subj
would|not|neg
said|start|fc
start|it|subj
start|war|obj
start|and|punc
start|denied|conj
denied|it|obj
denied|stationing|mod
stationing|it|subj
troops|700|num
stationing|troops|obj
border|abkhazia|nn
troops|border|on
was|make|pred
make|official|obj1
make|proposals|desc
proposals|abkhazia|to
abkhazia|and|punc
abkhazia|south ossetia|conj
make|and|punc
make|finalize|conj
agreement|framework|nn
finalize|agreement|obj
agreement|relations|on
relations|russia|with

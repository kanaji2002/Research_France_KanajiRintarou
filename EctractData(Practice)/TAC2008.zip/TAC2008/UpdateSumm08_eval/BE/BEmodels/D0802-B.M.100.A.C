ice|arctic|nn
ice|sea|mod
melting|ice|subj
melting|faster|mod
area|its|gen
is|down|guest
is|20%|pred
20%|and|punc
20%|it|conj
disappear|all|subj
thinning|sea|obj
threatens|ice|subj
threatens|extinction|obj
extinction|polar bears|of
reflects|ice|subj
reflects|sunlight|obj
reflects|warming|mod
warming|ice|subj
warming|planet|obj
warming|leading to|mod
leading to|more|guest
melt|ice|nn
leading to|melt|obj
rise|sea-level|subj
greenland|and|punc
melting|antarctic|mod
melting|ice shelf|nn
greenland|melting|conj
double|greenland|subj
rise|estimated|mod
rise|global|mod
rise|sea level|nn
double|rise|obj
meter|1|amount-value
rise|meter|to
thaw|arctic|nn
thaw|permafrost|nn
releases|thaw|subj
releases|warming|mod
warming|thaw|subj
gases|greenhouse|nn
warming|gases|obj
gases|which|whn
increase|gases|subj
increase|permafrost|obj
permafrost|melting|rel
melting|permafrost|subj
11|up to|num-mod
feet|11|nn
melting|feet|obj
permafrost|deep|pnmod
deep|2100|by
fishing season|greenland|gen
fishing season|ice|nn
shortened|fishing season|subj
areas|lake|nn
doubled|areas|subj
glaciers sermeg|sermilik|conj
sermilik|and|punc
sermilik|kangerdlugssuag|conj
melted|glaciers sermeg|subj
melted|faster|mod
glacier|alaska|gen
glacier|columbia|nn
melted|also|mod-before
melted|glacier|subj
melted|faster|mod

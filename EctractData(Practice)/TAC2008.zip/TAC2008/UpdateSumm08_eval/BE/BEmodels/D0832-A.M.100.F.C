was|july 2005|by
representative|u.s.|nn
representative|randall cunningham|person
was|under|pred
was|investigation|under
investigation|fbi|by
attorney|u.s.|nn
office|attorney|gen
fbi|office|conj
office|defense criminal investigative service|conj
defense criminal investigative service|irs|conj
irs|and|punc
probe|federal|mod
probe|grand jury|nn
irs|probe|conj
received|he|subj
mzm inc|defense contractor|nn
money|mzm inc|gen
money|pac|nn
received|money|obj
money|and|punc
donations|personal|mod
money|donations|conj
president|mzm|nn
donations|president|from
president|mitchell wade|appo
paid|wade|subj
inflated|supposedly|mod
price|inflated|mod
paid|price|obj
price|cunningham|for
cunningham|and|punc
money|cunningham|nn
money|paid|mod
money|wade|nn
little|questionably|mod
money|little|mod
cunningham|money|conj
money|live on|rel
live on|money|subj
yacht|wade|gen
live on|yacht|obj
yacht|dc|in
promoted|cunningham|subj
contracts|mzm|nn
contracts|defense|nn
promoted|contracts|obj
contracts|contributed to|vrel
contributed to|contracts|obj
contributed to|and|punc
contributed to|served|conj
served|contracts|subj
board|wade-run|mod
board|charity|nn
served|board|on
board|and|punc
board|spoke|conj
party|mzm|nn
party|company|nn
spoke|party|at
requested|cunningham|subj
permission|donors|gen
requested|permission|obj
permission|transfer|rel
transfer|permission|subj
funds|campaign|nn
transfer|funds|obj
fund|his|gen
fund|legal|mod
fund|defense|nn
funds|fund|to

prepared|properly|amod
prepared|shoots|obj
prepared|avoid|mod
avoid|bamboo shoot|subj
avoid|consuming|guest
consuming|naturally|mod
hydrogen cyanide|produced|mod
avoid|hydrogen cyanide|obj
help|bamboo|subj
buildings|makeshift|mod
withstand|better|mod-before
withstand|buildings|subj
withstand|earthquakes|obj
products|innovative|mod
products|bamboo|mod
flooring|hardwood|mod
flooring|paneling|conj
paneling|cabinets|conj
cabinets|countertops|conj
countertops|utensils|conj
utensils|plates|conj
plates|bowls|conj
boards|cutting|nn
bowls|boards|conj
curtains|shower|nn
boards|curtains|conj
curtains|and|punc
curtains|products|conj
products|based|vrel
based|products|obj
based|fiber|on
pulps|fiber|nn
fiber|pulps|conj
pulps|or|punc
pulps|veneers|conj
tensile strength|greater|mod
tensile strength|steel|than
harvested|it|obj
years|3 to 5|amount-value
years|but|punc
stands|entire|mod
stands|bamboo|mod
years|stands|conj
die|years|subj
years|60|amount-value
collapse|crop|nn
threatening|collapse|obj
threatening|and|punc
threatening|endangering|conj
pandas|china|gen
pandas|endangered|mod
endangering|pandas|obj
pandas|who|whn
are|dependent|pred
bamboo|arrow|nn
dependent|bamboo|on

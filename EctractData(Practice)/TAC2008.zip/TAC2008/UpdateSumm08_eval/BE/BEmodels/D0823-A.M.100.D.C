campaign|ukraine|gen
campaign|2004|num
campaign|presidential|mod
claimed|campaign|in
candidate|pro-western|mod
candidate|yushchenko|person
claimed|candidate|subj
claimed|poisoned|fc
poisoned|he|obj
poisoned|by|by-subj
poisoned|supporters|by
candidate|pro-russian|nn
supporters|candidate|of
yanukovich|current|mod
yanukovich|prime minister|title
candidate|yanukovich|appo
observers|international|nn
alleged|observers|subj
violations|election|nn
alleged|violations|obj
moved|yanukovich|subj
parade|kiev liberation day|nn
parade|military|mod
moved|parade|obj
parade|october 29|to
moved|raising|mod
raising|yanukovich|subj
raising|fears|obj
crackdown|military|mod
fears|crackdown|of
raising|or|punc
raising|canceled|conj
canceled|yanukovich|subj
canceled|elections|obj
media|state|nn
denied|media|subj
denied|yushchenko|obj1
denied|coverage|obj2
students|and|punc
employees|public|mod
students|employees|conj
pressured|students|obj
pressured|vote for|mod
vote for|student|subj
vote for|yanukovich|obj
raised|yanukovich|subj
raised|pensions|obj
pensions|elections|before
got|october 31|on
got|yushchenko|subj
got|39.82%|obj
39.82%|yanukovich 39.32%|appo
parliament|emergency|mod
parliament|meeting|rel
meeting|parliament|subj
meeting|quorum|without
reversed|parliament|subj
victory|yanukovich|gen
victory|november 21|nn
reversed|victory|obj
yushchenko|healthier|mod
proposed|yushchenko|subj
elections|new|mod
proposed|elections|obj
offered|yanukovich|subj
offered|yushchenko|obj1
offered|prime ministry|obj2

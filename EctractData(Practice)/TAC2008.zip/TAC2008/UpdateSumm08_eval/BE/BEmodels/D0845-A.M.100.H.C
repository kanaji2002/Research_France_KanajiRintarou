ivory-billed woodpecker|(|punc
thought|campephilus principalis|nn
thought|)|punc
ivory-billed woodpecker|thought|appo
thought|extinct|pnmod
extinct|1944|since
seen|ivory-billed woodpecker|obj
seen|again|mod
seen|february 11 , 2004|mod
was|last|pred
last|seen|vrel
seen|last|obj
region|"|punc
region|big woods|nn
region|"|punc
seen|region|in
arkansas|eastern|mod
region|arkansas|of
sightings|independent|mod
sightings|and|punc
sightings|video|conj
video|teams|by
laboratory of ornithology|cornell university|gen
teams|laboratory of ornithology|from
laboratory of ornithology|and|punc
laboratory of ornithology|nature conservancy|conj
nature conservancy|ruled|vrel
ruled|nature conservancy|obj
woodpecker|similar|mod
woodpecker|pileated|mod
ruled|woodpecker|out
ruled|and|punc
ruled|confirmed|conj
confirmed|nature conservancy|subj
confirmed|rediscovery|obj
rediscovery|which|whn
kept|rediscovery|obj1
kept|secret|desc
kept|for|mod
year|prepare|rel
prepare|year|subj
prepare|protect|mod
protect|bird|obj
for|'s|comp1
's|habitat|pred
's|not|mod
watchers|bird|nn
flood|watchers|of
groups|private|mod
including|nature conservancy|obj
about $10 million|spent|mod
about $10 million|and|punc
about $10 million|interior department|conj
committed|about $10 million|subj
committed|over $10 million|obj

vanished|taylor|subj
vanished|night|mod
night|march 27|of
vanished|after|mod
government|nigerian|mod
after|said|comp1
said|government|subj
said|end|fc
end|it|subj
asylum|his|gen
end|asylum|obj
end|and|punc
end|allow|conj
allow|it|subj
face|him|subj
face|indictment|obj
court|international|mod
indictment|court|by
court|sierra leone|in
arrested|march 29|on
arrested|he|obj
arrested|by|by-subj
police|nigeria|nn
arrested|police|by
police|trying|rel
trying|police|subj
trying|escape|fc
escape|cameroon|into
detained|he|obj
detained|guard|under
guard|flown|vrel
flown|guard|obj
flown|liberia|to
liberia|arrested|vrel
arrested|liberia|obj
arrested|by|by-subj
forces|un|nn
forces|peacekeeping|mod
arrested|forces|by
arrested|and|punc
arrested|extradited|conj
extradited|liberia|obj
extradited|by|by-subj
extradited|helicopter|by
helicopter|sierra leone|to
sierra leone|march 30|on
special court|sierra leon|in
indicted|special court|subj
indicted|taylor|obj
counts|11|num
taylor|counts|on
counts|crimes|of
crimes|humanity|against
indicted|making|mod
making|special court|subj
making|him|obj1
head of state|first|post
head of state|african|mod
making|head of state|desc
head of state|face|rel
face|head of state|subj
tribunal|international|mod
tribunal|war crimes|nn
face|tribunal|obj

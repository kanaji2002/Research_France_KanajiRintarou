national special program|china|gen
national special program|food security|for
assists|national special program|subj
eliminate|nigeria|subj
eliminate|poverty|obj
development|bamboo-based|mod
poverty|development|through
eliminate|using|mod
using|nigeria|subj
using|nigeria|obj
nigeria|existing|pnmod
forests|utilized|mod
forests|bamboo|mod
existing|forests|under
forests|turn|rel
turn|forest|subj
turn|out|guest
300|about|num-mod
byproducts|300|nn
turn|byproducts|obj
20|over|num-mod
insects|20|nn
plague|insects|subj
china|northwest|mod
bamboo|china|gen
bamboo|arrow|nn
plague|bamboo|obj
source|major|mod
source|food|nn
bamboo|source|appo
source|giant pandas|for
advances|u.s. national zoo|gen
advances|research|nn
cycles|giant panda|nn
cycles|reproductive|mod
advances|cycles|in
cycles|and|punc
cycles|artificial insemination|conj
increase|advances|subj
populations|endangered|mod
populations|giant panda|nn
increase|populations|obj
populations|captivity|in
in|and|punc
in|in|conj
in|wild|in
building|india|subj
building|two|obj
building|commercially|mod
friendly|environmentally|mod
one-megawatt|"|punc
plants|green|mod
plants|power|mod
plants|"|punc
plants|bamboo|mod
plants|gasification-based|mod
plants|electricity|nn
one-megawatt|plants|appo
variety|wide|mod
fiber|bamboo|mod
variety|fiber|of
are|available|pred
are|including|conj
including|rugs|subj
including|kiln-dried|obj
including|and|punc
including|carbonized|conj
carbonized|rugs|subj
carbonized|bamboo|obj
coatings|polyurethane|nn
bamboo|coatings|with

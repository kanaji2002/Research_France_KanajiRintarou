reduced|herceptin|subj
52 percent|her2-positive|mod
52 percent|gene-associated|mod
52 percent|breast|nn
52 percent|cancer|nn
52 percent|recurrences|nn
reduced|52 percent|obj
proved|avastin|subj
proved|effective|desc
cancer|breast|nn
effective|cancer|against
carcinoma|-grade|mod
carcinoma|ductal|mod
carcinoma|situ|in
becomes|carcinoma|subj
cancer|invasive|mod
becomes|cancer|obj
cancer|40 percent|in
years|patients|nn
40|over|num-mod
years|40|amount-value
40 percent|years|of
chemotherapy|combined|mod
chemotherapy|and|punc
therapy|hormone|nn
chemotherapy|therapy|conj
cut|chemotherapy|subj
cut|death|obj1
death|half|in
years|15|amount-value
half|years|within
years|recurring|from
recurring|chemotherapy|subj
cancer|breast|nn
cut|cancer|obj2
daily|consuming 33.3|nn
daily|fat|mod
daily|grams|nn
reduces|daily|subj
five|breast|nn
five|cancer|nn
five|recurrence|nn
five|30%|nn
five|over|num-mod
reduces|five|obj
reduces|years|mod
increases|exercise|subj
50%|breast|nn
50%|cancer|nn
50%|survival|nn
increases|50%|obj
levels|low|mod
levels|melatonin|nn
workers|night-time|nn
levels|workers|in
increased|levels|subj
cancer|breast|nn
increased|cancer|obj
lesions|benign|mod
lesions|"|punc
lesions|proliferative|mod
lesions|"|punc
correlate|lesions|subj
cancer|later|mod
cancer|breast|nn
correlate|cancer|with
65|and|punc
tumors|older|mod
smaller|early|mod
tumors|smaller|mod
tumors|localized|mod
65|tumors|conj
accounted for|65|subj
accounted for|96%|obj
improvement|survival|nn
96%|improvement|of
38%|50|under

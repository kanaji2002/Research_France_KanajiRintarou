sudan|and|punc
groups|darfur|gen
groups|two|nn
groups|main|mod
groups|rebel|mod
sudan|groups|conj
groups|sudan liberation army|conj
sudan liberation army|and|punc
sudan liberation army|justice|conj
justice|and|punc
movement|equality|nn
justice|movement|conj
ceasefire|ndjamena|in
ndjamena|april , 2004|in
visited|october 6|on
minister|uk|nn
minister|prime|mod
visited|minister|subj
visited|sudan|obj
sudan|discuss|rel
discuss|sudan|subj
discuss|darfur|obj
talks|au-lead|mod
talks|peace|nn
talks|abuja|in
rebels|darfur|nn
abuja|rebels|between
rebels|and|punc
rebels|sudan|conj
ran|talks|subj
ran|august 23|mod
reconvened|september 17|subj
reconvened|october 21|mod
reconvened|but|punc
reconvened|suspended|conj
suspended|september 17|obj
suspended|by|by-subj
suspended|au|by
au|october 27|on
hosted|libya|subj
mini-summit|"|punc
hosted|mini-summit|obj
mini-summit|"|punc
mini-summit|leaders|with
leaders|sudan|of
sudan|egypt|conj
egypt|nigeria|conj
nigeria|chad|conj
chad|and|punc
chad|jem|conj
jem|tripoli|in
tripoli|october 17-21|on
declined|sla|subj
eu|and|punc
officials|au|nn
eu|officials|conj
met|eu|subj
met|october 23-24|mod
met|khartoum|in
president|sudan|nn
khartoum|president|with

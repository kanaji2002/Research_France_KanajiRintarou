late|december 21 , 2004 ,|as
as|said|comp1
be|still|guest
be|under|pred
investigation|criminal|mod
be|investigation|under
investigation|justice department|by
manipulations|alleged|mod
manipulations|financial|mod
manipulations|accounting|nn
justice department|manipulations|for
manipulations|fannie mae|at
is|not|neg
is|clear|pred
is|if|c
was|ever|guest
was|under|pred
investigation|criminal|mod
was|investigation|under
investigation|related|vrel
related|investigation|obj
charges|criminal|mod
related|charges|to
charges|time warner|against
time warner|and|punc
time warner|aol|conj
aol|which|whn
companies|two|nn
paid|together|mod-before
paid|companies|subj
paid|over $500 million|obj
paid|settle|fc
settle|aol|obj
settle|company|subj
settle|december 2004|in
stemmed from|charges|subj
practices|alleged|mod
practices|fraudulent|mod
practices|accounting|nn
stemmed from|practices|obj
practices|dating back|rel
dating back|practice|subj
company|separate|mod
was|company|pred
director|raines|person
was|member|pred
committee|aol|gen
committee|audit|nn
member|committee|of

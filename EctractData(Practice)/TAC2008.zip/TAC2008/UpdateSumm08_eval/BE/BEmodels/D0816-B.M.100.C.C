agreement|2005 six-nations|nn
n.k|giving up|rel
giving up|n.k|subj
program|its|gen
program|nuclear weapons|nn
giving up|program|obj
returning to|npt|obj
npt|and|punc
safeguards|iaea|nn
npt|safeguards|conj
declared|u.s.|subj
arms|nuclear|mod
declared|arms|obj
peninsula|korean|nn
arms|peninsula|on
peninsula|and|punc
peninsula|intention|conj
intention|attack|rel
attack|intention|subj
attack|n.k|obj
reaffirmed|s.k|subj
reaffirmed|it|obj
china|russia|conj
russia|s.k|conj
s.k|u.s.|conj
u.s.|and|punc
u.s.|japan|conj
agreed|china|subj
give|n.k|obj1
reactor|light-water|mod
give|reactor|obj2
n.k|and|punc
pledge|u.s.|nn
n.k|pledge|conj
pledge|respect|rel
respect|pledge|subj
sovereignty|each other|gen
respect|sovereignty|obj
respect|coexist|conj
coexist|pledge|subj
coexist|peacefully|mod
coexist|and|punc
coexist|normalize|conj
normalize|pledge|subj
normalize|relations|obj
n.k|and|punc
n.k|japan|conj
agreed|n.k|subj
agreed|normalize|fc
normalize|n.k|subj
normalize|ties|obj
china|russia|conj
russia|s.k|conj
s.k|and|punc
s.k|u.s.|conj
gave|china|subj
assistance|n.k|nn
assistance|energy|nn
gave|assistance|obj
offered|australia|subj
energy|n.k|nn
offered|energy|obj
energy|aid|conj
aid|and|punc
aid|expertise|conj

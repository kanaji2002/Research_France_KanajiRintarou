newspaper|may 23 , 2005|nn
newspaper|sports|nn
used|newspaper|on
armstrong|l 'equip|nn
armstrong|reported|mod
used|illegally|mod-before
used|armstrong|subj
used|erythropoietin|obj
tour de france|1999|num
erythropoietin|tour de france|for
tour de france|based|vrel
based|tour de france|obj
samples|urine|nn
based|samples|on
samples|examined|vrel
examined|samples|obj
protocols|world anti-doping agency|nn
examined|protocols|outside
examined|but|punc
examined|linked|conj
linked|samples|obj
linked|armstrong|to
armstrong|l 'equip|by
linked|violation|in
rules|wada|nn
rules|anonymity|nn
violation|rules|of
director|tour|nn
director|leblanc|person
accepted|director|subj
accepted|charge|obj
accepted|uncritically|mod
seemed|discipline|subj
seemed|unlikely|desc
seemed|because|mod
testing|wada|nn
because|was|comp1
was|impossible|pred
minister|french|nn
minister|sports|nn
agreed|minister|subj
usa cycling|miguel indurain|conj
miguel indurain|and|punc
miguel indurain|ed coyle|conj
defended|usa cycling|subj
defended|armstrong|obj
took|armstrong|subj
took|erythropoietin|obj
treatments|cancer|nn
erythropoietin|treatments|during
treatments|1999|before
investigation|international cycling union|nn
testing|1999|num
testing|drug|nn
investigation|testing|of
is|pending|pred
suggested|alessandro donati|subj
suggested|evidence|without
evidence|that|c
used|armstrong|subj
substances|other|mod
substances|banned|mod
used|substances|obj

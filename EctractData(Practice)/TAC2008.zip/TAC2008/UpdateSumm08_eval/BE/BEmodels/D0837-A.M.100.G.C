graduated|barack obama|subj
graduated|harvard law school|obj
president|first|post
president|black|mod
harvard law school|president|as
president|harvard law review|of
won|term|subj
seat|u.s. senate|nn
won|seat|obj
won|support|with
liberals|white|mod
support|liberals|from
class|white|mod
class|middle|nn
liberals|class|conj
class|and|punc
blacks|chicago|nn
blacks|south side|nn
class|blacks|conj
senator|third|post
senator|black|mod
senator|u.s.|nn
become|senator|obj
years|150|amount-value
senator|years|in
raised|he|subj
fund|$14 million|nn
fund|campaign|nn
raised|fund|obj
raised|and|punc
raised|gave|conj
gave|he|subj
gave|$400,000|obj
candidates|other|mod
candidates|democratic|mod
$400,000|candidates|to
speech|keynote|nn
democratic convention|2004|num
speech|democratic convention|at
democratic convention|kindled|vrel
kindled|democratic convention|obj
kindled|such|mod
such|power|comp1
power|star|subj
power|he|obj
recruited|speech|obj
recruited|stump|mod
stump|speech|subj
stump|in|guest
stump|dozen|in
stump|states|obj
john kerry|presidential|mod
john kerry|nominee|nn
states|john kerry|for

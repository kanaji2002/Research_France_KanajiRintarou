manufactured|february 2005|in
february 2005|declared|rel
declared|february 2005|obj
declared|north korea|subj
manufactured|it|subj
manufactured|nuclear weapons|obj
manufactured|and|punc
manufactured|rejoin|conj
rejoin|it|subj
north korea|six-nation|mod
north korea|talks|nn
north korea|(|punc
rejoin|north korea|obj
had|may|in
n.k|iaea|nn
n.k|reported|mod
had|n.k|subj
six|close to|num-mod
nuclear weapons|six|nn
had|nuclear weapons|obj
n.k|and|punc
n.k|s.k|conj
resumed|n.k|subj
talks|direct|mod
resumed|talks|obj
returned to|july|in
returned to|n.k|subj
talks|six-nation|mod
returned to|talks|obj
returned to|after|mod
after|recognized|comp1
recognized|u.s.|subj
sovereignty|n.k|gen
recognized|sovereignty|obj
offered|s.k|subj
food|n.k|nn
offered|food|obj1
food|electricity|appo
membership|apec|nn
electricity|membership|appo
fund|multinational|mod
fund|rehabilitation|nn
offered|fund|obj2
offered|and|punc
offered|establish|conj
establish|s.k|subj
establish|northeast asian development bank|obj
establish|if|c
abandons|n.k|subj
abandons|nuclear weapons|obj
nuclear weapons|which|whn
called|nuclear weapons|obj
called|u.s.|subj
said|n.k|subj
said|return to|fc
return to|it|subj
return to|nuclear non-proliferation treaty|obj
return to|after|mod
program|its|gen
program|nuclear weapons|nn
after|resolved|comp1
resolved|program|obj

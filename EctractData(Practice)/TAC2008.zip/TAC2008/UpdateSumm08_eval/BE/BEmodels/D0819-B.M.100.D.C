absence|long|mod
absence|police|nn
fueled|absence|after
declaration|sarkozy|gen
declaration|october 19|nn
of|"|punc
declaration|war|of
war|mercy|without
mercy|"|punc
suburbs|violent|mod
mercy|suburbs|on
fueled|declaration|subj
fueled|riots|obj
riots|starting|rel
starting|riot|subj
starting|october 27|mod
declared|november 8|on
declared|france|subj
declared|state|obj
state|emergency|of
declared|and|punc
declared|offered|conj
offered|france|subj
offered|social assistance|obj
residents|november 11 , 118|nn
injured|residents|by
police|firefighters|conj
firefighters|and|punc
journalists|foreign|mod
firefighters|journalists|conj
injured|police|obj
damage|$us 235 million|nn
damage|total|mod
injured|damage|with
exceeded|vehicles|subj
exceeded|8,000|obj
exceeded|arrests|subj
exceeded|2,200|obj
torchings|vehicle|nn
torchings|and|punc
torchings|arrests|conj
517/78|897/250|appo
1300/349|1408/395|appo
1408/395|1173/330|appo
burned|riots|before
vehicles|3,500|num
burned|vehicles|subj
burned|monthly|mod
burned|nationwide|mod
extended|france|subj
powers|emergency|mod
extended|powers|obj
powers|november 14|on

richard prum|july 2005|nn
richard prum|ornithologists|nn
richard prum|mark robbins|conj
mark robbins|and|punc
mark robbins|jerome jackson|conj
paper|questioning|rel
questioning|paper|subj
questioning|sufficiency|obj
sufficiency|evidence|of
rediscovery|ivory-billed woodpecker|gen
evidence|rediscovery|for
withdrew|they|subj
paper|their|gen
withdrew|paper|obj
paper|hearing|after
hearing|they|subj
recordings|audio|nn
hearing|recordings|obj
recordings|calls|of
calls|and|punc
calls|raps|conj
matching|reportedly|amod
raps|matching|rel
matching|rap|subj
recordings|1930 's|nn
matching|recordings|obj
raps|bird|of
they|and|punc
they|others|conj
but|remained|comp1
remained|they|subj
remained|skeptical|desc
began|december|in
100|over|num-mod
researchers|100|nn
researchers|and|punc
researchers|volunteers|conj
began|researchers|subj
search|intensive|mod
search|six-month|nn
began|search|obj
acres|500,000|num
search|acres|across
wetlands|arkansas|nn
acres|wetlands|of
wetlands|seeking|rel
seeking|wetlands|subj
evidence|definitive|mod
seeking|evidence|obj
evidence|bird|of
town|local|mod
benefited|town|subj
benefited|bird|from
bird|watching|rel
watching|bird|subj
watching|tourists|obj
published|january 2006|in
published|jackson|subj
published|article|obj
article|saying|rel
saying|article|subj
claims|proof|for
existence|bird|gen
proof|existence|of
saying|constitute|fc
constitute|claims|subj
constitute|"|punc
ornithology|faith-based|mod
constitute|ornithology|obj

stormed|march 24 , 2005|on
stormed|protestors|subj
building|main|mod
building|kyrgystan|nn
building|government|nn
stormed|building|obj
building|and|punc
building|akayev|conj
akayev|fled|vrel
fled|akayev|obj
fled|russia|to
parliament|elected|mod
parliament|pro-akayev|nn
elected|nonetheless|mod-before
elected|parliament|subj
opponent|akayev|nn
elected|opponent|obj
opponent|speaker|as
elected|and|punc
elected|called for|conj
called for|parliament|subj
elections|new|mod
elections|presidential|mod
called for|elections|obj
elections|june 26|on
signed|april 3|on
signed|akayev|subj
resignation|his|gen
signed|resignation|obj
resignation|moscow|in
moscow|which|whn
notarized|moscow|obj
notarized|lieu|in
requirement|constitutional|mod
lieu|requirement|of
requirement|that|c
present|he|subj
resignation|his|gen
present|resignation|obj
resignation|person|in
person|parliament|to
safety|his|gen
guaranteed|still|mod-before
could|not|neg
because|guaranteed|comp1
guaranteed|safety|obj
calls|continued|mod
guaranteed|calls|due to
impeachment|his|gen
calls|impeachment|for
resignation|his|gen
resignation|recorded|mod
was|heard|pred
heard|by|by-subj
session|special|mod
heard|session|by
session|parliament|of
parliament|april 6|on
live|broadcast|subj

senator|5th|mod
senator|black|mod
is|senator|pred
history|u.s.|nn
senator|history|in
received|2005|in
received|he|subj
award|harvard law school|gen
award|highest|mod
received|award|obj
criticized|he|subj
debacle|katrina|nn
criticized|debacle|obj
published|he|subj
article|time|nn
article|magazine|nn
published|article|obj
article|president|about
president|lincoln|person
criticized|he|subj
administration|bush|nn
criticized|administration|obj
criticized|and|punc
criticized|called for|conj
called for|he|subj
withdrawal|troop|nn
called for|withdrawal|obj
withdrawal|iraq|from
met with|2006|in
met with|he|subj
met with|minister|obj
minister|israel|in
term|first|post
term|and|punc
senator|senior|mod
term|senator|conj
senator|mccain|person
worked on|term|subj
reform|ethics|nn
worked on|reform|obj
worked on|had|conj
had|term|subj
spat|public|mod
had|spat|obj
had|and|punc
had|made|conj
made|term|subj
made|nice|desc
chairman|democratic senatorial campaign committee|nn
helped|chairman|as
helped|he|subj
$6.5 million|raise|nn
helped|$6.5 million|obj
won|he|subj
won|grammy|obj1
audio|his|gen
grammy|audio|for
won|book|obj2
book|dreams of my father|title

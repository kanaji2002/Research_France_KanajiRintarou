arrests|two|nn
arrests|false|mod
was|arrests|after
serial killer|suspected|mod
serial killer|wichita|nn
serial killer|"|punc
serial killer|btk|nn
arrests|serial killer|appo
february 25 , 2005|arrested|mod
was|february 25 , 2005|pred
held|he|obj
murders|10 first-degree|nn
held|murders|for
held|from 1974 to 1991|mod
held|but|punc
held|get|conj
get|he|subj
penalty|kansas|gen
penalty|death|nn
get|penalty|obj
penalty|instituted|vrel
instituted|1994|in
local|and|punc
police|county|mod
local|police|conj
police|kansas bureau of investigation|conj
kansas bureau of investigation|and|punc
kansas bureau of investigation|fbi|conj
worked|local|subj
years|31|amount-value
worked|years|obj
tips|5,000|num
years|tips|on
tips|and|punc
tips|evidence|conj
evidence|provided|vrel
provided|evidence|obj
provided|by|by-subj
provided|btk|by
letters|eight|nn
letters|police|to
police|and|punc
police|media|conj
necklace|victim|gen
media|necklace|conj
necklace|gave|rel
gave|necklace|obj
gave|btk|subj
friend|his|gen
friend|girl|nn
gave|friend|to
driver 's license|victim|gen
friend|driver 's license|conj
voice|btk|gen
voice|recorded|mod
driver 's license|voice|conj
voice|and|punc
semen|crime|nn
semen|scene|nn
voice|semen|conj
semen|thousands|conj
swabs|dna|nn
thousands|swabs|of
dna|btk|gen
swabs|dna|conj
dna|linking|rel
linking|dna|subj
linking|rader|to
rader|and|punc
rader|facts|conj
facts|matching|rel
matching|fact|subj
biography|rader|gen
matching|biography|obj

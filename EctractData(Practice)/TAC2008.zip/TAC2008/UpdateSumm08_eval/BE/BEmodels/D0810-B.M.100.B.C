investigating|october 12 , 2004|by
attorney|u.s.|nn
office|attorney|gen
office|washington|in
investigating|office|subj
franklin raines|fannie mae|nn
franklin raines|ceo|title
investigating|franklin raines|obj
franklin raines|who|whn
denied|franklin raines|subj
charged|after|mod-before
office|caustic|mod
office|september 22|nn
charged|office|after
report|federal housing enterprise oversight|nn
office|report|of
report|vetted|vrel
vetted|report|obj
vetted|by|by-subj
vetted|sec|by
denied|charged|fc
charged|wrongdoing|subj
financial accounting standard 133|fannie mae|nn
financial accounting standard 133|violated|mod
charged|financial accounting standard 133|obj
financial accounting standard 133|and|punc
financial accounting standard 133|fas-91|conj
earnings|fannie mae|gen
earnings|reported|mod
earnings|net|mod
inflating|earnings|obj
earnings|$9 billion|by
inflating|so|mod
so|that|c
raines|and|punc
executives|other|mod
executives|top|nn
raines|executives|conj
received|raines|subj
bonuses|maximum|mod
received|bonuses|obj
bonuses|$27.1 million|nn
bonuses|vice|nn
bonuses|bonuses|of
received|and|punc
received|got|conj
manipulated|higher|mod-before
manipulated|allegedly|amod
manipulated|raines|obj
sales|their own|gen
prices|sales|for
stock|fannie mae|nn
sales|stock|of
told|justice department|subj
told|fannie mae|obj
fannie mae|preserve|rel
preserve|fannie mae|subj
preserve|documents|obj
documents|related|vrel
related|documents|obj
report|ofheo|gen
related|report|to

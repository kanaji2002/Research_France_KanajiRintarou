refused|georgia|subj
refused|exchange|fc
exchange|georgia|subj
prisoners|ossetian|nn
exchange|prisoners|obj
prisoners|georgians|for
georgians|captured|vrel
captured|georgians|obj
captured|by|by-subj
captured|south ossetia|by
saakashvili|asked|vrel
asked|saakashvili|obj1
asked|russia|obj2
russia|help|rel
help|russia|subj
reunite|saakashvili|subj
reunite|south ossetia|obj
south ossetia|and|punc
south ossetia|abkhazia|conj
abkhazia|georgia|with
told|he|subj
told|council of europe|obj
told|that|c
autonomy|south ossetia|for
south ossetia|and|punc
south ossetia|abkhazia|conj
comprise|autonomy|subj
comprise|"|punc
government|local|nn
comprise|government|obj
government|elected|vrel
elected|freely|mod
include|that|subj
branch|executive|nn
include|branch|obj
branch|and|punc
branch|parliament|conj
georgia|and|punc
georgia|moldovia|conj
issued|georgia|subj
declaration|joint|mod
issued|declaration|obj
movements|separatist|mod
declaration|movements|against
called for|saakashvili|subj
conference|"|punc
conference|new|mod
conference|yalta|nn
called for|conference|obj
called for|"|punc
called for|extend|mod
extend|saakashvili|subj
extend|"|punc
extend|liberty|obj
liberty|"|punc
region|black sea|nn
liberty|region|throughout
georgia|and|punc
georgia|abkhazia|conj
met with|georgia|subj
envoy|un|nn
met with|envoy|obj
envoy|form|rel
form|envoy|subj
group|joint|mod
form|group|obj
group|manage|rel
manage|group|subj
manage|mine|obj1
manage|removal|obj2
removal|and|punc
violations|ceasefire|nn
removal|violations|conj

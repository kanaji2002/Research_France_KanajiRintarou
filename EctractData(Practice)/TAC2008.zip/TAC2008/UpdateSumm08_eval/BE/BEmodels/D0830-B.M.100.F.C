daughter|rader|gen
did|not|neg
turn|daughter|subj
father|her|gen
turn|father|obj
investigators|wichita|nn
continue|investigators|subj
continue|examining|mod
examining|investigator|subj
killings|other|mod
examining|killings|obj
linkage|possible|mod
examining|linkage|for
linkage|btk|to
daughter|rader|gen
dna|daughter|from
facilitated|dna|subj
identification|his|gen
facilitated|identification|obj
disk|computer|nn
final|rader|gen
disk|final|in
church|his|gen
linked|church|to
charged|march 31|on
charged|rader|obj
murders|10 first-degree|nn
charged|murders|with
was|$10 million|pred
appearance|his|gen
appearance|next|post
appearance|court|nn
was|march 15|pred
waived|rader|subj
hearing|his|gen
hearing|april 19|nn
hearing|preliminary|mod
waived|hearing|obj
plead|he|subj
guilty|not|mod
plead|guilty|desc
guilty|arraignment|at
plead|may 3|mod
plead|not|mod-before
plead|insanity|obj
insanity|or|punc
bargain|plea|nn
insanity|bargain|conj
is|no|pred
secluded|longer|mod
no|secluded|pnmod
prisoners|other|mod
secluded|prisoners|from
expected|kansas|subj
expected|pay|fc
pay|kansas|subj
pay|$405,000|obj
defense|rader|gen
$405,000|defense|for

april 2005|judiciary committee|appo
judiciary committee|approved|vrel
approved|judiciary committee|obj
confirmation|u.s. senate|nn
approved|confirmation|for
judiciary committee|nomination|appo
nomination|janice rogers brown|of
of appeals|u.s.|nn
of appeals|circuit|nn
janice rogers brown|of appeals|to
of appeals|district of columbia|of
leader|democratic|mod
leader|senate|nn
leader|minority|nn
leader|reid|person
promised|leader|subj
promised|filibuster|fc
filibuster|leader|subj
filibuster|her|against
leader|republican|mod
leader|senate|nn
leader|majority|nn
leader|frist|person
threatened|leader|subj
maneuver|parliamentary|mod
threatened|maneuver|obj
maneuver|change|rel
change|maneuver|subj
rules|senate|nn
change|rules|obj
eliminate|permanently|amod
rules|eliminate|rel
eliminate|rule|subj
eliminate|filibusters|obj
confirmations|judicial|mod
filibusters|confirmations|in
eliminate|including|mod
nominees|supreme court|nn
including|nominees|obj
senators|six|nn
senators|republican|nn
senators|and|punc
democratic senators|six|nn
senators|democratic senators|conj
considered|senators|subj
considered|pact|obj
pact|vote|rel
vote|pact|subj
vote|prevent|mod
filibusters|judicial|mod
prevent|filibusters|obj
prevent|except|mod
in|"|punc
circumstances|extreme|mod
changes|circumstances|in
circumstances|"|punc
circumstances|and|punc
filibuster|defeat|nn
circumstances|filibuster|conj
except|changes|comp1
changes|rule|subj
confirmation|brown|gen
vote|confirmation|on
expected|vote|obj
may|late|mod
expected|may|in

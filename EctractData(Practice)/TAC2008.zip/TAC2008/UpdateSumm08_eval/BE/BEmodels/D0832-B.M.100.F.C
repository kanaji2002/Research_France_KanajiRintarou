pleaded|november 28 , 2005|on
pleaded|cunningham|subj
pleaded|guilty|desc
guilty|conspiracy|to
conspiracy|commit|rel
commit|conspiracy|subj
$2.4 million|least|post
commit|$2.4 million|at
$2.4 million|bribes|in
ever|most|mod
congressional|ever|mod
bribes|congressional|mod
bribes|bribes|conj
bribes|and|punc
evasion|$1 million|nn
evasion|tax|nn
bribes|evasion|conj
indicted|wade|obj
co-conspirators|three|nn
co-conspirators|unindicted|mod
were|brent wilkes|pred
brent wilkes|adcs|appo
asked for|prosecutors|subj
years|20|amount-value
incarceration|years|nn
asked for|incarceration|obj
incarceration|but|punc
years|requested|mod
years|10|amount-value
incarceration|years|conj
years|payment|conj
payment|$1.5 million|of
$1.5 million|taxes|in
taxes|and|punc
taxes|penalties|conj
penalties|and|punc
penalties|forfeiture|conj
forfeiture|$1.85 million|of
$1.85 million|bribes|in
february 24|pled|mod
february 24|guilty|mod
sentenced|march 3|on
sentenced|cunningham|obj
years|eight|amount-value
sentenced|years|to
years|and|punc
months|four|amount-value
years|months|conj
months|longest|conj
longest|congressman|for
congressman|and|punc
restitution|$1.8 million|nn
congressman|restitution|conj

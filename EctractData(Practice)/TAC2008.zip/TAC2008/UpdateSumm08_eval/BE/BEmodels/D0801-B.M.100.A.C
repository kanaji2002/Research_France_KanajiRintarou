delayed|june 1 , 2005|by
june 1 , 2005|customizing|rel
customizing|june 1, 2005|subj
customizing|a380s|obj
a380s|15|for
requirements|different|mod
requirements|client|nn
delayed|notably|mod-before
systems|different|mod
systems|passenger|nn
systems|entertainment|nn
notably|systems|for
delayed|requirements|subj
months|deliveries|nn
8|up to|num-mod
months|8|amount-value
delayed|months|obj
delayed|risking|mod
risking|requirement|subj
risking|millions|obj
millions|penalties|in
delivery|first|post
delivery|a380|nn
delivery|(|punc
delivery|singapore|to
slid|)|punc
slid|delivery|subj
early|late 2006|to
orders|159|num
fell|orders|with
customers|16|num
orders|customers|from
customers|and|punc
options|100|num
customers|options|conj
fell|production|subj
fell|demand|behind
fell|raising|mod
raising|production|subj
raising|price|obj
price|u.s. $292 million|to
problems|possible a380|nn
problems|air|mod
problems|turbulence|nn
requiring|potentially|amod
problems|requiring|rel
requiring|problem|subj
rule-making|icao|nn
requiring|rule-making|obj
failure|wing|nn
failure|load|nn
failure|test|mod
rule-making|failure|conj
failure|and|punc
injuries|passenger|nn
failure|injuries|conj
evacuation|simulated|mod
injuries|evacuation|during
deliveries|slow|mod
be|2006 20|by
be|a380-ready|pred
38|2008|by
60|2010|by

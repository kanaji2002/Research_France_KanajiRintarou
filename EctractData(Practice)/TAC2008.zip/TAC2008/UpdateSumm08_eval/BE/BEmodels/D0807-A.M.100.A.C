indicted|october 28 , 2005|on
indicted|lewis libby|obj
counts|two|nn
indicted|counts|on
counts|making|of
making|lewis libby|subj
making|false statements|obj
counts|two|nn
counts|perjury|nn
false statements|counts|conj
counts|and|punc
counts|obstruction|conj
obstruction|justice|of
investigation|special prosecutor patrick fitzgerald|gen
making|investigation|by
revelation|possible|mod
revelation|intentional|mod
revelation|illegal|mod
investigation|revelation|into
revelation|identify|of
valerie plame|cia|nn
valerie plame|covert|mod
valerie plame|operative|mod
identify|valerie plame|of
testimony|libby|gen
contradicted|testimony|obj
contradicted|by|by-subj
contradicted|witnesses|by
indicted|others|obj
indicted|as|mod
jury|grand|nn
as|extended|comp1
extended|jury|obj
remains|karl rove|subj
remains|investigation|under
fight|libby|subj
fight|charges|obj
charges|which|whn
have|charges|subj
penalties|maximum|mod
have|penalties|obj
years|30|amount-value
penalties|years|of
years|and|punc
years|$1.25 million|conj
jailed|judith miller|obj
days|85|num
jailed|days|mod
testifying|judith miller|subj
testifying|and|punc
testifying|surrendering|conj
surrendering|judith miller|subj
surrendering|notes|obj
surrendering|after|mod
rescinded|formally|mod-before
after|rescinded|comp1
rescinded|libby|subj
agreement|their|gen
agreement|confidential|mod
agreement|source|nn
rescinded|agreement|obj

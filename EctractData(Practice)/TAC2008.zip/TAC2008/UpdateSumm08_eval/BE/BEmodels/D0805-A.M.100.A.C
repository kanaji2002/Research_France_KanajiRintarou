enrollment|medicare|nn
enrollment|part|nn
enrollment|d|mod
beneficiaries|medicare|nn
enrollment|beneficiaries|for
began|enrollment|subj
began|november 15 , 2005|mod
began|though|mod
began|may 15 , 2006|mod
began|coverage|for
coverage|starting|rel
starting|coverage|subj
starting|january 1 , 2006 ,|mod
penalty|1%|nn
starting|penalty|with
penalty|month|per
enrollment|late|mod
penalty|enrollment|for
expired|part d drug discount card|subj
expired|may 15|mod
campaign|$100-million|mod
campaign|information|nn
felt|campaign|after
33%|seniors|of
felt|33%|subj
felt|informed|desc
thought|37%|nn
thought|benefit|comp1
benefit|they|subj
seniors|choosing|rel
choosing|senior|subj
part|medicare|subj
plan|d-approved|mod
plan|private|mod
plan|drug|nn
plan|insurance|nn
part|plan|obj
risk|seniors|subj
risk|loosing|fc
loosing|senior|subj
insurance|their|gen
insurance|other|mod
insurance|medical|mod
loosing|insurance|obj
used|employers|subj
subsidies|part|nn
subsidies|d|mod
subsidies|federal|mod
used|subsidies|obj
subsidies|reduce|rel
reduce|subsidy|subj
premiums|retirees|gen
premiums|overall|mod
premiums|health|nn
reduce|premiums|obj
dropped|others|subj
plans|retiree|nn
plans|health|nn
dropped|plans|obj
dropped|entirely|mod
beneficiaries|40 million|nn
beneficiaries|elderly|mod
beneficiaries|medicare|nn
enter|28 million|subj
enter|part d.|obj

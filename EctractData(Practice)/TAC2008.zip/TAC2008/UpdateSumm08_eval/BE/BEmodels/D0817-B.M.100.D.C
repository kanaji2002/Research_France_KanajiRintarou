sued|armstrong|subj
sued|sca promotions|obj
sca promotions|breach of contract|for
breach of contract|based|vrel
based|breach of contract|obj
charges|l 'equip|gen
based|charges|on
verbruggen|icu|gen
refuted|verbruggen|subj
pound|wada|gen
claims|pound|gen
refuted|claims|obj
gave|verbruggen|subj
information|l 'equip|nn
gave|information|obj1
information|linking|rel
linking|information|subj
linking|armstrong|obj
armstrong|positive|to
positive|1999|num
results|erythropoietin|nn
gave|results|obj2
claimed|verbruggen|subj
claimed|blocked|fc
blocked|pound|subj
investigation|icu|gen
blocked|investigation|obj
blocked|and|punc
blocked|made|conj
made|pound|subj
made|"|punc
made|transparently|punc
statements|erroneous|mod
made|statements|obj
international olympic athletes commission|and|punc
both|summer olympic sports|nn
international olympic athletes commission|both|conj
demanded|international olympic athletes commission|subj
lab|wada|gen
demanded|suspended|fc
suspended|lab|obj
violating|illegally|amod
violating|lab|subj
code|wada|nn
violating|code|obj
ioc|and|punc
ioc|icu|conj
appointed|each|mod-before
appointed|ioc|subj
investigators|independent|mod
appointed|investigators|obj
issues|all|pre
investigators|issues|into
issues|relating|rel
relating|issue|subj
tests|tour|gen
tests|1999|num
tests|positive|mod
relating|tests|to

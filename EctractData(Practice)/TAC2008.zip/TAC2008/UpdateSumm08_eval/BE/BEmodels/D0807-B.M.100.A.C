indictment|libby|gen
told|indictment|after
bob woodward|reporter|nn
told|bob woodward|subj
told|special prosecutor patrick fitzgerald|obj
told|that|c
one|about|num-mod
month|one|amount-value
identity|valerie plame|gen
month|identity|before
exposed|month|obj
learned|he|subj
learned|it|obj
official|bush|nn
official|administration|nn
learned|official|from
official|(|punc
official|not|appo-mod
official|libby|appo
revealed|karl rove|subj
revealed|identify|fc
identify|plame|subj
identify|to|guest
identify|time|to
matt cooper|magazine|nn
matt cooper|reporter|nn
identify|matt cooper|obj
identify|days|mod
identify|before|mod
before|revealed|comp1
revealed|libby|subj
revealed|it|obj
robert novak|columnist|nn
revealed|robert novak|to
investigation|plame|nn
investigation|identity|nn
investigation|leak|nn
testimony|investigation|gen
testimony|grand jury|nn
portions|testimony|of
unsealed|portions|obj
told|libby|subj
jury|grand|nn
told|jury|obj
told|that|c
president|cheney|person
authorized|president|subj
authorized|him|obj
authorized|leak|mod
leak|vice president|subj
information|classified|mod
leak|information|obj
disputed|fitzgerald|subj
motion|libby|gen
disputed|motion|obj
judge|federal|mod
motion|judge|to
judge|dismiss|rel
dismiss|judge|subj
indictment|his|gen
dismiss|indictment|obj
dismiss|claiming|mod
claiming|appointed|fc
appointed|prosecutor|obj
appointed|unconstitutionally|mod

is|october , 2004 ,|in
ordered|pa school board|subj
ordered|that|c
students|biology|nn
told|students|obj
is|"|punc
told|is|fc
is|theory|pred
is|not|mod
fact|"|punc
fact|and|punc
fact|"|punc
design|intelligent|mod
fact|design|conj
is|explanation|pred
explanation|origin|of
origin|life|of
life|that|whn
differs|life|subj
differs|"|punc
differs|evolution|from
differs|and|punc
differs|encouraged|conj
encouraged|life|obj
encouraged|read|mod
read|"|punc
& people", added to the school library.|pandas|nn
read|& people", added to the school library.|of
began|trial|subj
began|september , 26 ,|mod
september , 26 ,|2005|num
argued|plaintiffs|subj
design|intelligent|mod
argued|is|fc
is|not|neg
is|scientific|pred
scientific|but|punc
scientific|religious|conj
members|board|nn
had|members|subj
motivation|religious|mod
had|motivation|obj
design|intelligent|mod
design|and|punc
design|"|punc
design|pandas|conj
recast|"|punc
recast|design|obj
creationism|which|whn
banned|creationism|obj
classes|public school|nn
classes|science|nn
banned|classes|from
classes|supreme court|by
supreme court|violation|as
amendment|first|post
clause|amendment|gen
clause|establishment|nn
violation|clause|of

withdrawal|security council resolution 1559|nn
withdrawal|mandated|mod
of|"|punc
syria|foreign|mod
syria|forces|nn
syria|"|punc
syria|(|punc
troops|syria|gen
withdrawal|troops|of
troops|and|punc
agents|intelligence|nn
troops|agents|conj
agents|)|punc
agents|lebanon|from
assassination|february 14 , 2005|nn
told|assassination|after
lebanon|former|mod
assassination|lebanon|of
hariri|prime minister|title
told|anon|mod-before
told|hariri|subj
told|syria|obj
syria|withdraw|rel
withdraw|syria|subj
withdraw|april|before
withdraw|threatening|mod
threatening|sanctions|obj
egypt|and|punc
egypt|saudi arabia|conj
asked|egypt|subj
asked|syria|obj
syria|withdraw|rel
withdraw|syria|subj
withdraw|april 30|by
taif accord|1989|num
withdraw|taif accord|under
government|lebanon|gen
government|pro-syria|nn
resigned|government|subj
resigned|march 1.|mod
sent|march 12|on
sent|anon|subj
sent|envoy roed-larsen|obj
envoy roed-larsen|syria|to
syria|ultimatum|with
troops|all|pre
withdraw|troops|obj
asked|eu foreign ministers|subj
asked|syria|obj
implement|rapidly|amod
syria|implement|rel
implement|syria|subj
pledge|its|gen
implement|pledge|obj

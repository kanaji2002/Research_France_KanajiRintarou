UN Security Council Resolution 1559 mandated withdrawal of "foreign forces" (Syria's troops and intelligence agents) from Lebanon.
After the February 14, 2005 assassination of former Lebanon Prime Minister Hariri, Anon told Syria to withdraw before April, threatening sanctions.
Egypt and Saudi Arabia asked Syria to withdraw by April 30, under the 1989 Taif Accord.
Lebanon's pro-Syria government resigned March 1.
On March 12 Anon sent envoy Roed-Larsen to Syria with an ultimatum.
Syria pledged to withdraw all troops.
EU Foreign Ministers asked Syria to rapidly implement its pledge.

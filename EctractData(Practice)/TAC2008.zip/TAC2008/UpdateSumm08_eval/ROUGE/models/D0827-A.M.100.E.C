When Hurricane Katrina hit Louisiana, Mississippi, and Alabama on August 29, 2005 rescue crews worked frantically to save hundreds of people trapped by floodwaters.
By September 8, the US death toll had reached 118.
There was one reported death in Guatemala.
FEMA's Katrina disaster response efforts cost $US 2.87 million as of September 6, 2005.
By September 12, Swiss Reinsurance Company, estimated $US 40 billion global insured losses in the United States from Hurricane Katrina.
The Emir of Qatar donated $US 100 million for US victims of Katrina.
Uganda pledged $US 200,000 toward Katrina relief and rebuilding in the US.

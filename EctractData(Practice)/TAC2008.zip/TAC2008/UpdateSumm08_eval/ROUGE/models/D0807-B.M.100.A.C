After Libby's indictment, reporter Bob Woodward told Special Prosecutor Patrick Fitzgerald that about one month before Valerie Plame's identity was exposed, he had learned it from another Bush administration official (not Libby).
Karl Rove revealed Plame's identify to Time magazine reporter Matt Cooper days before Libby revealed it to columnist Robert Novak.
Portions of the Plame identity leak investigation's grand jury testimony were unsealed.
Libby had told the grand jury that Vice President Cheney had authorized him to leak classified information.
Fitzgerald disputed Libby's motion to a federal judge to dismiss his indictment, claiming the Prosecutor was appointed unconstitutionally.

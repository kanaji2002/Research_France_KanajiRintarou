Other power grid vulnerabilities include accidental line cuts during maintenance, equipment malfunction or failure, old grid infrastructure and poor grid design causing power loss over wider areas.
Improvements in grid architectures will increase network resilience.
Deregulation resulted in lower margins for reserve power capacity and transmission capacity, as well as loss of experienced personnel.
As companies specialized more in generation or transmission, supervisory data became proprietary and unavailable to regional grid managers.
An August 2005 federal law will create a process for mandating reliability rules.
Energy conservation and smart appliances that cut back during power grid stresses can avert blackouts.

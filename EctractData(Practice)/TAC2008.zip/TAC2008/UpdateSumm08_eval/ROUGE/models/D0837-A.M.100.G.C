Barack Obama graduated Harvard Law School as the first black President of the Harvard Law Review.
In 2004 three-term Illinois State Senator Barack Obama won the U.S. Senate seat, with support from white liberals, the white middle class and Chicago south side blacks, to become the third black U.S. Senator in 150 years.
He raised a $14 million campaign fund, and gave $400,000 to other Democratic candidates.
His lauded keynote speech at the 2004 Democratic Convention kindled such star power he was recruited to stump in a dozen states for presidential nominee John Kerry.

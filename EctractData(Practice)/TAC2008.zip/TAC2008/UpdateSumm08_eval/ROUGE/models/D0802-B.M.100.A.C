Arctic sea ice is melting faster.
Its area is down 20% and it all could disappear this century.
Thinning sea ice threatens extinction of polar bears.
Less ice reflects less sunlight, warming the planet, leading to more ice melt and sea-level rise.
Greenland and Antarctic ice shelf melting will double the estimated global sea level rise to 1 meter.
Arctic permafrost thaw releases warming greenhouse gases, which will increase permafrost melting up to 11 feet deep by 2100.
Greenland's ice fishing season has shortened.
Lake areas doubled.
Glaciers Sermeg, Sermilik, and Kangerdlugssuag melted faster.
Alaska's Columbia glacier also melted faster.

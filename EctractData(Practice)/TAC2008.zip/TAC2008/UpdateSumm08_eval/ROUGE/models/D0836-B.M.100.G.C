China's National Special Program for Food Security assists Nigeria eliminate poverty through Bamboo-based development, using Nigeria's existing under utilized bamboo forests to turn out about 300 byproducts.
Over 20 insects plague northwest China's arrow bamboo, a major food source for giant Pandas.
The U.S. National Zoo's research advances in giant panda reproductive cycles and artificial insemination will increase endangered giant panda populations in captivity and in the wild.
India is building two commercially viable, environmentally friendly, one-megawatt, "green power" bamboo gasification-based electricity plants.
A wide variety of bamboo fiber rugs are available, including kiln-dried and carbonized bamboo with polyurethane coatings.

On May 23, 2005 sports newspaper L'Equip reported Armstrong illegally used erythropoietin for the 1999 Tour de France, based on urine samples examined outside World Anti-Doping Agency protocols, but linked to Armstrong by L'Equip, in violation of WADA anonymity rules.
Tour Director Leblanc accepted the charge uncritically, but discipline seemed unlikely because WADA testing was impossible.
The French Sports Minister agreed.
USA Cycling, Miguel Indurain, and Ed Coyle defended Armstrong.
Armstrong took erythropoietin during cancer treatments before 1999.
An International Cycling Union investigation of 1999 drug testing is pending.
Alessandro Donati suggested without evidence that Armstrong used other banned substances.

Taylor vanished the night of March 27, after the Nigerian government said it would end his asylum and allow him to face indictment by an international court in Sierra Leone.
On March 29 he was arrested by Nigeria police trying to escape into Cameroon.
He was detained under guard, flown to Liberia, arrested by UN peacekeeping forces, and extradited by helicopter to Sierra Leone on March 30.
The Special Court in Sierra Leon indicted Taylor on 11 counts of crimes against humanity, making him the first African head of state to face an international war crimes tribunal.

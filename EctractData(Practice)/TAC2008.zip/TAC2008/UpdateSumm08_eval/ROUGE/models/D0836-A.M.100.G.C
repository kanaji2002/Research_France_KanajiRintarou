Bamboo shoots must be properly prepared to avoid consuming naturally produced hydrogen cyanide.
Bamboo can help makeshift buildings better withstand earthquakes.
Innovative bamboo products include: hardwood flooring, paneling, cabinets, countertops, utensils, plates, bowls, cutting boards, shower curtains, and products based on fiber, fiber pulps or veneers.
Bamboo's has greater tensile strength than steel.
It can be harvested every 3 to 5 years, but entire bamboo stands die-off every 60 years, threatening crop collapse and endangering China's endangered Giant Pandas, who are dependent on arrow bamboo.

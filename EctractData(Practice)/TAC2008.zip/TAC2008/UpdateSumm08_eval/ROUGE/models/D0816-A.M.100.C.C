In February 2005 North Korea declared it manufactured nuclear weapons and won't rejoin six-nation talks (North Korea, South Korea, China, Russia, Japan, U.S.).
In May the IAEA reported N.K. had close to six nuclear weapons.
N.K. and S.K. resumed direct talks.
In July N.K. returned to six-nation talks after the U.S. recognized N.K.'s sovereignty.
S.K. offered N.K. food, electricity, APEC membership, a multinational rehabilitation fund, and to establish a Northeast Asian Development Bank, if N.K. abandons nuclear weapons, which the U.S. called "premature".
N.K. said it would return to the Nuclear Non-Proliferation Treaty, after its nuclear weapons program was resolved.

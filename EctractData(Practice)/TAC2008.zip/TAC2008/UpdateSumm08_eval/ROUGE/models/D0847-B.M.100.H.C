On March 24, 2005 protestors stormed the main Kyrgystan government building and Akayev fled to Russia.
The elected pro-Akayev parliament nonetheless elected an Akayev opponent as Speaker and called for new presidential elections on June 26.
On April 3, Akayev signed his resignation in Moscow, which was notarized in lieu of a constitutional requirement that he present his resignation in person to parliament.
Because his safety still could not be guaranteed, due to continued calls for his impeachment, his recorded resignation was to be heard and accepted by a special session of parliament on April 6 and broadcast live.

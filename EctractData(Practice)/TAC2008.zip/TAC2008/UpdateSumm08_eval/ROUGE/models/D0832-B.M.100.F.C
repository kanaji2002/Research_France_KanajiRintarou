On November 28, 2005 Cunningham pleaded guilty to conspiracy to commit at least $2.4 million in bribes, the most ever congressional bribes, and $1 million tax evasion.
Wade was indicted.
Three unindicted co-conspirators were Brent Wilkes, ADCS, Inc. Thomas Kontogiannis; and John T. Kongogiannis.
Prosecutors could have asked for 20 years incarceration, but requested 10 years, payment of $1.5 million in taxes and penalties, and forfeiture of $1.85 million in bribes.
Wade pled guilty February 24, awaiting sentencing.
On March 3, Cunningham was sentenced to eight years and four months, the longest for any congressman, and $1.8 Million restitution.

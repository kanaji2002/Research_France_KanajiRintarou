On October 28, 2005 Lewis Libby was indicted on two counts of making false statements, two perjury counts and obstruction of justice, by Special Prosecutor Patrick Fitzgerald's investigation into possible intentional, illegal revelation of the identify of CIA covert operative Valerie Plame.
Libby's testimony was contradicted by several witnesses.
No others were indicted as the grand jury was extended and Karl Rove remains under investigation.
Libby will fight the charges, which have maximum penalties of 30 years and $1.25 million.
Judith Miller had been jailed 85 days before testifying and surrendering notes, after Libby formally rescinded their confidential source agreement.

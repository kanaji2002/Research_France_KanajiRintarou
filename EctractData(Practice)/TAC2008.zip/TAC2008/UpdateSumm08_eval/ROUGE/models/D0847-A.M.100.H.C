In February 2005 rallies in Bishkek urged President Akayev to step down as promised and constitutionally required after October presidential elections, fearing a referendum to continue his reign.
Akayev supporters won a landslide parliamentary victory.
Opposition leaders and the European Organization for Security and Cooperation charged the elections were flawed.
By March 16 opposition forces rallied, blocked roads, occupied government buildings, demanded Akayev's resignation, and took hostage a regional governor and district chief.
On March 20 four policemen were beaten after police fired shots at demonstrators.
Akayev ordered investigations into election fraud charges and fired the interior minister and prosecutor-general.

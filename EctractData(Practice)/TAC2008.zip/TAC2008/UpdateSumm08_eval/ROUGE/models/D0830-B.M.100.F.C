Rader's daughter did not turn her father in to police.
Wichita investigators continue examining other killings, for possible linkage to BTK.
Reportedly, DNA from Rader's daughter facilitated his identification.
A computer disk in Rader's final mailing linked to his church.
On March 31 Rader was charged with 10 first-degree murders.
Bail was $10 million.
His next court appearance was March 15.
Rader waived his April 19 preliminary hearing.
He would plead not guilty at arraignment May 3, and not plead insanity or plea bargain.
Rader is no longer secluded from other prisoners.
Kansas expected to pay $405,000 for Rader's defense.

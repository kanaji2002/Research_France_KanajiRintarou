Barack Obama is the 5th black Senator in U.S. history.
In 2005 he received Harvard Law School's highest award, at which he criticized the Katrina debacle.
He published a Time magazine article about President Lincoln.
He criticized the Bush administration and called for troop withdrawal from Iraq.
In 2006 he met with the Foreign Minister in Israel.
First term Senator Obama and senior Senator McCain worked on ethics reform, had a public spat, and made nice.
As Democratic Senatorial Campaign Committee Vice Chairman, he helped raise $6.5 million.
He won a Grammy for his audio book "Dreams of My Father".

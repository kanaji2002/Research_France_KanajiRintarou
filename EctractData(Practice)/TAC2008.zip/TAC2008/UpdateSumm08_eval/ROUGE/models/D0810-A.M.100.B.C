As late as December 21, 2004, Franklin Raines was said to be still under criminal investigation by the Justice Department for alleged financial accounting manipulations at Fannie Mae.
It is not clear if Raines himself was ever under criminal investigation related to criminal charges against Time Warner and AOL, which the two companies together paid over $500 million to settle in December 2004.
Those charges stemmed from alleged fraudulent accounting practices dating back to when AOL was a separate company and Director Raines was a member of AOL's audit committee.

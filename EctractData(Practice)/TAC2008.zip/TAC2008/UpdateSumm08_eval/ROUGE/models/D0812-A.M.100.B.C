In January 2004, Saakashvili regained control of Adzharia.
Georgia searched ships arriving in Abkhazia.
Saakashvili offered "widest possible autonomy" to Abkhazia and South Ossetia.
Georgian troops entered South Ossetia despite threats of Russian intervention.
Georgian coast guards fired on a Turkish ship near Abkhazia.
Georgia threatened withdrawal from the Commonwealth of Independent States.
Georgia and South Ossetia agreed to mutual withdrawal of troops.
Georgia said it would not start a war and denied stationing 700 troops on the Abkhazia border.
Saakashvilli was to make official proposals to Abkhazia and South Ossetia and finalize a framework agreement on relations with Russia.

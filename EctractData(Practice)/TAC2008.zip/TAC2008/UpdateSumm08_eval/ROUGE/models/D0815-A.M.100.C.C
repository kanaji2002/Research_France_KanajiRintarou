In April 2005, the Judiciary Committee approved and sent for U.S. Senate confirmation, the nomination of Janice Rogers Brown to the U.S. Circuit Court of Appeals of the District of Columbia.
Democratic Senate Minority Leader Reid promised to filibuster against her.
Republican Senate Majority leader Frist threatened a parliamentary maneuver to change Senate rules to permanently eliminate filibusters in judicial confirmations, including Supreme Court nominees.
Six Republican Senators and six Democratic Senators considered a pact to vote to prevent judicial filibusters, except in "extreme circumstances", and defeat filibuster rule changes.
The vote on Brown's confirmation was expected in late May.

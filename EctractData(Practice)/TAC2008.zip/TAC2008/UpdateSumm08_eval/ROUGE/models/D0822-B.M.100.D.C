By May 23, 2005, a UN team verified the pullout of all Syrian troops and intelligence agents from Lebanon.
In June, President Bush warned Syria to withdraw its remaining intelligence agents in Lebanon.
Syria denied having any intelligence agents in Lebanon.
The UN verification mission went back to Lebanon to ascertain the facts.
The UN said it was encouraged by talks with Syria's President regarding evidence from several countries that Syrian intelligence agents were still in Lebanon.
Egypt and Saudi Arabia discussed the Syria-Lebanon situation.
The U.S. reiterated its certainty that Syrian intelligence agents remained in Lebanon.

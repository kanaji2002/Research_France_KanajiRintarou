Emirate Airlines ordered the first passenger A380 five months before its December 2000 launch.
In January Federal Express ordered the first cargo A380.
Thirteen non-American airlines have placed 154 orders; China and Hong Kong have options.
Commercial deliveries begin first quarter 2006 to Singapore.
A380s will land at 25 airports worldwide, including New York, Los Angeles, San Francisco, Miami, Chicago, Dulles, Memphis and Anchorage.
In February 2001 Airbus's Hamburg plant expanded.
Toulouse production started in January 2002.
In July 2003 Broughton, Wales got an Airbus plant.
The first A380 arrived in January 2005, taking its maiden flight April 27.

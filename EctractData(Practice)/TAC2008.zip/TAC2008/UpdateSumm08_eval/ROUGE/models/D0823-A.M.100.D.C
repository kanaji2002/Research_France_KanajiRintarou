In Ukraine's 2004 presidential campaign, pro-western candidate Yushchenko claimed he was poisoned by supporters of pro-Russian candidate, current Prime Minister Yanukovich.
International observers alleged election violations.
Yanukovich moved the Kiev Liberation Day military parade to October 29, raising fears of a military crackdown or canceled elections.
State media denied Yushchenko any coverage.
Students and public employees were pressured to vote for Yanukovich.
Yanukovich raised pensions before the elections.
On October 31, Yushchenko got 39.82%, Yanukovich 39.32%.
An emergency Parliament meeting without a quorum reversed Yanukovich's November 21 victory.
A healthier Yushchenko proposed new elections.
Yanukovich offered Yushchenko the Prime Ministry.

After Taylor fled Liberia, he took comfortable asylum in Nigeria, agreeing not to interfere in Liberia or other countries.
Nigeria would return him to Liberia, only if a newly elected Liberia government formally requested it, but not directly to an international war crimes court in Sierra Leone.
From Nigeria, Taylor meddled in Liberia's elections and implicated Al-Qaida and blood diamonds in his attempted assassination of Guinea's president, so he could move to Guinea.
In March 2006 the new Liberian president requested Taylor be released to Sierra Leone vice Liberia.
President Bush and Obasanjo were to discuss Taylor on March 29.

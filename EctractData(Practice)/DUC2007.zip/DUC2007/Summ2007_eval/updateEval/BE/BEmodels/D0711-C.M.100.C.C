ruled|april 2000|in
judge|jackson|person
ruled|judge|subj
ruled|that|c
violated|microsoft|subj
act|sherman|nn
act|antitrust|mod
violated|act|obj
wrote|he|subj
maintained|company|subj
power|its|gen
power|monopoly|nn
maintained|power|obj
means|anticompetitive|mod
power|means|by
maintained|attempted|conj
attempted|company|subj
attempted|monopolize|fc
monopolize|company|subj
market|web|nn
market|browser|nn
monopolize|market|obj
attempted|and|punc
tied|unlawfully|mod-before
attempted|tied|conj
tied|company|subj
browser|its|gen
browser|web|nn
tied|browser|obj
browser|operating system|to
justice department|and|punc
general|17|num
general|state attorneys|nn
justice department|general|conj
proposed|justice department|subj
proposed|breaking|fc
breaking|justice department|subj
breaking|microsoft|obj
breaking|up|mod
companies|two|nn
up|companies|into
one|holding|rel
holding|one|subj
holding|operating system|obj
everything|other|mod
judge|jackson|person
agreed|judge|subj
agreed|proposal|with
announced|bill gates|subj
announced|that|c
company|his|gen
appeal|company|subj
appeal|verdict|obj
verdict|which|whn
characterized|verdict|obj
attack|anti-capitalist|mod
characterized|attack|as
attack|that|whn
be|harmful|pred
harmful|microsoft|to
microsoft|and|punc
microsoft|economy|conj

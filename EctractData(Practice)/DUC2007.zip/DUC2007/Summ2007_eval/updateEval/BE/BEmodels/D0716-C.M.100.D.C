november 1998|u.n.|appo
government|australian|mod
lobbying|government|by
government|decided|vrel
decided|government|obj
decided|put|mod
put|kakadu national park|obj
list|its|gen
list|endangered|mod
kakadu national park|list|on
put|but|punc
put|asked for|conj
report|detailed|mod
asked for|report|obj
report|april 15th|by
april 15th|1999|num
done|what|obj
done|prevent|mod
damage|further|mod
prevent|damage|obj
prevent|and|punc
prevent|mitigate|conj
threats|all|pre
mitigate|threats|obj
threats|kakadu park|to
mine|jabiluka|nn
kakadu park|mine|by
said|environment minister robert hill|subj
report|unesco|nn
said|made|fc
made|report|obj
visit|just|pre
day|four|amount-value
visit|day|nn
made|visit|after
visit|area|to
made|and|punc
made|ignored|conj
ignored|report|subj
volume|large|mod
ignored|volume|obj
volume|evidence|of
evidence|gathered|vrel
gathered|evidence|obj1
18|over|num-mod
years|18|amount-value
gathered|years|obj2
years|mining|of
mine|nearby|mod
mine|ranger|nn
mining|mine|at

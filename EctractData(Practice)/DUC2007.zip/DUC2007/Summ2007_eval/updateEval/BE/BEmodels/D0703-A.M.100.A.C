nations|european union|nn
eu|(|punc
european union|eu|abbrev
eu|)|punc
agreed|nations|subj
agreed|that|c
currency|single|mod
currency|(|punc
currency|euro|appo
go into|)|punc
go into|currency|subj
go into|effect|obj
effect|january 1 , 1999|on
indicate|polls|subj
support|but|punc
skepticism|widespread|mod
support|skepticism|conj
indicate|remains|fc
remains|support|subj
countries|six|nn
eighty percent|countries|in
say|eighty percent|subj
are|not|neg
informed|well|amod
say|informed|fc
informed|they|obj
worry about|economists|subj
worry about|loss|obj
sovereignty|financial|mod
loss|sovereignty|of
worry about|others|subj
unemployment|rising|mod
worry about|unemployment|obj
unemployment|and|punc
rates|interest|nn
unemployment|rates|conj
say|proponents|subj
say|guarantee|fc
guarantee|euro|subj
stability|currency|nn
guarantee|stability|obj
guarantee|lower|conj
lower|euro|subj
rates|interest|nn
lower|rates|obj
lower|and|punc
lower|contribute to|conj
contribute to|euro|subj
contribute to|unity|obj
unity|eu|of
design|euro|of
required|design|obj
required|include|mod
include|design|subj
languages|five|nn
include|languages|obj
languages|and|punc
languages|symbol|conj
symbol|eu|of
be|"|punc
code|currency|nn
be|code|pred

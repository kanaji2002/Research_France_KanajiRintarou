spain|france|conj
france|ireland|conj
ireland|italy|conj
italy|luxemboug|conj
luxemboug|netherlands|conj
netherlands|austria|conj
austria|portugal|conj
portugal|and|punc
portugal|finland|conj
founding|spain|subj
founding|members|obj
club|euro|nn
members|club|of
britain|and|punc
britain|demark|conj
opted out|britain|subj
opted out|while|mod
greece|and|punc
greece|sweden|conj
while|judged|comp1
not|economically|mod
ready|not|mod-before
ready|greece|subj
ready|join|mod
join|britain|subj
rival|euro|subj
dollar|u.s.|nn
rival|dollar|obj
currency|international|mod
dollar|currency|as
rival|but|punc
will|not|neg
rival|replace|conj
replace|euro|subj
dollar|u.s.|nn
replace|dollar|obj
dollar|choice|as
reserves|foreign|mod
choice|reserves|for
transactions|initial|mod
be|cashless|pred
notes|bank|nn
notes|and|punc
notes|coins|conj
become|notes|subj
january 1st 2002|legal tender|nn
become|january 1st 2002|obj
become|while|mod
currencies|national|mod
while|stop|comp1
stop|currencies|subj
stop|circulating|mod
circulating|currency|subj
circulating|july 1st 2002|by
american citibank|and|punc
plan|dutch abn-amro|nn
american citibank|plan|conj
plan|start|rel
start|plan|subj
start|quoting|mod
quoting|prices|obj
prices|euro|in

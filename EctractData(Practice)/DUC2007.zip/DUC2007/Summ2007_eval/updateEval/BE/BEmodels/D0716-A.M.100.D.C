gave|october 1997|in
government|australian|mod
gave|government|subj
gave|permission|obj
permission|energy resources of australia|to
era|(|punc
energy resources of australia|era|abbrev
era|)|punc
energy resources of australia|open|rel
open|energy resources of australia|subj
mine|jabiluka|nn
mine|uranium|nn
open|mine|obj
mine|edge|on
edge|kakadu national park|of
kakadu national park|which|whn
is|on|pred
is|world heritage list|on
northern territory|australia|gen
is|northern territory|in
conservationists|and|punc
owners|aboriginal|mod
owners|"|punc
owners|mirrar|nn
owners|"|punc
conservationists|owners|conj
owners|land|of
oppose|conservationists|subj
oppose|mine|obj
oppose|while|mod
while|insists|comp1
insists|era|subj
insists|that|c
record|its|gen
record|environmental|mod
proven|record|obj
proven|by|by-subj
operation|16-year|nn
proven|operation|by
mine|ranger|nn
operation|mine|of
located|also|mod-before
mine|located|vrel
located|mine|obj
located|kakadu park|in
after|began|comp1
began|construction|subj
arrested|june 1998 , 112|mid
arrested|protestors|obj
arrested|after|mod
after|overwhelmed|comp1
overwhelmed|they|subj
overwhelmed|police|obj
overwhelmed|and|punc
overwhelmed|stormed|conj
stormed|they|subj
stormed|site|onto

Belgium, Germany, Spain, France, Ireland, Italy, Luxemboug, the Netherlands, Austria, Portugal and Finland are founding members of the Euro club.
Britain and Demark have opted out while Greece and Sweden have been judged economically not ready to join.
The Euro will rival the U.S. dollar as an international currency but will not replace the U.S. dollar as the choice for foreign reserves.
Initial transactions will be cashless.
Bank notes and coins will become legal tender January 1st 2002 while national currencies will stop circulating by July 1st 2002.
American Citibank and Dutch ABN-AMRO plan to start quoting prices in Euro.

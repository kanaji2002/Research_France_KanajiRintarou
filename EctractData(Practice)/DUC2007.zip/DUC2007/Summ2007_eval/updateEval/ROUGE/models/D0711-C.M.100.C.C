In April 2000, Judge Jackson ruled that Microsoft violated the Sherman antitrust act.
He wrote that the company maintained its monopoly power by anticompetitive means, attempted to monopolize the web browser market and unlawfully tied its web browser to the operating system.
The Justice Department and 17 state attorneys general proposed breaking Microsoft up into two companies, one holding the operating system and the other everything else.
Judge Jackson agreed with the proposal.
Bill Gates announced that his company will appeal the verdict which was characterized as an anti-capitalist attack that would be harmful to Microsoft and the economy.

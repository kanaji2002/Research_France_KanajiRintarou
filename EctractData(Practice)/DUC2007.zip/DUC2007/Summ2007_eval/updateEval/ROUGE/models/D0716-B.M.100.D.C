A series of protests followed the start of work at the Jabiluka uranium mine and firebombs caused more than 100,000 Australian dollars damage to a Darwin ERA office.
In October 1998, an eight-member team from the United Nations World Heritage Bureau visited the site and spoke to interest groups, including the ERA.
A month later, the U.N.
Bureau called for closing the Jabiluka mine because it poses a danger to the cultural and natural values of the Kakadu National Park.
The Australian Environment Minister blasted the report as biased, unbalanced and lacking in objectivity.

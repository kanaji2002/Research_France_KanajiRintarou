Antitrust action against Microsoft has been ongoing since 1990.
In 1994, the Justice Department reached a settlement with Microsoft requiring the company to change its business practices.
In 1995, Justice sued to block Microsoft's acquisition of Intuit.
Separate suits were launched against Microsoft by Sun, for violating an agreement on Java and Caldera, for killing Dr. DOS.
In November 1999 Judge Jackson ruled that Microsoft is a monopoly that abused its power and harmed consumers.
If a mediated attempt to settle fails, Judge Jackson will issue a verdict as early as March 28th 2000.

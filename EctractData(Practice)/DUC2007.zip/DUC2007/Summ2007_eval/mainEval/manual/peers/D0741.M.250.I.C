Mark Barton was a loner in high school who dabbled in drugs. He used
chemicals to extract a hallucinogen from morning glory seeds, overdosed
and went to the emergency room. At age 14 he was arrested for breaking
into a drugstore. At 20, he did it again and got off with counseling.

After graduating from the U of SC with a degree in chemistry, he went to
work in Texas and became president of TLC Manufacturing. After being
fired in September 1990, he broke into the building and stole financial
records. He was charged with felony burglary but released when the
company declined to prosecute.

He moved to Georgia with his wife and 2 children, bounced from job to
job and began an affair with newlywed Leigh Ann Lang, 21. In August
1999, his wife and mother-in-law were found hacked to death in a camper
in Alabama. Mark was the prime suspect in the killing but was never
charged for lack of evidence. He collected a large sum from an insurance
policy and later married Leigh Ann.

In October 1998, he killed the family cat, buried it, then spent two
days helping his 8-year-old daughter search for it.

In Early 1999, he quit his chemical job and began day-trading, losing as
much as $450,000 gambling on internet stocks.

In July, Mark Barton, 44, killed his second wife and two children with a
hammer, killed nine people and wounded 12 others at two day-trading
firms in Atlanta, then committed suicide.

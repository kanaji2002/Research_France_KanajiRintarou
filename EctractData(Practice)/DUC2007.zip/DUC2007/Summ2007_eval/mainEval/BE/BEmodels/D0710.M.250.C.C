arrested|november 1998|in
police|greek-cypriot|nn
arrested|police|subj
israelis|two|nn
arrested|israelis|obj
israelis|udi hargov|conj
udi hargov|27|conj
27|and|punc
27|igal damary|conj
igal damary|49|num
arrested|and|punc
arrested|accused|conj
accused|police|subj
accused|them|obj
accused|spying|of
caught|they|obj
scanner|radio|mod
caught|scanner|with
scanner|tapes|conj
police|cypriot|mod
tapes|police|of
police|or|punc
communications|army|nn
police|communications|conj
communications|and|punc
communications|maps|conj
village|fishing|nn
maps|village|in
village|ziyi|of
ziyi|where|wha
exercise|nearby|mod
exercise|cypriot army|nn
taking place|exercise|subj
suspected|cypriots|subj
suspected|were|fc
were|spying|pred
spying|turkey|for
turkey|connection|in
purchase|recent|mod
purchase|greek-cypriot|nn
connection|purchase|to
missiles|russian|mod
missiles|s-300|nn
missiles|anti-aircraft|mod
purchase|missiles|of
were|fears|pred
fears|that|c
train|israel|subj
pilots|turkish|nn
train|pilots|obj
on|bomb|pcomp-c
bomb|israel|subj
sites|missile|nn
bomb|sites|obj
men|two|nn
entered|men|subj
entered|cyprus|obj
passports|false|mod
cyprus|passports|with
passports|october|in
was|evidence|pred
communications|phone|nn
evidence|communications|of
institute|"|punc
institute|intelligence|nn
communications|institute|with
institute|"|punc
institute|tel aviv|in
was|just|mod
arrest|their|gen
just|arrest|prior to
denials|initial|mod
following|denials|obj
denials|that|c
men|two|nn
agents|mossad|nn
were|agents|pred
officials|israeli|mod
began|officials|subj
efforts|diplomatic|mod
began|efforts|obj
efforts|secure|rel
secure|effort|subj
release|their|gen
secure|release|obj
official|senior|mod
agency|israel|gen
agency|mossad|nn
agency|intelligence|nn
official|agency|of
as|"|punc
only|y|as
y|"|punc
resigned|reportedly|amod
y|resigned|vrel
resigned|y|obj
november|late|mod
resigned|november|in
resigned|result|as
result|incident|of
botched|"|punc
botched|third|subj
mission|spy|nn
botched|mission|obj
mission|"|punc
mission|mossad|of
mossad|year|in
dropped|negotiations|after
alecos markides|attorney-general|title
negotiations|alecos markides|between
alecos markides|and|punc
counterpart|his|gen
counterpart|isreali|nn
alecos markides|counterpart|conj
alecos markides|elyakim rubinstein|appo
charges|espionage|nn
dropped|charges|obj
men|two|nn
pleaded|men|subj
pleaded|guilty|desc
charges|lesser|mod
guilty|charges|to
charges|resulting|pnmod
year|three|amount-value
term|year|nn
term|prison|nn
resulting|term|in
term|handed down|vrel
handed down|february 1999|in
pardoned|august 1999,the|in
men|two|nn
pardoned|men|obj1
pardoned|by|by-subj
pardoned|cypriot|by
pardoned|president|obj2
president|glafcos clerides|person
statement|cypriot|mod
statement|government|nn
said|statement|subj
said|that|c
gesture|goodwill|nn
was|gesture|pred
government|new|mod
government|israeli|mod
serve|government|toward
government|ehud barak|of
ehud barak|and|punc
ehud barak|that|conj
detention|men|of
serve|no longer|amod
serve|detention|subj
interest|national|mod
serve|interest|obj

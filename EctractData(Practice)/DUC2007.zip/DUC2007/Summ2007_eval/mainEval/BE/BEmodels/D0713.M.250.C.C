pakistan|and|punc
pakistan|india|conj
failed|pakistan|subj
failed|join|fc
join|pakistan|subj
join|1970|guest
join|nuclear non-proliferation treaty|obj
nnpt|(|punc
nuclear non-proliferation treaty|nnpt|abbrev
nnpt|)|punc
join|blaming|mod
blaming|each other|obj
each other|and|punc
nuclear powers|five|nn
each other|nuclear powers|conj
france|russia|conj
russia|and|punc
russia|united states|conj
behavior|unfair|mod
unfair|and|punc
unfair|discriminatory|conj
united states|behavior|for
maintain|accordance|in
accordance|nnpt|with
nations|those|nn
nations|five|nn
maintain|nations|subj
arsenals|nuclear|mod
maintain|arsenals|obj
conducted|may 1998|in
conducted|pakistan|subj
nuclear explosions|six|nn
nuclear explosions|underground|mod
conducted|nuclear explosions|obj
nuclear explosions|response|in
tests|five|nn
response|tests|to
tests|india|by
condemned|tests|obj
imposed|sanctions|obj
on|both|punc
imposed|countries|on
countries|united states|by
countries|britain|conj
britain|japan|conj
japan|and|punc
nations|other|mod
nations|industrialized|mod
japan|nations|conj
did|not|neg
join|russia|subj
join|imposition|in
imposition|sanctions|of
join|and|punc
join|signed|conj
signed|russia|subj
signed|deal|obj
deal|india|with
india|construction|for
station|nuclear power|nn
construction|station|of
station|kudankulam|in
tests|nuclear|mod
's|tests|pred
president|pakistani|mod
president|nawaz sharif|person
said|president|subj
said|that|c
balance of power|region|in
been|"|punc
been|violently|punc
india|tilted|mod
india|"|punc
been|india|pred
gone to war|pakistan|subj
gone to war|three times|mod
three times|1947|since
gone to war|twice|mod
territory|disputed|mod
twice|territory|over
territory|kashmir|of
claimed|india|subj
claimed|that|c
tests|its|gen
tests|nuclear|mod
were|necessary|pred
necessary|threats|because of
threats|china|by
territory|disputed|mod
china|territory|over
called for|egypt|subj
called for|middle east|obj
region|nuclear-free|mod
be|region|pred
be|and|punc
be|urged|conj
urged|egypt|subj
join|israel|subj
join|nnpt|obj
turkey|and|punc
turkey|iran|conj
called|turkey|subj
called|pakistan|on
pakistan|and|punc
pakistan|india|conj
india|cease|rel
cease|india|subj
testing|nuclear|mod
cease|testing|obj
cease|and|punc
cease|join|conj
join|india|subj
join|comprehensive test ban treaty|obj
ctbt|(|punc
comprehensive test ban treaty|ctbt|abbrev
ctbt|)|punc
called|saudi arabia|subj
called|india|on
india|and|punc
india|pakistan|conj
pakistan|show|rel
show|pakistan|subj
show|restraint|obj
prince|crown|nn
prince|abdullah|person
visited|recently|mod-before
visited|prince|subj
plant|uranium|nn
plant|enrichment|nn
visited|plant|obj
plant|and|punc
factory|missile|nn
plant|factory|conj
factory|pakistan|in
urged|japan|subj
urged|india|obj
india|and|punc
india|pakistan|conj
pakistan|join|rel
join|pakistan|subj
join|ctbt|obj
urged|and|punc
offered|also|amod
urged|offered|conj
offered|japan|subj
offered|countries|obj
countries|conduct|rel
conduct|country|subj
talks|bilateral|mod
conduct|talks|obj
talks|tokyo|in

gave|october 1997|in
government|australian|mod
gave|government|subj
gave|permission|obj
permission|energy resources of australia|to
era|(|punc
energy resources of australia|era|abbrev
era|)|punc
energy resources of australia|open|rel
open|energy resources of australia|subj
mine|jabiluka|nn
mine|uranium|nn
open|mine|obj
mine|edge|on
edge|kakadu national park|of
kakadu national park|which|whn
is|on|pred
is|world heritage list|on
northern territory|australia|gen
is|northern territory|in
produce|mine|subj
tons|19.5 million|amount-value
produce|tons|obj
tons|ore|of
produce|and|punc
produce|generate|conj
generate|mine|subj
dollars|4.46 billion|nn
dollars|u.s.|nn
generate|dollars|obj
years|australia|gen
years|gnp|nn
28|over|num-mod
years|28|amount-value
dollars|years|to
considered|jabiluka|obj1
test|litmus|nn
considered|test|obj2
12|up to|num-mod
mines|12|nn
mines|other|mod
mines|uranium|nn
test|mines|for
mines|australia|in
conservationists|and|punc
owners|aboriginal|mod
owners|"|punc
owners|mirrar|nn
owners|"|punc
conservationists|owners|conj
owners|land|of
oppose|conservationists|subj
oppose|mine|obj
oppose|while|mod
while|insists|comp1
insists|era|subj
insists|that|c
record|its|gen
record|environmental|mod
proven|record|obj
proven|by|by-subj
operation|16-year|nn
proven|operation|by
mine|ranger|nn
operation|mine|of
located|also|mod-before
mine|located|vrel
located|mine|obj
located|kakadu park|in
leader|opposition|nn
leader|kim beazley|person
said|leader|subj
said|stop|fc
stop|labor party|subj
stop|jabiluka|obj
stop|if|c
won|it|subj
won|government|obj
election|october|nn
election|national|mod
government|election|in
after|began|comp1
began|construction|subj
were|june 1998|mid
were|series|pred
protests|public|mod
series|protests|of
office|era|nn
office|darwin|in
firebombed|office|obj
team|united nations world heritage bureau|from
visited|team|subj
visited|site|obj
called for|then|mod-before
site|called for|vrel
called for|site|obj
called for|closing|mod
closing|team|subj
mine|jabiluka|nn
closing|mine|obj
closing|because|mod
because|poses|comp1
poses|it|subj
poses|danger|obj
values|cultural|mod
cultural|and|punc
cultural|natural|conj
danger|values|to
values|kakadu park|of
november 1998|u.n.|appo
government|australian|mod
lobbying|government|by
government|decided|vrel
decided|government|obj
decided|put|mod
put|kakadu national park|obj
list|its|gen
list|endangered|mod
kakadu national park|list|on
put|but|punc
put|asked for|conj
report|detailed|mod
asked for|report|obj
report|april 15th|by
april 15th|1999|num
done|what|obj
done|prevent|mod
damage|further|mod
prevent|damage|obj
prevent|and|punc
prevent|mitigate|conj
threats|all|pre
mitigate|threats|obj
threats|kakadu park|to
mine|jabiluka|nn
kakadu park|mine|by

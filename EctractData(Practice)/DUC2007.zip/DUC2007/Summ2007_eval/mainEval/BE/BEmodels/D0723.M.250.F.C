mayor|former|mod
mayor|democratic|mod
diane feinstein|mayor|appo
mayor|san francisco|of
elected|first|amod
elected|diane feinstein|obj
senate|u.s.|nn
elected|senate|to
senate|1992|in
1992|fulfill|rel
fulfill|1992|subj
years|last|post
years|2|amount-value
fulfill|years|obj
term|pete wilson|gen
years|term|of
fulfill|when|wha
resigned|he|subj
resigned|become|mod
become|he|subj
become|governor|obj
reelected|she|obj
reelected|by|by-subj
margin|narrow|mod
reelected|margin|by
margin|republican michael huffington|against
republican michael huffington|1994|in
senator|feinstein|person
is|centrist|pred
centrist|who|whn
snubs|centrist|subj
edges|outer|mod
snubs|edges|obj
ideology|political|mod
edges|ideology|of
broke|she|subj
leadership|democratic|mod
broke|leadership|from
broke|voting for|mod
voting for|she|subj
amendment|republican-led|nn
amendment|constitutional|mod
voting for|amendment|obj
amendment|ban|rel
ban|amendment|subj
desecration|flag|nn
ban|desecration|obj
persuaded|she|subj
leaders|republican|mod
persuaded|leaders|obj
leaders|accept|rel
accept|leader|subj
accept|amendment|obj
bill|trade|nn
amendment|bill|to
bill|allowing|rel
allowing|bill|subj
countries|african|nn
produce|countries|subj
expensive|less|mod
drugs|expensive|mod
drugs|generic|mod
drugs|aids|nn
produce|drugs|obj
spoke|she|subj
spoke|out|mod
spoke|strongly|mod
strongly|president|against
president|clinton|person
affair|lewinsky|nn
president|affair|over
clinton|censure|nn
hard|clinton|to
supporter|strong|mod
supporter|law-enforcement|nn
is|supporter|pred
supporter|and|punc
supporter|foe|conj
lobby|gun|nn
foe|lobby|of
introduced|she|subj
introduced|legislation|obj
legislation|which|whn
require|legislation|subj
require|buyers|obj
buyers|handguns|of
handguns|and|punc
weapons|semiautomatic|mod
handguns|weapons|conj
weapons|get|rel
get|weapon|subj
get|licenses|obj
proposed|she|subj
proposed|ban|obj
dealings|business|mod
ban|dealings|on
companies|foreign|mod
dealings|companies|with
companies|that|whn
are|fronts|pred
cartels|drug|nn
fronts|cartels|for
campaign|her|gen
campaign|last|post
focused on|campaign|during
focused on|she|subj
focused on|improving|mod
improving|she|subj
care|health|nn
improving|care|obj
improving|preserving|conj
preserving|she|subj
preserving|lake tahoe|obj
preserving|restricting|conj
restricting|she|subj
restricting|sale|obj
sale|guns|of
restricting|eliminating|conj
eliminating|she|subj
mtbe|gasoline|nn
mtbe|additive|nn
eliminating|mtbe|obj
eliminating|and|punc
eliminating|bringing together|conj
bringing together|she|subj
sides|opposing|mod
bringing together|sides|obj
wars|california|gen
wars|water|nn
sides|wars|in
advocate|strong|mod
is|advocate|pred
rights|patients|gen
advocate|rights|of
was|age|at
age|64|num
popular|most|mod
politician|popular|mod
was|politician|pred
politician|california|in
was|and|punc
mentioned|often|amod
was|mentioned|conj
mentioned|she|obj
candidate|potential|mod
mentioned|candidate|as
candidate|vice president|for
vice president|2000|in
democrat|top|mod
worked|democrat|as
panel|senate judiciary committee|gen
democrat|panel|on
panel|technology|on
technology|terrorism|conj
terrorism|and|punc
information|government|nn
terrorism|information|conj
worked|she|subj
worked|resolve|mod
resolve|she|subj
differences|bitter|mod
resolve|differences|obj
encryption|data|nn
differences|encryption|over

was|loner|pred
school|high|nn
loner|school|in
school|who|whn
dabbled|school|subj
dabbled|drugs|in
used|he|subj
used|chemicals|obj
chemicals|extract|rel
extract|chemical|subj
extract|hallucinogen|obj
seeds|morning glory|nn
hallucinogen|seeds|from
used|overdosed|conj
overdosed|he|subj
overdosed|and|punc
overdosed|went|conj
went|he|subj
room|emergency|nn
went|room|to
arrested|age|at
he|14|num
arrested|he|obj
breaking into|he|subj
breaking into|drugstore|obj
did|20|at
did|he|subj
did|it|obj
did|again|mod
did|and|punc
did|got off|conj
got off|he|obj
got off|counseling|with
graduating|u|from
u|sc|of
sc|degree|with
degree|chemistry|in
after|went to work|comp1
went to work|he|subj
went to work|texas|in
went to work|and|punc
went to work|became|conj
became|he|subj
became|president|obj
president|tlc manufacturing|of
fired|september 1990|in
after|broke into|comp1
broke into|he|subj
broke into|building|obj
building|and|punc
records|stole|nn
records|financial|mod
building|records|conj
charged|he|obj
burglary|felony|nn
charged|burglary|with
charged|but|punc
charged|released|conj
released|he|obj
released|when|wha
declined|company|subj
declined|prosecute|mod
prosecute|company|subj
moved|he|subj
moved|georgia|to
wife|his|gen
georgia|wife|with
wife|and|punc
children|2|num
wife|children|conj
children|bounced|vrel
bounced|children|obj
bounced|job|from
job|job|to
bounced|and|punc
bounced|began|conj
began|children|subj
began|affair|obj
affair|newlywed|with
found|august 1999|in
wife|his|gen
wife|and|punc
wife|mother-in-law|conj
found|wife|obj
death|camper|in
camper|alabama|in
suspect|prime|mod
was|suspect|pred
suspect|killing|in
was|but|punc
charged|never|amod
was|charged|conj
charged|mark|obj
charged|lack|for
lack|evidence|of
collected|he|subj
sum|large|mod
collected|sum|obj
policy|insurance|nn
sum|policy|from
policy|and|punc
married|later|mod
leigh ann|married|mod
policy|leigh ann|conj
killed|october 1998|in
killed|he|subj
cat|family|nn
killed|cat|obj
spent|then|mod-before
spent|it|subj
days|two|amount-value
helping|days|nn
spent|helping|obj
daughter|his|gen
daughter|8-year-old|mod
helping|search|rel
search|helping|obj
search|daughter|subj
search|it|for
quit|early 1999|in
quit|he|subj
job|his|gen
job|chemical|mod
quit|job|obj
quit|and|punc
quit|began|conj
began|he|subj
began|day-trading|obj
began|losing|mod
losing|he|subj
gambling|as much as|pre
gambling|$450,000|nn
losing|gambling|obj
stocks|internet|nn
gambling|stocks|on
killed|july|in
killed|mark barton|subj
wife|his|gen
wife|second|post
killed|wife|obj
wife|and|punc
children|two|nn
wife|children|conj
children|hammer|with
killed|killed|conj
killed|mark barton|subj
people|nine|nn
killed|people|obj
killed|and|punc
killed|wounded|conj
wounded|mark barton|subj
others|12|num
wounded|others|obj
firms|two day-trading|mod
others|firms|at
firms|atlanta|in
committed|then|mod-before
atlanta|committed|vrel
committed|atlanta|obj1
committed|suicide|obj2

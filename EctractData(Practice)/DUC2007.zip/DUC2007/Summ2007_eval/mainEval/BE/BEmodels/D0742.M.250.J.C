friday , july 17th|1999|num
friday , july 17th|john f. kennedy jr.|appo
surviving|only|mod
son|surviving|mod
president|35th|nn
son|president|of
carolyn bessette kennedy|his|gen
carolyn bessette kennedy|wife|nn
president|carolyn bessette kennedy|conj
carolyn bessette kennedy|and|punc
sister|her|gen
carolyn bessette kennedy|sister|conj
president|lauren bessette|appo
killed|son|obj
killed|when|wha
piper saratoga|piloted|vrel
piloted|piper saratoga|obj
piloted|by|by-subj
piloted|john|by
crashed|piper saratoga|subj
miles|110-foot|nn
miles|deep|mod
miles|water|nn
seven|about|num-mod
miles|seven|amount-value
crashed|miles|into
miles|south|pnmod
vineyard|martha|gen
south|vineyard|of
took off|kennedy|subj
took off|essex county airport|from
essex county airport|8:38pm|at
was|last|pred
last|seen|vrel
seen|last|obj
seen|radar|on
radar|9:39pm|at
friend|kennedy|nn
friend|family|nn
called|friend|subj
guard|coast|nn
called|guard|obj
guard|2:15am|at
called|saturday|mod
vessel|first|post
vessel|search|nn
launched|vessel|obj
4:30am|about|mod
launched|4:30am|at
c-130|air|nn
c-130|national guard|nn
c-130|and|punc
aircraft|civil air patrol|nn
c-130|aircraft|conj
joined|c-130|subj
joined|search|obj
was|not|neg
found|wreckage|obj
wednesday|following|mod
found|wednesday|until
found|after|mod
survey|oceanographic|mod
after|ship|comp1
ship|survey|subj
ship|"|punc
ship|rude|obj
rude|"|punc
rude|and|punc
rude|salvage|conj
uss grasp|recovery|nn
uss grasp|vessel|nn
joined|uss grasp|subj
joined|search|obj
divers|navy|nn
found|divers|subj
found|all|guest
people|three|nn
found|people|obj
people|strapped|vrel
strapped|people|obj
seats|their|gen
strapped|seats|in
conducted|sea|at
three|all|pre
burial|three|of
conducted|burial|obj
conducted|friday|mod
uss brisco|destroyer|nn
conducted|uss brisco|aboard
uss brisco|view|in
estate|jacquelin kennedy onassis|nn
estate|shore-front|mod
view|estate|of
was|2000|mid
error|pilot|mod
was|probable cause|pred
dark|very|mod
was|dark|pred
haze|thick|mod
dark|haze|with
pilot|relatively-inexperienced|mod
kennedy|pilot|appo
flying over|kennedy|subj
flying over|water|obj
water|lights|with
lights|reference-conditions|for
reference-conditions|conducive|pnmod
to|"|punc
disorientation|spatial|mod
conducive|disorientation|to
disorientation|"|punc
disorientation|where|wha
lose|pilots|subj
sense|their|gen
lose|sense|obj
sense|position|of
position|and|punc
position|motion|conj
motion|relative|pnmod
relative|'s surface|to
analysis|radar|nn
indicated|analysis|subj
indicated|that|c
falling|plane|subj
feet|5,000|num
falling|feet|at
feet|minute|per
indicating|possibly|amod
falling|indicating|mod
indicating|analysis|subj
spiral|"|punc
spiral|graveyard|nn
indicating|spiral|obj
spiral|"|punc
descent|corkscrew|nn
spiral|descent|appo
descent|where|wha
lost control|pilot|subj

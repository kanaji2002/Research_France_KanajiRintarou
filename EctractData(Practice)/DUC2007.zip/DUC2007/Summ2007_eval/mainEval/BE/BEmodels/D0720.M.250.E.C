accords|1993|num
accords|"|punc
accords|oslo|nn
accords|"|punc
accords|signed|vrel
signed|accords|obj
signed|by|by-subj
president|israeli|mod
signed|president|by
president|yitzhak rabin|person
president|and|punc
leader|palestinian|mod
president|leader|conj
leader|yasser arafat|person
based|accords|obj
based|principles|on
of|"|punc
principles|land for peace|of
land for peace|"|punc
land for peace|and|punc
land for peace|"|punc
self-rule|palestinian|mod
land for peace|self-rule|conj
was|redeploy|pred
forces|its|gen
redeploy|forces|obj
forces|west bank|in
phases|three|nn
west bank|phases|in
redeploy|turning over|mod
turning over|most|obj
most|territory|of
territory|palestinians|to
palestinians|may 4th|by
may 4th|1999|num
palestinians|exchange|in
guarantees|security|nn
exchange|guarantees|for
were|late 2000|as of
terms|oslo|nn
were|far|pred
implemented|about 40 percent|with
about 40 percent|west bank|of
west bank|returned|vrel
returned|west bank|obj
control|full|mod
full|or|punc
full|partial|conj
control|palestinian|mod
returned|control|to
factors|two|nn
factors|impeding|rel
impeding|factor|subj
impeding|implementation|obj
were|ascent|pred
ascent|power|to
power|1996|in
government|conservative|mod
government|likud|nn
power|government|of
government|led|vrel
led|government|obj
led|by|by-subj
led|benjamin netanyahu|by
benjamin netanyahu|and|punc
benjamin netanyahu|series|conj
bombings|deadly|mod
bombings|suicide|nn
series|bombings|of
bombings|sponsored|vrel
sponsored|bombings|obj
sponsored|by|by-subj
sponsored|hamas|by
year|same|post
sponsored|year|mod
abandoned|israel|subj
freeze|labor party|gen
abandoned|freeze|obj
settlements|new|mod
freeze|settlements|on
settlements|and|punc
redeployment|delayed|mod
settlements|redeployment|conj
forces|its|gen
redeployment|forces|of
forces|west bank|in
abandoned|saying|mod
saying|israel|subj
saying|were|fc
were|not|neg
were|doing|pred
doing|enough|pnmod
enough|combat|comp1
combat|terrorism|obj
israelis|more|mod
died|israelis|subj
accords|oslo|nn
died|accords|since
years|15|amount-value
signed|attempts|in
attempts|salvage|rel
salvage|attempt|subj
salvage|principles|obj
accords|oslo|nn
principles|accords|of
agreements|new|mod
signed|agreements|obj
signed|1998|in
signed|by|by-subj
signed|netanyahu|by
netanyahu|and|punc
netanyahu|arafat|conj
arafat|wye plantaion|at
wye plantaion|washington|outside
sharm el sheikh|egypt|in
egypt|outlining|rel
outlining|egypt|subj
outlining|framework|obj
accord|final-status|nn
accord|peace|nn
framework|accord|for
accord|september 2000|by
issues|final-status|nn
include|inf|subj
include|status|obj
status|jerusalem|of
jerusalem|borders|conj
entity|palestinian|mod
borders|entity|of
entity|fate|conj
refugees|palestinian|mod
fate|refugees|of
refugees|future|conj
settlements|jewish|mod
future|settlements|of
settlements|west bank|in
west bank|and|punc
west bank|gaza strip|conj
gaza strip|and|punc
gaza strip|water|conj

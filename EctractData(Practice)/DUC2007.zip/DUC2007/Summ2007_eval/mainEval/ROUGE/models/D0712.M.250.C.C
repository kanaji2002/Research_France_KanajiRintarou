In 1989, Ayatollah Khomeini of Iran issued a death sentence on British author Salman Rushdie because his book "Satanic Verses" insulted Islamic sanctities.
Rushdie was born in India, but his book was banned and his application for a visit was denied.
British Airways would not permit Rushdie to fly on its airplanes.
Reacting to diplomatic pressures by Britian and other European Nations, Iran announced in 1996 that the death sentence was dropped.
President Rafsanjani said there was a difference between a fatwa (ruling) and a hokm (command) and that Khomeini did not mean the sentence to be a command.
Despite official retraction of the death sentence, Iranian Islamic fundamentalists continue to demand Rushdie's death.
The Khordad Foundation raised the reward for Rushdie's death to 2.5 million dollars and announced, "There is nothing more important to the foundation than seeing Imam Khomeini's decree executed." In 1998, Grand Ayatollah Lankarani and Grand Ayatolla Hamedani said the fatwa must be enforced and no one can reverse it.
More than half of Iran's parliament signed a letter saying the death sentence against Rushdie still stands.
A hard-line student group offered $333K to anyone who kills Salman Rushdie; residents of a village in northern Iran offered land and carpets to anyone who kills him and thousands of Iranian clerics and students pledged a month's salary toward a bounty.
In February 2000, the Islamic Revolutionary Guard said in a radio report that the death sentence was still in force and nothing will change it.

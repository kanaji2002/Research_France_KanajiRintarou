rescued|november 25 , 1999 ,|on
elian gonzalez|six-year-old|mod
rescued|elian gonzalez|obj
rescued|atlantic|from
atlantic|boat|after
he|and|punc
mother|his|gen
he|mother|conj
mother|and|punc
mother|others|conj
fleeing|he|subj
fleeing|cuba|obj
fleeing|capsized|mod
capsized|us|subj
mother|his|gen
drowned|mother|subj
great-uncle|his|gen
great-uncle|miami|in
granted|great-uncle|obj1
custody|temporary|mod
granted|custody|obj2
custody|elian|of
granted|and|punc
granted|sought|conj
sought|great-uncle|subj
sought|asylum|obj
asylum|him|for
fidel castro|and|punc
father|elian|gen
fidel castro|father|conj
father|juan miguel gonzalez|person
demanded|fidel castro|subj
return|elian|gen
demanded|return|obj
return|cuba|to
administration|clinton|nn
weighed|administration|subj
weighed|honoring|mod
honoring|administration|subj
mother|dead|mod
wishes|mother|gen
honoring|wishes|obj
wishes|bringing|in
bringing|elian|obj
elian|freedom|to
bringing|and|punc
bringing|placating|conj
community|cuban|mod
community|exile|nn
placating|community|obj
placating|or|punc
placating|bending|conj
pressure|cuban|mod
bending|pressure|to
bending|and|punc
bending|strengthening|conj
relations|cuban-american|nn
strengthening|relations|obj
demanded|vietnam|subj
demanded|returned|fc
returned|elian|obj
returned|cuba|to
based|us|on
us|and|punc
us|international law|conj
ruled|ins|subj
ruled|that|c
belonged|elian|subj
father|his|gen
belonged|father|with
belonged|and|punc
belonged|returned|conj
returned|elian|obj
returned|cuba|to
relatives|miami|nn
insisted|relatives|subj
insisted|want|fc
want|elian|subj
want|return|fc
return|elian|subj
return|and|punc
return|appealed to|conj
appealed to|elian|subj
janet reno|attorney general|title
appealed to|janet reno|obj
upheld|reno|subj
upheld|father|obj
father|right|pnmod
right|custody|to
upheld|and|punc
upheld|ignored|conj
ignored|reno|subj
interference|florida|nn
interference|court|nn
ignored|interference|obj
ignored|stating|mod
stating|reno|subj
stating|was|fc
matter|federal|mod
was|matter|pred
challenged|relatives|subj
challenged|ins|obj
appealed|then|mod-before
appealed|ruling|subj
suit|their|gen
dismissal|suit|gen
appealed|dismissal|obj
met with|reno|subj
met with|relatives|obj
met with|and|punc
met with|ordered|conj
ordered|reno|obj1
ordered|them|obj2
ordered|surrender|mod
surrender|reno|subj
surrender|elian|obj
seized|april 22|on
seized|federal agents|subj
seized|elian|obj
raid|pre-dawn|mod
elian|raid|in
seized|and|punc
seized|reunited|conj
reunited|federal agents|subj
reunited|him|obj
father|his|gen
reunited|father|with
father|who|whn
come to|father|subj
come to|washington|obj
washington|dc|appo
dc|bring|rel
bring|dc|subj
home|elian|nn
bring|home|obj
riots|and|punc
riots|strikes|conj
broke out|riots|subj
broke out|miami|in
of appeals|11th|mod
of appeals|us|nn
of appeals|circuit|nn
ruled|unanimously|mod-before
ruled|of appeals|subj
ruled|government|for
government|and|punc
father|elian|gen
government|father|conj
ruled|later|mod
ruled|reaffirming|mod
reaffirming|court of appeals|subj
decision|its|gen
reaffirming|decision|obj
rejected|supreme court|subj
rejected|appeal|obj
relatives|miami|nn
appeal|relatives|by
returned to|elian|subj
returned to|cuba|obj
cuba|june 28 , 2000|on

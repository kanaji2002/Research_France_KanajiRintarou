is|non-polluting|pred
renewable|and|punc
renewable|low-cost|conj
use|its|gen
preserves|use|subj
preserves|environment|obj
preserves|and|punc
preserves|helps|conj
helps|use|subj
is|most|pred
way|affordable|mod
is|way|mod
way|bring|rel
bring|way|subj
bring|electricity|obj
areas|remote|mod
remote|or|punc
remote|hard-to-wire|conj
electricity|areas|to
areas|that|whn
are|"|punc
are|off|punc
are|grid|pred
are|"|punc
are|deserts|such as
deserts|jungles|conj
jungles|and|punc
jungles|mountains|conj
boats|solar|mod
open|boats|subj
open|up|guest
open|waterways|obj
waterways|that|whn
banned|waterways|obj
use|human|mod
banned|use|to
pollution|associated|mod
use|pollution|because of
places|sunny|nn
places|north china|like
have|places|subj
potential|great|mod
potential|solar energy|nn
have|potential|obj
is|popular|pred
countries|developing|mod
popular|countries|in
including|cameroun|obj
cameroun|brazil|conj
brazil|egypt|conj
egypt|india|conj
india|indonesia|conj
indonesia|mexico|conj
mexico|somalia|conj
somalia|uganda|conj
uganda|and|punc
uganda|vietnam|conj
used|it|obj
used|heating|in
lighting|cooking|conj
cooking|refrigeration|conj
refrigeration|telecommunications|conj
telecommunications|meteorology|conj
forecasts|earthquake|nn
meteorology|forecasts|conj
forecasts|and|punc
prevention|forest fire|nn
forecasts|prevention|conj
countries|that|whn
made|countries|subj
advancements|solar energy|in
assisting|such as|mod-before
assisting|israel|such as
israel|germany|conj
germany|japan|conj
japan|and|punc
japan|canada|conj
assisting|advancements|subj
development|solar energy|nn
assisting|development|with
development|china|in
china|and|punc
china|africa|conj
aiding|also|amod
aiding|china|subj
development|african|mod
development|solar energy|nn
aiding|development|obj
10|next|num-mod
years|10|amount-value
are|years|in
years|253|num
projects|cooperative|mod
projects|solar|mod
projects|demonstration|nn
are|launched|pred
is|leader|pred
research|solar energy|nn
leader|research|in
universities|australian|mod
is|universities|with
universities|developing|rel
developing|university|subj
solar cells|efficient|mod
solar cells|ultra-thin|mod
developing|solar cells|obj
solar cells|and|punc
material|high-tech|mod
solar cells|material|conj
electricity|solar|mod
electricity|thermal|mod
material|electricity|for
leads|us|subj
manufacturing|solar|mod
manufacturing|equipment|nn
leads|manufacturing|in
leads|also|mod-before
leads|it|subj
production|solar energy|nn
leads|production|in
production|followed|vrel
followed|production|obj
followed|by|by-subj
followed|japan|by
japan|and|punc
japan|europe|conj
expanding|germany|subj
production|solar cell|nn
expanding|production|obj
producer|major|mod
producer|solar energy|nn
is|producer|pred
is|and|punc
is|sells|conj
sells|china|subj
sells|it|obj
sells|home|at
increasing|the netherlands|subj
use|its|gen
use|solar energy|nn
increasing|use|obj
increasing|and|punc
increasing|installing|conj
installing|the netherlands|subj
installing|collectors|obj
collectors|rooftops|on
user|leading|mod
user|solar energy|nn
is|user|pred
user|and|punc
research|does|nn
research|extensive|mod
user|research|conj
research|and|punc
research|development|conj
brazil|and|punc
brazil|mexico|conj
consumers|major|mod
consumers|solar power|nn
are|consumers|pred

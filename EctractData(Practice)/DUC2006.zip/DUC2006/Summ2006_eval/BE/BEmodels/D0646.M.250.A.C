is|lying under oath|pred
law|federal|mod
prove|law|under
prove|prosecutors|subj
prove|knows|fc
knows|person|subj
knows|is|fc
is|inaccurate|pred
make|false statement|obj
false statement|and|punc
false statement|that|conj
are|material|pred
material|case|to
case|hand|at
said|1973|in
said|us supreme court|subj
said|that|c
answers|shrewd|mod
shrewd|or|punc
shrewd|narrow|conj
calculated|answers|subj
are|not|neg
are|perjury|pred
perjury|as|mod
are|as|mod
as|are|comp1
are|truthful|pred
is|crime|pred
on|both|punc
levels|local|mod
local|and|punc
local|federal|conj
crime|levels|on
law|federal|mod
making|false statements|obj
forms|federal|mod
false statements|forms|on
on|or|punc
on|to|conj
officers|federal|mod
on|officers|to
cases|perjury|nn
account for|cases|subj
1|less than|num-mod
account for|1|obj
prosecutions|federal|mod
prosecutions|and|punc
10|less than|num-mod
prosecutions|10|conj
prosecutions|state|nn
charges|perjury|nn
arise|usually|amod
arise|charges|subj
arise|conjunction|in
crimes|other|mod
conjunction|crimes|with
arise|and|punc
arise|brought|conj
brought|charges|obj
cases|civil|mod
brought|cases|in
less|far|mod
frequently|less|mod
brought|frequently|mod
cases|criminal|mod
cases|perjury|nn
involve|cases|subj
involve|documents|obj
prosecutions|federal|mod
prosecutions|perjury|nn
average|prosecutions|subj
average|130 per year|obj
serving|october 1998 , 115|in
serving|people|subj
serving|sentences|obj
sentences|perjury|for
prisons|federal|mod
perjury|prisons|in
law|federal|mod
are|law|under
perjury|and|punc
perjury|false statements|conj
are|punishable|pred
fine|undetermined|mod
punishable|fine|by
five|up to|num-mod
years|five|amount-value
years|prison|in
sentences|federal|mod
average|sentences|subj
months|27|amount-value
average|months|obj
punishments|other|mod
punishments|perjury|nn
involved|punishments|subj
detention|home|nn
involved|detention|obj
service|community|mod
detention|service|conj
service|giving|conj
license|medical|mod
giving|license|up
license|removal|conj
office|public|mod
removal|office|from
office|and|punc
sentences|prison|nn
office|sentences|conj
days|60|amount-value
sentences|days|of
months|four|amount-value
days|months|conj
months|and|punc
years|two|amount-value
months|years|conj
mark fuhrman|simpson|nn
mark fuhrman|case|nn
charged|mark fuhrman|obj
years|three|amount-value
probation|years|nn
charged|probation|with
charged|and|punc
charged|fined|conj
fined|mark fuhrman|obj1
fined|$200|obj2
convictions|perjury|nn
brought|convictions|subj
sentences|prison|nn
brought|sentences|obj
years|three|amount-value
sentences|years|of
years|alger hiss|to
alger hiss|and|punc
years|six|amount-value
alger hiss|years|conj
case|terrorism|nn
years|case|in
in|and|punc
in|for|conj
killer|confessed|mod
in|killer|for
cleared|earlier|mod-before
killer|cleared|vrel
cleared|killer|obj
crime|his|gen
cleared|crime|of

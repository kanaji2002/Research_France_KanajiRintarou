#!C:\strawberry\perl\bin\perl

use strict;


my $docA = $_[1];
my $docB = $_[2];

my @numSoum = ();
my @tabScores = ();
my $compt = 0;

open (LIRA, $docA);
open (LIRB, $docB);

while (<LIRA>)
{
	if (m/([0-9]*?) ([0-9\.]*?) (.*)/)
	{
		$numSoum[$compt] = $1;
		$tabScores[$compt] = $2;
		$compt++;
	}
}

$compt = 0;

while (<LIRB>)
{
	if (m/([0-9]*?) ([0-9\.]*?) (.*)/)
	{
		$tabScores[$compt] = ($2+$tabScores[$compt])/2;
		print "$numSoum[$compt] $tabScores[$compt]";
		$compt++;
	}
}
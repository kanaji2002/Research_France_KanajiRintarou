held|world trade center foundation|subj
meeting|its|gen
meeting|first|post
held|meeting|obj
meeting|january 6.|on
priority|its|gen
january 6.|raising|rel
raising|january 6.|obj
raising|priority|subj
$500 million|build|rel
build|$500 million|subj
build|memorial|obj1
memorial|and|punc
buildings|two|nn
buildings|cultural|mod
memorial|buildings|conj
build|four|obj2
four|living|rel
living|four|subj
presidents|former|mod
presidents|us|nn
living|presidents|obj
directors|honorary|mod
are|directors|pred
directors|prominent|person
members|foundation|nn
include|members|subj
include|robert de niro|obj
robert de niro|barbara walters|conj
barbara walters|david rockefeller|conj
david rockefeller|and|punc
canadian|former|mod
david rockefeller|canadian|conj
minister|prime|mod
design|minister|gen
minister|brian mulroney michael arad|person
design|reflecting absence|appo
chosen|design|obj
chosen|memorial|for
planned|it|obj
planned|include|mod
include|it|subj
include|forest|obj
trees|oak|nn
forest|trees|of
trees|and|punc
hall|memorial|nn
trees|hall|conj
interpretive|underground|mod
center|interpretive|mod
house|center|subj
house|artifacts|obj
attacks|1993 and 2001|nn
artifacts|attacks|from
scheduled|memorial|obj
scheduled|open|mod
open|memorial|subj
open|2009|in

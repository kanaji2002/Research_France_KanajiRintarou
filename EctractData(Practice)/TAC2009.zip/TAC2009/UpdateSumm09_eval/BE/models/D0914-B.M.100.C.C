officials|israeli|mod
suspect|strongly|mod-before
suspect|officials|subj
network|al-qaida|nn
suspect|network|obj
blasts|three|nn
blasts|sinai peninsula|nn
blasts|resort|nn
network|blasts|in
blasts|based|vrel
based|blasts|obj
based|similarities|on
attacks|past|mod
similarities|attacks|with
unknown|previously|mod
group|unknown|mod
group|islamic unity brigades|appo
claimed|group|subj
claimed|responsibility|obj
responsibility|series|for
series|bombings|of
claimed|supposedly|mod
supposedly|revenge|as
assassination|israel|gen
revenge|assassination|for
sheikh ahmed yassin|hamas|nn
sheikh ahmed yassin|founder|nn
assassination|sheikh ahmed yassin|of
sheikh ahmed yassin|march|in
march|both|punc
bomb|car|nn
bomb|and|punc
bomber|suicide|nn
bomb|bomber|conj
march|struck|rel
struck|march|obj1
struck|bomb|subj
struck|taba hilton|obj2
10:00 p.m.|about|mod
taba hilton|10:00 p.m.|at
bombs|car|nn
suspected|bombs|obj
suspected|blasts|in
blasts|which|whn
struck|blasts|subj
struck|just|mod
just|midnight|before
midnight|ras shytan|at
ras shytan|and|punc
accounts|nuweiba|nn
accounts|resorts|nn
ras shytan|accounts|conj
dead|and|punc
dead|wounded|conj
effort|rescue|nn
varied|effort|throughout

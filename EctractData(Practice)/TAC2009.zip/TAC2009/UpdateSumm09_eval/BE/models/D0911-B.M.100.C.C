granting|iceland|gen
granting|citizenship|of
citizenship|bobby fischer|to
signed|formally|mod-before
bobby fischer|signed|vrel
signed|bobby fischer|obj
signed|law|into
law|march 22|on
made|granting|subj
made|it|obj1
possible|legally|mod
made|possible|desc
possible|japan|for
japan|deport|rel
deport|japan|subj
deport|him|obj
deport|country|to
deportation|japanese|mod
deportation|law|nn
deportation|only|mod
deportation|permits|nn
deportation|country|to
country|where|wha
fischer|citizen|nn
passport|fischer|gen
passport|icelandic|nn
is|passport|pred
be|ready|pred
ready|march 23|on
officials|japanese|mod
agreed|officials|subj
agreed|allow|fc
allow|official|subj
travel to|him|subj
travel to|iceland|obj
travel to|after|mod
after|withdraws|comp1
withdraws|he|subj
lawsuit|his|gen
lawsuit|pending|mod
withdraws|lawsuit|obj
government|japanese|mod
lawsuit|government|against
government|block|rel
block|government|subj
deportation|his|gen
block|deportation|obj
supporter|fischer|nn
deportation|said|rel
said|supporter|subj
said|do|fc
do|deportation|obj
do|he|subj
do|so|mod
so|morning|on
morning|march 24|of
way|his|gen
morning|way|on
morning|airport|to
airport|fly|rel
fly|airport|subj
fly|iceland|to

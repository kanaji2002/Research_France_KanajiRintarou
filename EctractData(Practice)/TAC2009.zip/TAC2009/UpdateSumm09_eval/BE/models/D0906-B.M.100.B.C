stopped|rain|subj
was|underway|guest
was|roads|pred
roads|had|vrel
had|roads|obj
had|yet|mod
had|cleared|mod
storms|early|mod
storms|january|nn
claimed|storms|subj
claimed|lives|fc
lives|28|subj
storm|late|mod
storm|february|nn
pummeled|storm|subj
california|southern|mod
pummeled|california|obj
days|six|amount-value
trees|days|nn
trees|falling|mod
california|trees|for
trees|mudslides|conj
mudslides|rockslides|conj
rockslides|tornadoes|conj
tornadoes|floods|conj
floods|washed|vrel
washed|floods|obj
washed|roads|out
roads|and|punc
roads|bridges|conj
bridges|and|punc
residents|sinkholes|nn
residents|threatened|mod
bridges|residents|conj
safety|and|punc
deaths|homes|nn
nine|at least|num-mod
deaths|nine|nn
safety|deaths|conj
attributed|safety|obj
attributed|storm|to
dozens|homes|of
condemned|dozens|obj
100|over|num-mod
rendered|100|obj1
uninhabitable|temporarily|mod
rendered|uninhabitable|desc
opened|los angeles|subj
emergency operations center|its|gen
opened|emergency operations center|obj1
coordinate|better|amod
emergency operations center|coordinate|rel
coordinate|emergency operations center|subj
response|its|gen
response|storm|nn
coordinate|response|obj
opened|damage|obj2
january|and|punc
january|february|conj
top|storms|subj
top|$100 million|obj

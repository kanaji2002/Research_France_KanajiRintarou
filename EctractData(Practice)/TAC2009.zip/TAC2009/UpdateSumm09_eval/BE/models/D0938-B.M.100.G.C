project|world trade center|nn
project|memorial|nn
bogged down|project|subj
bogged down|while|mod
negotiations|issues|over
issues|condemnation|of
condemnation|and|punc
domain|imminent|mod
condemnation|domain|conj
while|hashed|comp1
hashed|negotiations|obj
hashed|out|mod
revisions|design|nn
complicated|further|amod
complicated|revisions|subj
members|project|nn
members|family|nn
complicated|members|obj
displeasure|9/11|nn
displeasure|victims|nn
displeasure|expressed|mod
members|displeasure|of
displeasure|many|with
amendments|proposed|mod
many|amendments|of
design|arad|gen
amendments|design|to
believe|they|subj
believe|taken|fc
taken|memorial|subj
taken|backseat|obj
interests|commercial|mod
backseat|interests|to
taken|and|punc
taken|called|conj
called|memorial|subj
new york|fundraising|mod
new york|boycott|nn
governor|new york|gen
called|announced|mod
announced|governor|subj
announced|appoint|fc
appoint|he|subj
chief of staff|his|gen
appoint|chief of staff|obj1
chief of staff|take control|rel
take control|chief of staff|subj
effort|rebuilding|nn
take control|effort|of
use|also|amod
effort|use|rel
use|effort|obj
use|he|subj
funds|public|mod
appoint|funds|obj2
funds|jumpstart|rel
jumpstart|fund|subj
effort|fundraising|mod
jumpstart|effort|obj
memorial|temporary|mod
effort|open|rel
open|effort|obj
open|memorial|subj
open|july 11|on

trial|first|post
trial|grand larceny|nn
dennis kozlowski|former|mod
dennis kozlowski|tyco|nn
dennis kozlowski|ceo|title
trial|dennis kozlowski|of
dennis kozlowski|and|punc
dennis kozlowski|codefendant|conj
codefendant|ended|rel
ended|codefendant|obj
ended|mark swartz|subj
ended|mistrial|in
retrial|their|gen
mistrial|began|rel
began|mistrial|obj
began|retrial|subj
stole|allegedly|mod-before
stole|they|subj
stole|$600 million|obj
$600 million|company|from
compensation|unauthorized|mod
company|compensation|in
compensation|and|punc
compensation|sale|conj
stock|inflated|mod
stock|tyco|nn
sale|stock|of
stock|face|rel
face|stock|obj
face|kozlowski|subj
years|30|amount-value
prosecutors|prison|nn
years|prosecutors|in
focusing|years|subj
focusing|less|mod
life|kozlowski|gen
less|life|on
life|excess|of
excess|and|punc
excess|more|conj
looted|allegedly|mod-before
looted|he|subj
arguments|company|nn
arguments|in|nn
arguments|opening|mod
looted|arguments|obj
suggested|defense|subj
suggested|was|fc
was|legitimate|pred
directors|company|nn
practicing|directors|subj
history|revisionist|nn
practicing|history|obj
faces|still|mod-before
history|faces|rel
faces|history|obj
faces|kozlowski|subj
tax|separate|mod
tax|conspiracy|appo
faces|falsifying|mod
falsifying|tax|subj
records|business|mod
falsifying|records|obj
falsifying|and|punc
falsifying|evidence|conj
evidence|tax|subj
charges|tampering|nn
evidence|charges|obj

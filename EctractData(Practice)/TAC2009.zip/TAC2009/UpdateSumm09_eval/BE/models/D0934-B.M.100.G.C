announcement|official|mod
expecting|announcement|obj
death|yasser arafat|gen
announcement|death|of
death|wednesday , november 10 ,|on
made|palestinians|subj
made|plans|obj
plans|and|punc
plans|preparations|conj
funeral|his|gen
preparations|funeral|for
cleric|muslim|nn
funeral|flew|rel
flew|funeral|obj
flew|cleric|subj
flew|paris|to
be|with|pred
leader|palestinian|mod
be|leader|with
leader|who|whn
remained|leader|subj
remained|coma|in
remained|and|punc
remained|suffered|conj
suffered|leader|subj
suffered|liver|obj
liver|and|punc
failure|kidney|nn
liver|failure|conj
died|arafat|subj
died|3:30 a.m.|at
body|his|gen
flown|body|obj
flown|cairo|to
service|memorial|nn
cairo|service|for
scheduled|there|mod-before
service|scheduled|vrel
scheduled|service|obj
scheduled|friday|for
scheduled|service|after
body|his|gen
flown|body|obj
flown|ramallah|to
israel|his|gen
israel|headquarters|nn
israel|there|nn
burial|israel|at
flown|sealed|mod
sealed|burial|subj
declared|west bank|off
west bank|and|punc
west bank|gaza strip|conj
gaza strip|security|for
sealed|declared|fc
declared|palestinian authority|subj
period|40-day|nn
period|mourning|mod
declared|period|obj

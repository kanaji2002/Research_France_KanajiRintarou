heard|march 2 , 2005 ,|on
heard|supreme court|subj
cases|two|nn
heard|cases|obj
cases|display|concerning
display|ten commandments|of
property|government|nn
ten commandments|property|on
property|texas|in
lawyer|homeless|mod
lawyer|former|mod
challenged|lawyer|subj
challenged|constitutionality|obj
monument|inscribed|mod
constitutionality|monument|of
monument|displayed|pnmod
grounds|state|nn
grounds|capitol|nn
displayed|grounds|on
grounds|kentucky|in
claimed|aclu|subj
claimed|displayed|fc
displayed|copies|subj
courthouses|two|nn
displayed|courthouses|in
courthouses|modified|vrel
modified|courthouses|obj
before|twice|mod
modified|before|mod
before|response|in
court|copy|subj
violated|still|mod-before
response|violated|comp1
violated|rulings|subj
violated|first amendment|obj
violated|because|mod
purpose|original|mod
because|was|comp1
was|religious|pred
were|sham|pred
argued|supporters|subj
argued|that|c
symbol|recognized|mod
are|symbol|pred
symbol|law|of
with|both|punc
functions|secular|mod
secular|and|punc
secular|religious|conj
are|functions|with
functions|issue|rel
issue|functions|obj1
issue|justices|subj
issue|opinion|obj2
june|late|mod
opinion|june|by

relations|improved|mod
relations|economic|mod
economic|and|punc
economic|cultural|conj
made|relations|despite
india|and|punc
india|pakistan|conj
made|india|subj
made|progress|obj
progress|problem|on
problem|kashmir|of
made|however|mod
leaders|countries|of
remain|leaders|subj
remain|committed|desc
process|peace|nn
committed|process|to
planned|they|subj
talks|formal|mod
planned|talks|obj
talks|subject|on
subject|new delhi|in
new delhi|april 17|on
first|their|gen
first|india|since
singh|prime minister|title
took office|singh|subj
may|last|post
took office|may|mod
took office|april 16|on
leaders|moderate|mod
leaders|kashmiri|nn
leaders|separatist|mod
were|meet with|pred
president|pakistani|mod
meet with|president|obj
in|new delhi|nn
president|in|in
meet with|june|mod
made|they|subj
trip|historic|mod
made|trip|obj
trip|pakistan|to
made|and|punc
made|met with|conj
met with|they|subj
officials|pakistani|mod
officials|government|nn
met with|officials|obj
officials|india|person
singh|prime minister|title
invited|singh|subj
invited|them|obj
talks|peace|nn
invited|talks|for
talks|held|rel
held|september 5.|on

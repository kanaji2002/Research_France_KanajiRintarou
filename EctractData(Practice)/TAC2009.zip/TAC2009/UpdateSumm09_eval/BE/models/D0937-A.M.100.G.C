president|dick cheney|person
shot|accidentally|mod-before
shot|president|subj
partner|hunting|nn
shot|partner|obj
partner|february 11|on
partner|weekend|during
trip|quail|nn
trip|hunting|nn
friend|texas cheney|gen
trip|friend|in
friend|attorney|appo
attorney|harry whittington|person
attorney|austin|from
sprayed|trip|obj
sprayed|face|in
neck|and|punc
neck|chest|conj
whittington|birdshot|nn
chest|whittington|with
reported|neck|obj
be|in|pred
condition|stable|mod
be|condition|in
hospital|corpus christi|nn
condition|hospital|in
reported|first|amod
reported|incident|obj
reported|by|by-subj
reported|corpus christi caller-times cheney|by
disclosed|office|subj
hours|accident|nn
hours|20|amount-value
disclosed|hours|obj
disclosed|after|mod
after|occurred|comp1
staff|white house|nn
occurred|criticized|fc
criticized|staff|obj
criticized|delay|for
provided|incident|subj
provided|wealth|obj
wealth|material|of
material|democrats|for
activists|gun control|nn
democrats|activists|conj
activists|and|punc
comedians|late|mod
comedians|night|nn
activists|comedians|conj

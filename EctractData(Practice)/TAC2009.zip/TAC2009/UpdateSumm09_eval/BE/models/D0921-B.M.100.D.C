selection|jury|nn
trial|michael jackson|gen
trial|expected|mod
trial|six-month|nn
selection|trial|for
began|selection|subj
began|january 31|on
january 31|face|rel
face|january 31|obj
face|jackson|subj
years|20|num
face|years|mod
face|prison|in
prison|february 15|on
hospitalized|jackson|obj
hours|33|amount-value
suffering|hours|nn
hospitalized|suffering|for
suffering|flu|from
hospitalized|delaying|mod
delaying|jackson|subj
selection|jury|nn
delaying|selection|obj
selection|february 23|by
selection|jury|nn
completed|selection|obj
arguments|opening|mod
delivered|arguments|obj
delivered|february 28|on
was|accused|pred
accused|molesting|of
molesting|jackson|subj
boy|13-year-old|mod
molesting|boy|obj
neverland ranch|his|gen
boy|neverland ranch|at
neverland ranch|february 3|between
february 3|and|punc
february 3|march 3 , 2003|conj
march 3 , 2003|alleged|rel
alleged|prosecution|subj
alleged|plotted|fc
plotted|march 3 , 2003|obj
plotted|jackson|subj
plotted|kidnap|mod
kidnap|jackson|subj
kidnap|boy|obj
boy|and|punc
family|his|gen
boy|family|conj
kidnap|and|punc
kidnap|hold|conj
hold|jackson|subj
hold|them|obj
hold|order|in
order|limit|rel
limit|order|subj
limit|damage|obj
damage|caused|vrel
caused|damage|obj
caused|by|by-subj
documentary|2003|num
caused|documentary|by
documentary|that|whn
inspired|documentary|subj
inspired|charges|obj
charges|him|against

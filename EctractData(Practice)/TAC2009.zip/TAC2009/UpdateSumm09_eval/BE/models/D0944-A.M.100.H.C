argued|legality|over
penalty|death|nn
legality|penalty|of
penalty|criminals|for
criminals|age|under
age|18|num
age|roper|in
simmons simmons|v.|nn
attorney|simmons simmons|gen
argued|attorney|subj
argued|that|c
consensus|national|mod
emerged|consensus|subj
penalty|death|nn
penalty|juveniles|for
punishment|cruel|mod
cruel|and|punc
cruel|unusual|conj
is|punishment|pred
compared|he|subj
compared|case|obj
case|2002|num
case|case|to
compared|which|in
abolished|court|subj
penalty|death|nn
abolished|penalty|obj
offenders|mentally retarded|nn
penalty|offenders|for
attorney general|missouri|nn
argued|attorney general|subj
argued|that|c
uphold|court|subj
uphold|execution|obj
execution|minors|of
uphold|because|mod
because|are|comp1
heinous|so|mod
are|heinous|pred
heinous|warrant|as to
votes|justices|gen
justices|kennedy|person
justices|and|punc
justices|day o 'connor|conj
are|likely|pred
be|pivotal|pred

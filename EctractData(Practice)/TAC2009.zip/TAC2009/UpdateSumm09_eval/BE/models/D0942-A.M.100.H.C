claims|prc|subj
law|anti-secession|mod
law|deliberated|rel
deliberated|by|by-subj
body|its|gen
body|legislative|mod
deliberated|body|by
body|march|in
claims|aimed at|fc
aimed at|law|obj
aimed at|promoting|mod
promoting|law|subj
reunification|peaceful|mod
promoting|reunification|obj
reunification|taiwan|with
taiwan|denies|rel
denies|it|subj
denies|that|c
used|it|obj
used|justify|fc
justify|taiwan|obj
justify|it|subj
action|military|nn
action|maintains|rel
maintains|prc|subj
maintains|that|c
systems|one|nn
systems|country|mod
systems|two|nn
approach|systems|subj
is|best|guest
taiwan|taiwan|nn
best|taiwan|for
is|fears|pred
law|anti-secession|mod
fears|designed|comp1
designed|law|obj
designed|legalize|mod
legalize|law|subj
invasion|beijing|nn
invasion|military|mod
legalize|invasion|obj
says|it|subj
says|is|fc
is|provocation|pred
provocation|that|whn
undermine|provocation|subj
undermine|stability|obj
stability|taiwan strait|across
taiwan strait|ruling|rel
ruling|taiwan strait|obj
ruling|its|subj
parties|opposition|nn
agreed|parties|subj
agreed|adopt|fc
adopt|party|subj
adopt|resolution|obj
us|beijing|nn
us|law|nn
resolution|us|against
us|and|punc
taiwan|eu|nn
taiwan|support|nn
position|taiwan|gen
us|position|conj

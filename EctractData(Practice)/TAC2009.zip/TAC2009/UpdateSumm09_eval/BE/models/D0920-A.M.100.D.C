yusuf islam|british|mod
yusuf islam|singer|nn
known|formerly|amod
known|yusuf islam|obj
cat stevens|popular|mod
cat stevens|singer-songwriter|mod
known|cat stevens|as
known|before|mod
converting|yusuf islam|subj
converting|islam|to
converting|30 years ago|mod
before|established|comp1
established|he|subj
schools|islamic|mod
established|schools|obj
schools|britain|in
established|and|punc
established|worked|conj
worked|he|subj
activist|peace|nn
worked|activist|as
worked|recently|mod
sang|he|subj
concert|charity|nn
sang|concert|at
concert|london|in
sang|and|punc
sang|recorded|conj
recorded|he|subj
version|one|of
hits|his|gen
one|hits|of
hits|writing|rel
writing|hits|obj1
writing|he|subj
musical|broadway|nn
writing|musical|obj2
musical|based|vrel
based|musical|obj
based|his|on
recorded|hits|fc
hits|version|subj
hits|gorbachev foundation|obj1
gorbachev foundation|awarded|vrel
awarded|gorbachev foundation|obj1
awarded|islam|obj2
man|its|gen
hits|man|obj2
prize|peace|nn
man|prize|of
prize|november|in
prize|september|in
barred|islam|obj
entering|islam|subj
entering|us|obj
entering|when|wha
name|his|gen
appeared|name|subj
list|no-fly|mod
appeared|list|on
terrorist|possible|mod
list|terrorist|because of
islam|links|nn
denies|islam|subj
denies|terrorist|obj1
denies|connection|obj2

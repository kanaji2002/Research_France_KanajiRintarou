election|iraqi|mod
destroyed|election|before
destroyed|insurgents|subj
polling stations|40|num
destroyed|polling stations|obj
attacks|thursday|gen
killed|attacks|subj
19|at least|num-mod
killed|19|obj
killed|and|punc
killed|included|conj
included|attacks|subj
bombing|car|nn
included|bombing|obj
bombing|samarra|near
samarra|and|punc
blasts|three|nn
samarra|blasts|conj
blasts|basra|in
polling stations|-five|nn
attacked|polling stations|obj
attacked|iraq|across
iraq|friday|on
six|at least|num-mod
killed|six|obj
occurred|attacks|subj
occurred|kirkuk|around
kirkuk|baghdad , al-dur|conj
baghdad , al-dur|tikrit|conj
tikrit|and|punc
tikrit|shorgat|conj
shorgat|saturday|on
were|struck|pred
offensive|large-scale|mod
offensive|insurgent|mod
materialized|offensive|subj
bomber|suicide|nn
network|al-zarqawi|gen
network|al-qaida|nn
bomber|network|of
attacked|bomber|subj
attacked|station|obj
attacks|khanaqin|nn
attacks|other|mod
station|attacks|in
attacks|occurred|vrel
occurred|attacks|obj
occurred|baghdad|in
ramadi|kirkuk|conj
kirkuk|baiji|conj
baiji|and|punc
18|moqdadiya|nn
18|at least|num-mod
baiji|18|conj
killed|ramadi|obj
killed|saturday|on

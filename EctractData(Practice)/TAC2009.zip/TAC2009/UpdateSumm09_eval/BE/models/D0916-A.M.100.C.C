kidnapped|january 7|on
journalist|christian science monitor|nn
jill carroll|journalist|appo
kidnapped|jill carroll|obj
kidnapped|baghdad|in
baghdad|gunmen|by
gunmen|who|whn
killed|gunmen|subj
iraqi|her|gen
iraqi|iraqi|mod
iraqi|interpreter|nn
killed|iraqi|obj
investigators|us|nn
hunting for|investigators|subj
hunting for|her|obj
hunting for|acting|mod
acting|investigator|subj
acting|tip|on
iraqi|and|punc
soldiers|us|nn
iraqi|soldiers|conj
raided|iraqi|subj
mosque|baghdad|nn
raided|mosque|obj
morning|early|mod
mosque|morning|in
morning|january 10|of
detained|people|obj
detained|january 17|on
al-jazeera|arab|nn
al-jazeera|television network|nn
ran|al-jazeera|subj
ran|video|obj
video|carroll|of
message|accompanying|mod
carroll|message|with
message|that|c
killed|she|obj
killed|unless|mod
unless|freed|comp1
freed|us|subj
female|all|mod
prisoners|female|mod
freed|prisoners|obj
prisoners|iraq|in
hours|72|amount-value
iraq|hours|within
identified|kidnappers|subj
identified|themselves|obj
identified|brigades|as
brigades|vengeance|of
unknown|previously|mod
group|unknown|mod
vengeance|group|appo

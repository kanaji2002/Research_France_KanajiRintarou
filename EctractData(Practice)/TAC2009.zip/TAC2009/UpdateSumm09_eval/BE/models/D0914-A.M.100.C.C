ripped|night|in
night|october 7 , 2004 ,|of
bombs|suspected|mod
bombs|terrorist|nn
bombs|car|nn
ripped|bombs|subj
resorts|three|nn
resorts|egyptian red sea|nn
ripped|resorts|through
resorts|popular|pnmod
israelis|vacationing|nn
popular|israelis|with
30|at least|num-mod
people|30|nn
killed|people|obj
100|at least|num-mod
wounded|100|obj
month|last|post
wounded|month|mod
intelligence|israeli|mod
warned|intelligence|subj
warned|israelis|obj
israelis|keep|rel
keep|israeli|subj
desert|sinai|nn
keep|desert|out of
keep|citing|mod
citing|information|obj
attacks|possible|mod
information|attacks|about
warned|came|fc
came|explosions|subj
army|massive|mod
army|israeli|mod
came|army|amid
army|offensive|pnmod
offensive|north|in
strip|gaza|nn
north|strip|of
unheard|previously|mod
unheard|world islamist group|of
responsibility|taba hilton hotel|for
blast|responsibility|subj
blast|saying|mod
saying|responsibility|subj
saying|was|fc
was|in|pred
was|revenge|in
revenge|palestinians|for
palestinians|and|punc
palestinians|arabs|conj
arabs|killed|vrel
killed|arabs|obj
killed|palestine|in
palestine|and|punc
palestine|iraq|conj

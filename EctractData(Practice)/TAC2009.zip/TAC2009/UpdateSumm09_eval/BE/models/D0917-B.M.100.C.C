puffed|tuesday , april 19 ,|on
smoke|white|mod
puffed|smoke|subj
chimney|sistine chapel|nn
puffed|chimney|from
puffed|signaling|mod
signaling|smoke|subj
signaling|election|obj
pope|new|mod
election|pope|of
ballots|four|nn
pope|ballots|after
cardinals|roman catholic|nn
elected|cardinals|subj
joseph ratzinger|german-born|mod
elected|joseph ratzinger|obj
theologian|renowned|mod
theologian|and|punc
enforcer|hard-line|mod
theologian|enforcer|conj
ratzinger|catholic church|nn
ratzinger|doctrine|nn
enforcer|ratzinger|of
took|theologian|subj
took|name|obj

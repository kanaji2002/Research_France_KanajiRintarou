son|her|gen
death|son|gen
death|april 2004|nn
following|death|obj
death|iraq|in
made|cindy sheehan|subj
appearances|regular|mod
appearances|public|mod
made|appearances|obj1
appearances|nation|across
nation|protesting|rel
protesting|nation|subj
protesting|war|obj
war|co -|rel
co -|war|obj
co -|she|subj
made|gold star families|desc
gold star families|peace|for
peace|august 8 , 2005 ,|on
led|sheehan|subj
protest|antiwar|mod
led|protest|obj
protest|road|down
road|leading to|rel
leading to|road|subj
ranch|president|gen
president|bush|person
leading to|ranch|obj
ranch|crawford|near
she|and|punc
50|about|num-mod
activists|50|nn
activists|antiwar|mod
she|activists|conj
established|she|subj
camp|roadside|nn
established|camp|obj
far|not|mod
camp|far|pnmod
far|ranch|from
established|vowing|mod
vowing|she|subj
remain|until|mod
until|met with|comp1
met with|bush|subj
met with|her|obj
vowing|used|fc
used|she|subj
used|internet|obj
internet|garner|rel
garner|internet|subj
garner|publicity|obj
publicity|august 11|by
protesters|dozen|mod
joined|country|subj
joined|sheehan|obj
sheehan|camp casey|at
camp casey|named|vrel
named|camp casey|obj
named|fallen|mod
fallen|her|subj
fallen|son|obj

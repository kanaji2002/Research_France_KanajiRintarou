supremacists|white|mod
travel|often|mod-before
travel|supremacists|subj
staging|cross-country|nn
protests|staging|subj
group|arkansas-based|mod
protests|group|obj
group|protested|vrel
protested|group|obj
protested|boston|in
group|virginia-based|mod
boston|marched|rel
marched|boston|obj
marched|group|subj
marched|toledo|in
urged|neo-nazis|subj
urged|followers|obj
followers|travel to|rel
travel to|follower|subj
travel to|crawford|obj
crawford|protest|rel
protest|crawford|subj
war|iraq|nn
protest|war|obj
leader|one|nn
leader|neo-nazi|nn
plotted|leader|subj
kill|leader|subj
judge|federal|mod
kill|judge|obj
judge|white|person
plotted|spread|fc
spread|supremacists|subj
word|their|gen
spread|word|obj
word|books|through
books|and|punc
postings|internet|nn
books|postings|conj
quoting|often|amod
spread|quoting|mod
quoting|supremacist|subj
quoting|king|obj
king|and|punc
civil rights leaders|other|mod
king|civil rights leaders|conj
civil rights leaders|advance|rel
advance|civil rights leader|subj
advance|their own|obj1
advance|agendas|obj2
clashes|violent|mod
avoid|clashes|obj
leaders|community|mod
pleaded|leaders|subj
pleaded|calm|for
pleaded|staged|conj
staged|leaders|subj
rallies|peace|nn
staged|rallies|obj
staged|and|punc
staged|delayed|conj
delayed|leaders|obj
delayed|announcing|mod
announcing|leader|subj
routes|protest|nn
group|national|mod
group|watchdog|nn
routes|monitors|rel
monitors|routes|obj
monitors|group|subj
announcing|warehouse|fc
warehouse|routes|subj
warehouse|activities|obj
aryan wear|online|mod
aryan wear|retailer|nn
activities|aryan wear|of
aryan wear|dallas-fort worth|in

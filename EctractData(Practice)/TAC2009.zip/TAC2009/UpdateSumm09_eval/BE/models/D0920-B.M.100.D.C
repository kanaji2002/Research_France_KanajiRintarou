birthday|yusuf islam|gen
yusuf islam|birthday|whn
is|july 21|pred
host|yusuf islam|subj
host|concert|obj
concert|jakarta|in
jakarta|raise|rel
raise|jakarta|subj
raise|money|obj
victims|tsunami|nn
victims|disaster|nn
money|victims|for
perform|he|subj
song|his|gen
perform|song|obj
indian ocean|written|pnmod
proceeds|occasion|nn
written|proceeds|for
recording|song|gen
proceeds|recording|from
go|indian ocean|subj
go|aid|mod
aid|indian ocean|subj
children|tsunami-orphaned|mod
aid|children|obj
charity|his|gen
children|charity|through
newspapers|small|mod
newspapers|kindness|nn
newspapers|two|nn
newspapers|british|mod
newspapers|paid|vrel
paid|newspapers|obj1
damages|unspecified|mod
paid|damages|obj2
damages|islam|to
islam|articles|over
articles|suggesting|rel
suggesting|article|subj
suggesting|had|fc
had|he|subj
had|links|obj
islam|terrorists|nn
links|islam|to
said|newspapers|subj
said|given|fc
given|money|obj
projects|relief|nn
given|projects|to
projects|areas|in
areas|hit|vrel
hit|areas|obj
hit|by|by-subj
indian ocean|december|nn
hit|indian ocean|by
government|tsunami|nn
government|us|nn
explained|still|mod-before
explained|not|amod
explained|government|subj
explained|why|wha
name|his|gen
added|name|obj
list|no-fly|mod
added|list|to

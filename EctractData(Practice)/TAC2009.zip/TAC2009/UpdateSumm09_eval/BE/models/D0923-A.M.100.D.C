real id act|so-called|mod
attached|real id act|obj
bill|must-pass|nn
bill|iraq|nn
bill|appropriations|nn
attached|bill|to
attached|consequently|mod
had|legislators|subj
time|little|mod
had|time|obj
debate|legislator|subj
debate|bill|obj
bill|passing|before
passing|legislator|subj
passing|it|obj1
passing|only|guest
passing|driver 's licenses|obj2
driver 's licenses|complying|from
time|be|comp1
be|valid|pred
valid|air travel|for
air travel|and|punc
purposes|other|mod
purposes|official|nn
purposes|identification|nn
air travel|purposes|conj
purposes|deny|rel
deny|purposes|obj1
deny|law|subj
deny|licenses|obj2
immigrants|illegal|mod
licenses|immigrants|to
deny|and|punc
raise|significantly|amod
deny|raise|conj
raise|purposes|obj
raise|law|subj
standard|proof|of
proof|persecution|of
proponents|asylum-seekers|nn
persecution|proponents|for
expect|standard|subj
opponents|greater|mod
opponents|homeland|nn
opponents|security|nn
say|opponents|subj
say|is|fc
is|anti-immigrant|pred
is|and|punc
is|add|conj
add|law|subj
add|cost|obj
libertarians|dmv|nn
libertarians|processes|nn
libertarians|civil|mod
delays|libertarians|to
argue|delays|subj
argue|creates|fc
creates|it|subj
national|de facto|mod
card|national|mod
card|id|nn
creates|card|obj
creates|and|punc
creates|threatens|conj
threatens|it|subj
privacy|individual|mod
threatens|privacy|obj

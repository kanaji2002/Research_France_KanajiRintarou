aired|january 19|on
images|new|mod
images|jill carroll|of
jill carroll|surrounded|vrel
surrounded|jill carroll|obj
surrounded|by|by-subj
gunmen|masked|mod
surrounded|gunmen|by
revenge brigade|so-called|mod
gunmen|revenge brigade|of
aired|images|obj
aired|those|among
those|pleading|rel
pleading|those|subj
were|carroll|for
pleading|were|fc
mother|her|gen
were|mother|pred
mother|and|punc
muslim|iraqi|nn
mother|muslim|conj
group|leaders a us-based|mod
group|islamic|mod
group|rights|nn
group|sent|vrel
sent|group|obj1
sent|representatives|obj2
representatives|baghdad|to
senator|her|gen
senator|behalf|nn
senator|us|nn
baghdad|senator|on
senator|john kerry|person
discussed|group|subj
plight|her|gen
officials|iraqi|mod
plight|officials|with
visit|his|gen
officials|visit|during
ministry|iraq iraq|gen
ministry|justice|nn
visit|ministry|to
discussed|announced|fc
announced|plight|subj
announced|that|c
detainees|eight|nn
detainees|women|nn
six|detainees|of
were|due|pred
be|release|pred
release|week|within
week|based|pnmod
based|review|on
iraqi|their|gen
iraqi|cases|nn
review|iraqi|of
officials|us|nn
deny|officials|subj
deny|be|fc
be|in|pred
be|response|in
demands|captors|gen
response|demands|to

recommends|john yoo|subj
recommends|develop|fc
develop|us|subj
ways|new|mod
new|ruthless|conj
ruthless|and|punc
ruthless|cunning|conj
develop|ways|mod
ways|combat|rel
combat|way|subj
networks|terrorist|mod
combat|networks|obj
networks|some|whn
some|networks|of
run afoul of|some|subj
in|existing|mod
in|laws|nn
run afoul of|in|obj
book|his|gen
book|new|mod
contends|yoo|subj
contends|has|fc
has|us|subj
has|right|obj
right|hold|comp1
hold|us|subj
combatants|enemy|mod
hold|combatants|obj
hold|indefinitely|mod
indefinitely|charges|without
charges|believes|comp1
believes|he|subj
believes|gives|fc
gives|constitution|subj
power|president|nn
power|sole|mod
gives|power|obj
power|interpret|rel
interpret|power|subj
interpret|international law|obj
believes|he|subj
techniques|cruel|mod
cruel|inhumane|conj
inhumane|or|punc
inhumane|degrading|conj
techniques|interrogation|nn
believes|fall short of|fc
fall short of|techniques|subj
fall short of|torture|obj
fall short of|and|punc
fall short of|employed|conj
employed|techniques|obj
discretion|president|gen
employed|discretion|at
discretion|prisoners|with
yoo|overseas|mod
prisoners|wrote|rel
wrote|prisoners|obj1
wrote|yoo|subj
wrote|commentary|obj2
john roberts|supreme court|nn
john roberts|nominees|nn
commentary|john roberts|on
john roberts|harriet myers|conj
harriet myers|and|punc
harriet myers|samuel alito|conj
on|and|punc
on|on|conj
improvements|suggested|mod
improvements|government|nn
improvements|disaster|nn
improvements|response|nn
on|improvements|on

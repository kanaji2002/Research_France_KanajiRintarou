election day|iraq|gen
claimed|election day|on
attacks|voting|nn
attacks|center|nn
claimed|attacks|subj
six|at least|num-mod
claimed|lives|fc
lives|six|subj
series|blasts|of
blasts|baghdad|around
included|series|subj
bombing|suicide|nn
included|bombing|obj
bombing|which|whn
killed|bombing|subj
killed|one|obj
killed|and|punc
killed|wounded|conj
wounded|bombing|subj
wounded|four|obj
attack|mortar|nn
killed|attack|subj
killed|four|obj
killed|and|punc
killed|wounded|conj
wounded|attack|subj
wounded|seven|obj
slum|shiite|nn
seven|slum|in
basra|sadr city|nn
basra|in|nn
slum|basra|of
mortar|exploded|vrel
exploded|mortar|obj
exploded|but|mod
but|were|comp1
balad|reported|mod
were|balad|pred
suffered|mortar|subj
mortar|two|nn
suffered|mortar|obj
voter|attacks|nn
voter|one|nn
killed|voter|obj
wounded|child|subj
contrast|in|nn
contrast|sharp|mod
wounded|contrast|obj
went|no one|subj
went|vote|fc
vote|no one|subj
most|fallujah|nn
said|most|in
vote|said|fc
said|people|subj
said|were|fc
in|afraid|mod
were|in|pred
days|past|mod
were|days|mod
targeted|insurgents|subj
centers|polling|mod
targeted|centers|obj
province|anbar|nn
centers|province|in
province|where|wha
situated|fallujah|obj

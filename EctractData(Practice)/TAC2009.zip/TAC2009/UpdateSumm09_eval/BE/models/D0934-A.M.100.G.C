health|yasser arafat|gen
concern|health|for
came to|concern|subj
came to|light|obj
light|october 23|around
came to|when|wha
doctors|tunisian|mod
team|doctors|of
traveled to|team|subj
traveled to|ramallah|obj
examine|him|obj
daily|nearly|mod
conflicting|daily|mod
reports|conflicting|mod
condition|his|gen
reports|condition|of
followed|reports|subj
ailments|possible|mod
included|ailments|subj
included|flu|obj
disease|blood|nn
flu|disease|conj
disease|and|punc
disease|cancer|conj
cancer|october 29|on
flown|arafat|obj
hospital|military|nn
flown|hospital|to
transferred|paris|near
transferred|he|obj
unit|intensive|mod
unit|care|nn
transferred|unit|to
unit|november 3.|on
unit|november 9|by
reports|conflicting|mod
flurry|reports|of
death|his|gen
reports|death|of
death|or|punc
condition|near-death|mod
death|condition|conj
circulated|flurry|subj
factions|palestinian|mod
circulated|factions|obj
factions|met|vrel
met|factions|obj
met|discuss|mod
discuss|flurry|subj
discuss|arrangements|obj
arrangements|following|rel
following|arrangement|subj
israeli|his|gen
israeli|death|nn
following|israeli|obj
officials|palestinian|mod
came to|officials|subj
came to|agreement|obj
arrangements|his|gen
arrangements|funeral|nn
agreement|arrangements|about

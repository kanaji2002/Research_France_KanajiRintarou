after|'s|comp1
father|revered|mod
's|father|pred
deterrent|its|gen
deterrent|nuclear|mod
father|deterrent|of
deterrent|admitted|vrel
admitted|deterrent|obj
admitted|february|in
dealings|black market|nn
admitted|dealings|to
technology|nuclear weapons|nn
dealings|technology|in
technology|iran|to
libya|and|punc
libya|north korea|conj
north korea|pardoned|rel
pardoned|north korea|obj2
pardoned|he|obj1
north korea|but|punc
north korea|remains|conj
investigations|house arrest|nn
investigations|recent|mod
remains|investigations|under
found|libya|subj
found|evidence|obj
evidence|that|c
delivered|khan|subj
blueprints|bomb|nn
delivered|blueprints|obj
enriched|weapons-grade|subj
enriched|uranium|obj
uranium|iran|to
iran|sold|rel
sold|iran|obj1
sold|he|subj
blueprints|warhead|nn
sold|blueprints|obj2
blueprints|libya|to
sold|and|punc
surfaced|possibly|mod-before
possibly|north korea evidence|to
sold|surfaced|conj
surfaced|iran|obj
surfaced|he|subj
enterprise|his|gen
enterprise|vast|mod
enterprise|global|mod
surfaced|enterprise|of
facilities|his|gen
enterprise|facilities|conj
facilities|dubai|in
dubai|and|punc
dubai|south africa|conj
south africa|and|punc
connections|international|mod
south africa|connections|conj
enterprise|asia|from
skepticism|africa pakistan|gen
skepticism|government|nn
skepticism|expressed|mod
asia|skepticism|to
claims|recent|mod
skepticism|claims|over
claims|and|punc
claims|refuses|conj
refuses|allow|rel
allow|refuse|subj
question|foreign|mod
question|authorities|nn
allow|question|obj1
allow|khan|obj2

reduced|november 2004|during
minister|india|gen
minister|prime|mod
reduced|minister|subj
reduced|troops|obj
border|kashmir|nn
troops|border|on
gesture|goodwill|nn
border|gesture|as
visit|his|gen
gesture|visit|prior to
while|met with|comp1
met with|he|subj
met with|kashmiri|obj
leaders|separatist|mod
leaders|india|person
rejected|leaders|subj
suggestion|pakistani|mod
rejected|suggestion|obj
suggestion|that|c
areas|kashmir|nn
made|areas|obj1
made|independent|desc
made|placed|conj
placed|areas|obj
control|joint|mod
placed|control|under
placed|or|punc
placed|put|conj
put|areas|obj
administration|un|nn
put|administration|under
indian|and|punc
ministers|pakistani|mod
ministers|prime|mod
indian|ministers|conj
administration|were|rel
were|meet|mod
meet|leader|subj
meet|new delhi|in
new delhi|further|rel
further|new delhi|subj
process|peace|nn
further|process|obj
process|begun|vrel
begun|process|obj
begun|january|in
were|and|punc
were|facilitated|conj
facilitated|administration|obj
facilitated|indian|subj
ceasefire|year-long|mod
facilitated|ceasefire|by
facilitated|consequently|mod
facilitated|april 7 , 2005 ,|on
service|limited|mod
service|bi-weekly|mod
service|bus|nn
sections|indian-and pakistani-controlled|mod
service|sections|between
sections|kashmir|of
kashmir|resumed|vrel
resumed|kashmir|obj
time|first|post
resumed|time|for
years|57|amount-value
time|years|in

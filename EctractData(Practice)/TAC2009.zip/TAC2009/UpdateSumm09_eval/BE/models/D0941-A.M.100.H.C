journey|seven-year|nn
separated|journey|after
probe|huygens|nn
probe|space|nn
separated|successfully|mod-before
separated|probe|subj
spacecraft|cassini|nn
separated|spacecraft|from
december 24|about|mod
december 24|10:24 p.m. est|nn
saturn|december 24|at
three-week|its|gen
beginning|three-week|obj
free|2 million-mile|subj
free|fall|obj
titan|saturn|gen
titan|moon|nn
free|titan|toward
remain|it|subj
remain|dormant|desc
dormant|january 14|until
remain|when|wha
float|it|subj
surface|moon|gen
float|surface|to
surface|parachutes|on
float|shooting|mod
shooting|it|subj
shooting|pictures|obj
shooting|and|punc
shooting|sending|conj
sending|it|subj
sending|back|guest
sending|data|obj
2.5|about|num-mod
hours|2.5|amount-value
data|hours|for
sending|before|mod
hitting|surface|obj
before|hope|comp1
hope|scientists|subj
hope|confirm|fc
confirm|huygens|subj
confirm|assumption|obj
assumption|that|c
atmosphere|titan|gen
is|similar|pred
similar|that|to
earth|early|mod
is|earth|of
project|joint|mod
is|project|pred
project|nasa|of
nasa|european space agency|conj
european space agency|and|punc
european space agency|italian space agency|conj

announced|march 13|on
announced|china|subj
adoption|its|gen
announced|adoption|obj
beijing|anti-secession law taiwan|nn
beijing|condemned|mod
adoption|beijing|of
beijing|passing|for
passing|china|subj
passing|law|obj
saying|caused|fc
caused|it|subj
damage|irreparable|mod
caused|damage|obj
relations|cross-strait|mod
damage|relations|to
officials|taiwan|nn
said|officials|subj
said|that|c
state|independent|mod
state|sovereign|mod
is|state|pred
state|belonging to|rel
belonging to|state|subj
people|taiwan|nn
belonging to|people|obj
move|change|rel
change|move|subj
change|status quo|obj
approval|people|gen
status quo|approval|without
prices|unacceptable|mod
prices|taiwan|nn
prices|share|nn
is|prices|pred
prices|dropped|vrel
dropped|sharply|guest
concern|us|nn
concern|expressed|mod
dropped|concern|obj2
dropped|and|punc
dropped|called|conj
called|move|subj
adoption|china|gen
called|adoption|obj
adoption|law|of
law|unfortunate|pnmod
announced|china|subj
announced|that|c
countries|more|mod
supported|countries|subj
adoption|its|gen
supported|adoption|obj
adoption|law|of
countries|listed|mod
countries|numerous|mod
countries|tiny|mod
mostly|africa|in
africa|and|punc
africa|asia|conj
asia|and|punc
asia|france|conj

arrived at|sunday , april 17 , 115|on
cardinals|roman catholic|nn
cardinals|representing|rel
representing|cardinal|subj
countries|52|num
representing|countries|obj
countries|and|punc
continents|six|nn
countries|continents|conj
arrived at|cardinals|subj
arrived at|vatican|obj
vatican|select|rel
select|vatican|subj
select|successor|obj
ii|pope john paul|nn
successor|ii|to
ii|monday|on
convened|they|subj
convened|conclave|obj
conclave|secret|conj
secret|and|punc
gathering|sacred|mod
secret|gathering|conj
convened|sistine chapel following|in
oath|cardinals|gen
process|selection|nn
began|process|subj
majority|two-thirds|nn
required|majority|obj
required|elect|mod
elect|majority|subj
elect|pope|obj
elect|outside|mod
focused|attention|obj
roof|chapel|nn
focused|roof|on
focused|watching|mod
watching|attention|subj
smoke|white|mod
rose|smoke|for
smoke|burning|of
burning|ballots|obj
ballots|that|whn
indicate|ballots|subj
election|successful|mod
indicate|election|obj
indicate|monday|mod
smoke|black|mod
watching|rose|fc
rose|smoke|subj
rose|chimney|from
chimney|return|rel
return|chimney|obj
return|cardinals|subj
return|twice|mod
return|daily|mod
return|beginning|mod
beginning|cardinal|subj
beginning|tuesday|mod
ballots|additional|mod
beginning|ballots|for

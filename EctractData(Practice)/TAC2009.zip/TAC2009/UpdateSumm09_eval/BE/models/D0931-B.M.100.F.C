evidence|new|mod
surfaced|evidence|subj
surfaced|indicating|mod
indicating|evidence|subj
indicating|sold|fc
sold|a.q khan|subj
technology|nuclear|mod
sold|technology|obj
technology|saudi arabia|to
saudi arabia|and|punc
countries|other|mod
saudi arabia|countries|conj
played|also|mod-before
countries|played|rel
played|countries|obj1
played|he|subj
role|bigger|mod
played|role|obj2
disclosed|previously|mod
disclosed|iran|in
iran|and|punc
programs|north korea|gen
programs|nuclear|mod
iran|programs|conj
materials|bomb-building|mod
delivering|materials|obj
centrifuges|high-speed|mod
including|centrifuges|obj
centrifuges|and|punc
centrifuges|designs|conj
believe|investigators|subj
believe|traveled to|fc
traveled to|he|subj
traveled to|saudi arabia|obj
saudi arabia|egypt|conj
egypt|sudan|conj
sudan|ivory coast|conj
ivory coast|and|punc
ivory coast|niger|conj
purpose|trips|of
is|unclear|pred
deputy|khan|gen
provided|in|mod-before
provided|custody|in
custody|malaysia|in
provided|deputy|subj
provided|information|obj
evidence|his|gen
evidence|activities|nn
evidence|pakistan|nn
evidence|dismissed|mod
evidence|recent|mod
information|evidence|of
evidence|as|mod
provided|but|punc
provided|said|conj
said|deputy|subj
probe|its|gen
activities|khan|gen
probe|activities|into
said|continues|fc
continues|probe|subj
authorities|foreign|mod
banned|still|amod
banned|authorities|obj
questioning|authority|subj
questioning|him|obj
authorities|pakistani|mod
relay|authorities|subj
relay|questions|obj
questions|him|to

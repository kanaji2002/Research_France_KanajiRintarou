#! /usr/bin/perl -w

my $score1 = 0;
my $score2 = 0;
my $pc;
my $moy = 0;
my $cpt = 0;

while (<>)
{
	if ($_ =~ m/^[0-9]+ ([0-9\.]+) \(/)
	{
		if ($score1 == 0)
		{
			$score1 = $1;
		}
		elsif ( $score2 == 0)
		{
			$score2 = $1;
		}
		else
		{
			$score1 = $score2;
			$score2 = $1;
		}
		if ($score1 != 0  && $score2 != 0)
		{
			$pc = ($score1-$score2) / $score2 * 100;
			print $pc."\n";
			if ($cpt < 10)
			{

				$moy = $moy + $pc;
				$cpt = $cpt + 1;
			}
		}
	}

}
$moy = $moy / $cpt;
print "FINAL AVG : $moy\n";
